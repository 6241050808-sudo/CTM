.class public final Lcom/github/zagum/speechrecognitionview/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/github/zagum/speechrecognitionview/R$anim;,
        Lcom/github/zagum/speechrecognitionview/R$attr;,
        Lcom/github/zagum/speechrecognitionview/R$bool;,
        Lcom/github/zagum/speechrecognitionview/R$color;,
        Lcom/github/zagum/speechrecognitionview/R$dimen;,
        Lcom/github/zagum/speechrecognitionview/R$drawable;,
        Lcom/github/zagum/speechrecognitionview/R$id;,
        Lcom/github/zagum/speechrecognitionview/R$integer;,
        Lcom/github/zagum/speechrecognitionview/R$layout;,
        Lcom/github/zagum/speechrecognitionview/R$string;,
        Lcom/github/zagum/speechrecognitionview/R$style;,
        Lcom/github/zagum/speechrecognitionview/R$styleable;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
