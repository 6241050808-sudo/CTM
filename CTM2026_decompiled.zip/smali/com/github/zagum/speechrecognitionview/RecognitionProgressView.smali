.class public Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;
.super Landroid/view/View;
.source "RecognitionProgressView.java"

# interfaces
.implements Landroid/speech/RecognitionListener;


# static fields
.field public static final BARS_COUNT:I = 0x5

.field private static final CIRCLE_RADIUS_DP:I = 0x5

.field private static final CIRCLE_SPACING_DP:I = 0xb

.field private static final DEFAULT_BARS_HEIGHT_DP:[I

.field private static final IDLE_FLOATING_AMPLITUDE_DP:I = 0x3

.field private static final MDPI_DENSITY:F = 1.5f

.field private static final ROTATION_RADIUS_DP:I = 0x19


# instance fields
.field private amplitude:I

.field private animating:Z

.field private animator:Lcom/github/zagum/speechrecognitionview/animators/BarParamsAnimator;

.field private barColor:I

.field private barColors:[I

.field private barMaxHeights:[I

.field private density:F

.field private isSpeaking:Z

.field private paint:Landroid/graphics/Paint;

.field private radius:I

.field private final recognitionBars:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/github/zagum/speechrecognitionview/RecognitionBar;",
            ">;"
        }
    .end annotation
.end field

.field private recognitionListener:Landroid/speech/RecognitionListener;

.field private rotationRadius:I

.field private spacing:I

.field private speechRecognizer:Landroid/speech/SpeechRecognizer;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const/4 v0, 0x5

    new-array v0, v0, [I

    .line 45
    fill-array-data v0, :array_0

    sput-object v0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->DEFAULT_BARS_HEIGHT_DP:[I

    return-void

    nop

    :array_0
    .array-data 4
        0x3c
        0x2e
        0x46
        0x36
        0x40
    .end array-data
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    .line 70
    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 49
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionBars:Ljava/util/List;

    const/4 p1, -0x1

    .line 65
    iput p1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->barColor:I

    .line 71
    invoke-direct {p0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->init()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 0

    .line 75
    invoke-direct {p0, p1, p2}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 49
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionBars:Ljava/util/List;

    const/4 p1, -0x1

    .line 65
    iput p1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->barColor:I

    .line 76
    invoke-direct {p0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->init()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 0

    .line 80
    invoke-direct {p0, p1, p2, p3}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 49
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionBars:Ljava/util/List;

    const/4 p1, -0x1

    .line 65
    iput p1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->barColor:I

    .line 81
    invoke-direct {p0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->init()V

    return-void
.end method

.method static synthetic access$000(Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;)V
    .locals 0

    .line 36
    invoke-direct {p0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->startRotateInterpolation()V

    return-void
.end method

.method private init()V
    .locals 3

    .line 202
    new-instance v0, Landroid/graphics/Paint;

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    iput-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->paint:Landroid/graphics/Paint;

    const/4 v1, 0x1

    .line 203
    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setFlags(I)V

    .line 204
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->paint:Landroid/graphics/Paint;

    const v1, -0x777778

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 206
    invoke-virtual {p0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    iput v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->density:F

    const/high16 v1, 0x40a00000    # 5.0f

    mul-float v1, v1, v0

    float-to-int v1, v1

    .line 208
    iput v1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->radius:I

    const/high16 v1, 0x41300000    # 11.0f

    mul-float v1, v1, v0

    float-to-int v1, v1

    .line 209
    iput v1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->spacing:I

    const/high16 v1, 0x41c80000    # 25.0f

    mul-float v1, v1, v0

    float-to-int v1, v1

    .line 210
    iput v1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->rotationRadius:I

    const/high16 v1, 0x40400000    # 3.0f

    mul-float v1, v1, v0

    float-to-int v1, v1

    .line 211
    iput v1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->amplitude:I

    const/high16 v2, 0x3fc00000    # 1.5f

    cmpg-float v0, v0, v2

    if-gtz v0, :cond_0

    mul-int/lit8 v1, v1, 0x2

    .line 214
    iput v1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->amplitude:I

    :cond_0
    return-void
.end method

.method private initBarHeights()Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    .line 269
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 270
    iget-object v1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->barMaxHeights:[I

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-nez v1, :cond_0

    :goto_0
    if-ge v3, v2, :cond_1

    .line 272
    sget-object v1, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->DEFAULT_BARS_HEIGHT_DP:[I

    aget v1, v1, v3

    int-to-float v1, v1

    iget v4, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->density:F

    mul-float v1, v1, v4

    float-to-int v1, v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    :goto_1
    if-ge v3, v2, :cond_1

    .line 276
    iget-object v1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->barMaxHeights:[I

    aget v1, v1, v3

    int-to-float v1, v1

    iget v4, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->density:F

    mul-float v1, v1, v4

    float-to-int v1, v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_1

    :cond_1
    return-object v0
.end method

.method private initBars()V
    .locals 10

    .line 257
    invoke-direct {p0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->initBarHeights()Ljava/util/List;

    move-result-object v0

    .line 258
    invoke-virtual {p0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->getMeasuredWidth()I

    move-result v1

    div-int/lit8 v1, v1, 0x2

    iget v2, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->spacing:I

    mul-int/lit8 v2, v2, 0x2

    sub-int/2addr v1, v2

    iget v2, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->radius:I

    mul-int/lit8 v2, v2, 0x4

    sub-int/2addr v1, v2

    const/4 v2, 0x0

    :goto_0
    const/4 v3, 0x5

    if-ge v2, v3, :cond_0

    .line 262
    iget v3, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->radius:I

    mul-int/lit8 v3, v3, 0x2

    iget v4, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->spacing:I

    add-int/2addr v3, v4

    mul-int v3, v3, v2

    add-int v5, v1, v3

    .line 263
    new-instance v3, Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    invoke-virtual {p0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->getMeasuredHeight()I

    move-result v4

    div-int/lit8 v6, v4, 0x2

    iget v4, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->radius:I

    mul-int/lit8 v7, v4, 0x2

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v8

    iget v9, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->radius:I

    move-object v4, v3

    invoke-direct/range {v4 .. v9}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;-><init>(IIIII)V

    .line 264
    iget-object v4, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionBars:Ljava/util/List;

    invoke-interface {v4, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method private resetBars()V
    .locals 3

    .line 283
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionBars:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    .line 284
    invoke-virtual {v1}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->getStartX()I

    move-result v2

    invoke-virtual {v1, v2}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->setX(I)V

    .line 285
    invoke-virtual {v1}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->getStartY()I

    move-result v2

    invoke-virtual {v1, v2}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->setY(I)V

    .line 286
    iget v2, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->radius:I

    mul-int/lit8 v2, v2, 0x2

    invoke-virtual {v1, v2}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->setHeight(I)V

    .line 287
    invoke-virtual {v1}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->update()V

    goto :goto_0

    :cond_0
    return-void
.end method

.method private startIdleInterpolation()V
    .locals 3

    .line 292
    new-instance v0, Lcom/github/zagum/speechrecognitionview/animators/IdleAnimator;

    iget-object v1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionBars:Ljava/util/List;

    iget v2, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->amplitude:I

    invoke-direct {v0, v1, v2}, Lcom/github/zagum/speechrecognitionview/animators/IdleAnimator;-><init>(Ljava/util/List;I)V

    iput-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->animator:Lcom/github/zagum/speechrecognitionview/animators/BarParamsAnimator;

    .line 293
    invoke-interface {v0}, Lcom/github/zagum/speechrecognitionview/animators/BarParamsAnimator;->start()V

    return-void
.end method

.method private startRmsInterpolation()V
    .locals 2

    .line 297
    invoke-direct {p0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->resetBars()V

    .line 298
    new-instance v0, Lcom/github/zagum/speechrecognitionview/animators/RmsAnimator;

    iget-object v1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionBars:Ljava/util/List;

    invoke-direct {v0, v1}, Lcom/github/zagum/speechrecognitionview/animators/RmsAnimator;-><init>(Ljava/util/List;)V

    iput-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->animator:Lcom/github/zagum/speechrecognitionview/animators/BarParamsAnimator;

    .line 299
    invoke-interface {v0}, Lcom/github/zagum/speechrecognitionview/animators/BarParamsAnimator;->start()V

    return-void
.end method

.method private startRotateInterpolation()V
    .locals 4

    .line 315
    new-instance v0, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;

    iget-object v1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionBars:Ljava/util/List;

    invoke-virtual {p0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->getWidth()I

    move-result v2

    div-int/lit8 v2, v2, 0x2

    invoke-virtual {p0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->getHeight()I

    move-result v3

    div-int/lit8 v3, v3, 0x2

    invoke-direct {v0, v1, v2, v3}, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;-><init>(Ljava/util/List;II)V

    iput-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->animator:Lcom/github/zagum/speechrecognitionview/animators/BarParamsAnimator;

    .line 316
    invoke-interface {v0}, Lcom/github/zagum/speechrecognitionview/animators/BarParamsAnimator;->start()V

    return-void
.end method

.method private startTransformInterpolation()V
    .locals 5

    .line 303
    invoke-direct {p0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->resetBars()V

    .line 304
    new-instance v0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;

    iget-object v1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionBars:Ljava/util/List;

    invoke-virtual {p0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->getWidth()I

    move-result v2

    div-int/lit8 v2, v2, 0x2

    invoke-virtual {p0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->getHeight()I

    move-result v3

    div-int/lit8 v3, v3, 0x2

    iget v4, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->rotationRadius:I

    invoke-direct {v0, v1, v2, v3, v4}, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;-><init>(Ljava/util/List;III)V

    iput-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->animator:Lcom/github/zagum/speechrecognitionview/animators/BarParamsAnimator;

    .line 305
    invoke-interface {v0}, Lcom/github/zagum/speechrecognitionview/animators/BarParamsAnimator;->start()V

    .line 306
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->animator:Lcom/github/zagum/speechrecognitionview/animators/BarParamsAnimator;

    check-cast v0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;

    new-instance v1, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView$1;

    invoke-direct {v1, p0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView$1;-><init>(Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;)V

    invoke-virtual {v0, v1}, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->setOnInterpolationFinishedListener(Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator$OnInterpolationFinishedListener;)V

    return-void
.end method


# virtual methods
.method public onBeginningOfSpeech()V
    .locals 1

    .line 328
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionListener:Landroid/speech/RecognitionListener;

    if-eqz v0, :cond_0

    .line 329
    invoke-interface {v0}, Landroid/speech/RecognitionListener;->onBeginningOfSpeech()V

    :cond_0
    const/4 v0, 0x1

    .line 331
    iput-boolean v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->isSpeaking:Z

    return-void
.end method

.method public onBufferReceived([B)V
    .locals 1

    .line 352
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionListener:Landroid/speech/RecognitionListener;

    if-eqz v0, :cond_0

    .line 353
    invoke-interface {v0, p1}, Landroid/speech/RecognitionListener;->onBufferReceived([B)V

    :cond_0
    return-void
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .locals 5

    .line 231
    invoke-super {p0, p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    .line 233
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionBars:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    .line 237
    :cond_0
    iget-boolean v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->animating:Z

    if-eqz v0, :cond_1

    .line 238
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->animator:Lcom/github/zagum/speechrecognitionview/animators/BarParamsAnimator;

    invoke-interface {v0}, Lcom/github/zagum/speechrecognitionview/animators/BarParamsAnimator;->animate()V

    :cond_1
    const/4 v0, 0x0

    .line 241
    :goto_0
    iget-object v1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionBars:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_4

    .line 242
    iget-object v1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionBars:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    .line 243
    iget-object v2, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->barColors:[I

    if-eqz v2, :cond_2

    .line 244
    iget-object v3, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->paint:Landroid/graphics/Paint;

    aget v2, v2, v0

    invoke-virtual {v3, v2}, Landroid/graphics/Paint;->setColor(I)V

    goto :goto_1

    .line 245
    :cond_2
    iget v2, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->barColor:I

    const/4 v3, -0x1

    if-eq v2, v3, :cond_3

    .line 246
    iget-object v3, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->paint:Landroid/graphics/Paint;

    invoke-virtual {v3, v2}, Landroid/graphics/Paint;->setColor(I)V

    .line 248
    :cond_3
    :goto_1
    invoke-virtual {v1}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->getRect()Landroid/graphics/RectF;

    move-result-object v1

    iget v2, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->radius:I

    int-to-float v3, v2

    int-to-float v2, v2

    iget-object v4, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->paint:Landroid/graphics/Paint;

    invoke-virtual {p1, v1, v3, v2, v4}, Landroid/graphics/Canvas;->drawRoundRect(Landroid/graphics/RectF;FFLandroid/graphics/Paint;)V

    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 251
    :cond_4
    iget-boolean p1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->animating:Z

    if-eqz p1, :cond_5

    .line 252
    invoke-virtual {p0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->invalidate()V

    :cond_5
    return-void
.end method

.method public onEndOfSpeech()V
    .locals 1

    .line 359
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionListener:Landroid/speech/RecognitionListener;

    if-eqz v0, :cond_0

    .line 360
    invoke-interface {v0}, Landroid/speech/RecognitionListener;->onEndOfSpeech()V

    :cond_0
    const/4 v0, 0x0

    .line 362
    iput-boolean v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->isSpeaking:Z

    .line 363
    invoke-direct {p0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->startTransformInterpolation()V

    return-void
.end method

.method public onError(I)V
    .locals 1

    .line 368
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionListener:Landroid/speech/RecognitionListener;

    if-eqz v0, :cond_0

    .line 369
    invoke-interface {v0, p1}, Landroid/speech/RecognitionListener;->onError(I)V

    :cond_0
    return-void
.end method

.method public onEvent(ILandroid/os/Bundle;)V
    .locals 1

    .line 389
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionListener:Landroid/speech/RecognitionListener;

    if-eqz v0, :cond_0

    .line 390
    invoke-interface {v0, p1, p2}, Landroid/speech/RecognitionListener;->onEvent(ILandroid/os/Bundle;)V

    :cond_0
    return-void
.end method

.method protected onLayout(ZIIII)V
    .locals 0

    .line 220
    invoke-super/range {p0 .. p5}, Landroid/view/View;->onLayout(ZIIII)V

    .line 221
    iget-object p2, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionBars:Ljava/util/List;

    invoke-interface {p2}, Ljava/util/List;->isEmpty()Z

    move-result p2

    if-eqz p2, :cond_0

    .line 222
    invoke-direct {p0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->initBars()V

    goto :goto_0

    :cond_0
    if-eqz p1, :cond_1

    .line 224
    iget-object p1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionBars:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->clear()V

    .line 225
    invoke-direct {p0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->initBars()V

    :cond_1
    :goto_0
    return-void
.end method

.method public onPartialResults(Landroid/os/Bundle;)V
    .locals 1

    .line 382
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionListener:Landroid/speech/RecognitionListener;

    if-eqz v0, :cond_0

    .line 383
    invoke-interface {v0, p1}, Landroid/speech/RecognitionListener;->onPartialResults(Landroid/os/Bundle;)V

    :cond_0
    return-void
.end method

.method public onReadyForSpeech(Landroid/os/Bundle;)V
    .locals 1

    .line 321
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionListener:Landroid/speech/RecognitionListener;

    if-eqz v0, :cond_0

    .line 322
    invoke-interface {v0, p1}, Landroid/speech/RecognitionListener;->onReadyForSpeech(Landroid/os/Bundle;)V

    :cond_0
    return-void
.end method

.method public onResults(Landroid/os/Bundle;)V
    .locals 1

    .line 375
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionListener:Landroid/speech/RecognitionListener;

    if-eqz v0, :cond_0

    .line 376
    invoke-interface {v0, p1}, Landroid/speech/RecognitionListener;->onResults(Landroid/os/Bundle;)V

    :cond_0
    return-void
.end method

.method public onRmsChanged(F)V
    .locals 2

    .line 336
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionListener:Landroid/speech/RecognitionListener;

    if-eqz v0, :cond_0

    .line 337
    invoke-interface {v0, p1}, Landroid/speech/RecognitionListener;->onRmsChanged(F)V

    .line 339
    :cond_0
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->animator:Lcom/github/zagum/speechrecognitionview/animators/BarParamsAnimator;

    if-eqz v0, :cond_3

    const/high16 v1, 0x3f800000    # 1.0f

    cmpg-float v1, p1, v1

    if-gez v1, :cond_1

    goto :goto_0

    .line 342
    :cond_1
    instance-of v0, v0, Lcom/github/zagum/speechrecognitionview/animators/RmsAnimator;

    if-nez v0, :cond_2

    iget-boolean v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->isSpeaking:Z

    if-eqz v0, :cond_2

    .line 343
    invoke-direct {p0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->startRmsInterpolation()V

    .line 345
    :cond_2
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->animator:Lcom/github/zagum/speechrecognitionview/animators/BarParamsAnimator;

    instance-of v1, v0, Lcom/github/zagum/speechrecognitionview/animators/RmsAnimator;

    if-eqz v1, :cond_3

    .line 346
    check-cast v0, Lcom/github/zagum/speechrecognitionview/animators/RmsAnimator;

    invoke-virtual {v0, p1}, Lcom/github/zagum/speechrecognitionview/animators/RmsAnimator;->onRmsChanged(F)V

    :cond_3
    :goto_0
    return-void
.end method

.method public play()V
    .locals 1

    .line 103
    invoke-direct {p0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->startIdleInterpolation()V

    const/4 v0, 0x1

    .line 104
    iput-boolean v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->animating:Z

    return-void
.end method

.method public setBarMaxHeightsInDp([I)V
    .locals 5

    if-nez p1, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x5

    new-array v1, v0, [I

    .line 154
    iput-object v1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->barMaxHeights:[I

    .line 155
    array-length v2, p1

    const/4 v3, 0x0

    if-ge v2, v0, :cond_1

    .line 156
    array-length v2, p1

    invoke-static {p1, v3, v1, v3, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 157
    array-length v1, p1

    :goto_0
    if-ge v1, v0, :cond_2

    .line 158
    iget-object v2, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->barMaxHeights:[I

    aget v4, p1, v3

    aput v4, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 161
    :cond_1
    invoke-static {p1, v3, v1, v3, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :cond_2
    return-void
.end method

.method public setCircleRadiusInDp(I)V
    .locals 1

    int-to-float p1, p1

    .line 171
    iget v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->density:F

    mul-float p1, p1, v0

    float-to-int p1, p1

    iput p1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->radius:I

    return-void
.end method

.method public setColors([I)V
    .locals 5

    if-nez p1, :cond_0

    return-void

    :cond_0
    const/4 v0, 0x5

    new-array v1, v0, [I

    .line 134
    iput-object v1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->barColors:[I

    .line 135
    array-length v2, p1

    const/4 v3, 0x0

    if-ge v2, v0, :cond_1

    .line 136
    array-length v2, p1

    invoke-static {p1, v3, v1, v3, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 137
    array-length v1, p1

    :goto_0
    if-ge v1, v0, :cond_2

    .line 138
    iget-object v2, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->barColors:[I

    aget v4, p1, v3

    aput v4, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    .line 141
    :cond_1
    invoke-static {p1, v3, v1, v3, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :cond_2
    return-void
.end method

.method public setIdleStateAmplitudeInDp(I)V
    .locals 1

    int-to-float p1, p1

    .line 189
    iget v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->density:F

    mul-float p1, p1, v0

    float-to-int p1, p1

    iput p1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->amplitude:I

    return-void
.end method

.method public setRecognitionListener(Landroid/speech/RecognitionListener;)V
    .locals 0

    .line 96
    iput-object p1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->recognitionListener:Landroid/speech/RecognitionListener;

    return-void
.end method

.method public setRotationRadiusInDp(I)V
    .locals 1

    int-to-float p1, p1

    .line 198
    iget v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->density:F

    mul-float p1, p1, v0

    float-to-int p1, p1

    iput p1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->rotationRadius:I

    return-void
.end method

.method public setSingleColor(I)V
    .locals 0

    .line 123
    iput p1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->barColor:I

    return-void
.end method

.method public setSpacingInDp(I)V
    .locals 1

    int-to-float p1, p1

    .line 180
    iget v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->density:F

    mul-float p1, p1, v0

    float-to-int p1, p1

    iput p1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->spacing:I

    return-void
.end method

.method public setSpeechRecognizer(Landroid/speech/SpeechRecognizer;)V
    .locals 0

    .line 88
    iput-object p1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->speechRecognizer:Landroid/speech/SpeechRecognizer;

    .line 89
    invoke-virtual {p1, p0}, Landroid/speech/SpeechRecognizer;->setRecognitionListener(Landroid/speech/RecognitionListener;)V

    return-void
.end method

.method public stop()V
    .locals 1

    .line 111
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->animator:Lcom/github/zagum/speechrecognitionview/animators/BarParamsAnimator;

    if-eqz v0, :cond_0

    .line 112
    invoke-interface {v0}, Lcom/github/zagum/speechrecognitionview/animators/BarParamsAnimator;->stop()V

    const/4 v0, 0x0

    .line 113
    iput-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->animator:Lcom/github/zagum/speechrecognitionview/animators/BarParamsAnimator;

    :cond_0
    const/4 v0, 0x0

    .line 115
    iput-boolean v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->animating:Z

    .line 116
    invoke-direct {p0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->resetBars()V

    return-void
.end method
