.class public Lcom/github/zagum/speechrecognitionview/RecognitionBar;
.super Ljava/lang/Object;
.source "RecognitionBar.java"


# instance fields
.field private height:I

.field private final maxHeight:I

.field private radius:I

.field private final rect:Landroid/graphics/RectF;

.field private final startX:I

.field private final startY:I

.field private x:I

.field private y:I


# direct methods
.method public constructor <init>(IIIII)V
    .locals 2

    .line 33
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 34
    iput p1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->x:I

    .line 35
    iput p2, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->y:I

    .line 36
    iput p5, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->radius:I

    .line 37
    iput p1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->startX:I

    .line 38
    iput p2, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->startY:I

    .line 39
    iput p3, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->height:I

    .line 40
    iput p4, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->maxHeight:I

    .line 41
    new-instance p4, Landroid/graphics/RectF;

    sub-int v0, p1, p5

    int-to-float v0, v0

    div-int/lit8 p3, p3, 0x2

    sub-int v1, p2, p3

    int-to-float v1, v1

    add-int/2addr p1, p5

    int-to-float p1, p1

    add-int/2addr p2, p3

    int-to-float p2, p2

    invoke-direct {p4, v0, v1, p1, p2}, Landroid/graphics/RectF;-><init>(FFFF)V

    iput-object p4, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->rect:Landroid/graphics/RectF;

    return-void
.end method


# virtual methods
.method public getHeight()I
    .locals 1

    .line 71
    iget v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->height:I

    return v0
.end method

.method public getMaxHeight()I
    .locals 1

    .line 79
    iget v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->maxHeight:I

    return v0
.end method

.method public getRadius()I
    .locals 1

    .line 95
    iget v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->radius:I

    return v0
.end method

.method public getRect()Landroid/graphics/RectF;
    .locals 1

    .line 91
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->rect:Landroid/graphics/RectF;

    return-object v0
.end method

.method public getStartX()I
    .locals 1

    .line 83
    iget v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->startX:I

    return v0
.end method

.method public getStartY()I
    .locals 1

    .line 87
    iget v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->startY:I

    return v0
.end method

.method public getX()I
    .locals 1

    .line 55
    iget v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->x:I

    return v0
.end method

.method public getY()I
    .locals 1

    .line 63
    iget v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->y:I

    return v0
.end method

.method public setHeight(I)V
    .locals 0

    .line 75
    iput p1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->height:I

    return-void
.end method

.method public setX(I)V
    .locals 0

    .line 59
    iput p1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->x:I

    return-void
.end method

.method public setY(I)V
    .locals 0

    .line 67
    iput p1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->y:I

    return-void
.end method

.method public update()V
    .locals 7

    .line 48
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->rect:Landroid/graphics/RectF;

    iget v1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->x:I

    iget v2, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->radius:I

    sub-int v3, v1, v2

    int-to-float v3, v3

    iget v4, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->y:I

    iget v5, p0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->height:I

    div-int/lit8 v6, v5, 0x2

    sub-int v6, v4, v6

    int-to-float v6, v6

    add-int/2addr v1, v2

    int-to-float v1, v1

    div-int/lit8 v5, v5, 0x2

    add-int/2addr v4, v5

    int-to-float v2, v4

    invoke-virtual {v0, v3, v6, v1, v2}, Landroid/graphics/RectF;->set(FFFF)V

    return-void
.end method
