.class public final Lcom/github/zagum/speechrecognitionview/R$dimen;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/github/zagum/speechrecognitionview/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "dimen"
.end annotation


# static fields
.field public static final abc_action_bar_content_inset_material:I = 0x7f060000

.field public static final abc_action_bar_content_inset_with_nav:I = 0x7f060001

.field public static final abc_action_bar_default_height_material:I = 0x7f060002

.field public static final abc_action_bar_default_padding_end_material:I = 0x7f060003

.field public static final abc_action_bar_default_padding_start_material:I = 0x7f060004

.field public static final abc_action_bar_elevation_material:I = 0x7f060005

.field public static final abc_action_bar_icon_vertical_padding_material:I = 0x7f060006

.field public static final abc_action_bar_overflow_padding_end_material:I = 0x7f060007

.field public static final abc_action_bar_overflow_padding_start_material:I = 0x7f060008

.field public static final abc_action_bar_stacked_max_height:I = 0x7f060009

.field public static final abc_action_bar_stacked_tab_max_width:I = 0x7f06000a

.field public static final abc_action_bar_subtitle_bottom_margin_material:I = 0x7f06000b

.field public static final abc_action_bar_subtitle_top_margin_material:I = 0x7f06000c

.field public static final abc_action_button_min_height_material:I = 0x7f06000d

.field public static final abc_action_button_min_width_material:I = 0x7f06000e

.field public static final abc_action_button_min_width_overflow_material:I = 0x7f06000f

.field public static final abc_alert_dialog_button_bar_height:I = 0x7f060010

.field public static final abc_button_inset_horizontal_material:I = 0x7f060012

.field public static final abc_button_inset_vertical_material:I = 0x7f060013

.field public static final abc_button_padding_horizontal_material:I = 0x7f060014

.field public static final abc_button_padding_vertical_material:I = 0x7f060015

.field public static final abc_cascading_menus_min_smallest_width:I = 0x7f060016

.field public static final abc_config_prefDialogWidth:I = 0x7f060017

.field public static final abc_control_corner_material:I = 0x7f060018

.field public static final abc_control_inset_material:I = 0x7f060019

.field public static final abc_control_padding_material:I = 0x7f06001a

.field public static final abc_dialog_fixed_height_major:I = 0x7f06001c

.field public static final abc_dialog_fixed_height_minor:I = 0x7f06001d

.field public static final abc_dialog_fixed_width_major:I = 0x7f06001e

.field public static final abc_dialog_fixed_width_minor:I = 0x7f06001f

.field public static final abc_dialog_list_padding_bottom_no_buttons:I = 0x7f060020

.field public static final abc_dialog_list_padding_top_no_title:I = 0x7f060021

.field public static final abc_dialog_min_width_major:I = 0x7f060022

.field public static final abc_dialog_min_width_minor:I = 0x7f060023

.field public static final abc_dialog_padding_material:I = 0x7f060024

.field public static final abc_dialog_padding_top_material:I = 0x7f060025

.field public static final abc_dialog_title_divider_material:I = 0x7f060026

.field public static final abc_disabled_alpha_material_dark:I = 0x7f060027

.field public static final abc_disabled_alpha_material_light:I = 0x7f060028

.field public static final abc_dropdownitem_icon_width:I = 0x7f060029

.field public static final abc_dropdownitem_text_padding_left:I = 0x7f06002a

.field public static final abc_dropdownitem_text_padding_right:I = 0x7f06002b

.field public static final abc_edit_text_inset_bottom_material:I = 0x7f06002c

.field public static final abc_edit_text_inset_horizontal_material:I = 0x7f06002d

.field public static final abc_edit_text_inset_top_material:I = 0x7f06002e

.field public static final abc_floating_window_z:I = 0x7f06002f

.field public static final abc_list_item_padding_horizontal_material:I = 0x7f060033

.field public static final abc_panel_menu_list_width:I = 0x7f060034

.field public static final abc_progress_bar_height_material:I = 0x7f060035

.field public static final abc_search_view_preferred_height:I = 0x7f060036

.field public static final abc_search_view_preferred_width:I = 0x7f060037

.field public static final abc_seekbar_track_background_height_material:I = 0x7f060038

.field public static final abc_seekbar_track_progress_height_material:I = 0x7f060039

.field public static final abc_select_dialog_padding_start_material:I = 0x7f06003a

.field public static final abc_switch_padding:I = 0x7f06003b

.field public static final abc_text_size_body_1_material:I = 0x7f06003c

.field public static final abc_text_size_body_2_material:I = 0x7f06003d

.field public static final abc_text_size_button_material:I = 0x7f06003e

.field public static final abc_text_size_caption_material:I = 0x7f06003f

.field public static final abc_text_size_display_1_material:I = 0x7f060040

.field public static final abc_text_size_display_2_material:I = 0x7f060041

.field public static final abc_text_size_display_3_material:I = 0x7f060042

.field public static final abc_text_size_display_4_material:I = 0x7f060043

.field public static final abc_text_size_headline_material:I = 0x7f060044

.field public static final abc_text_size_large_material:I = 0x7f060045

.field public static final abc_text_size_medium_material:I = 0x7f060046

.field public static final abc_text_size_menu_header_material:I = 0x7f060047

.field public static final abc_text_size_menu_material:I = 0x7f060048

.field public static final abc_text_size_small_material:I = 0x7f060049

.field public static final abc_text_size_subhead_material:I = 0x7f06004a

.field public static final abc_text_size_subtitle_material_toolbar:I = 0x7f06004b

.field public static final abc_text_size_title_material:I = 0x7f06004c

.field public static final abc_text_size_title_material_toolbar:I = 0x7f06004d

.field public static final compat_button_inset_horizontal_material:I = 0x7f06008e

.field public static final compat_button_inset_vertical_material:I = 0x7f06008f

.field public static final compat_button_padding_horizontal_material:I = 0x7f060090

.field public static final compat_button_padding_vertical_material:I = 0x7f060091

.field public static final compat_control_corner_material:I = 0x7f060092

.field public static final disabled_alpha_material_dark:I = 0x7f0600c4

.field public static final disabled_alpha_material_light:I = 0x7f0600c5

.field public static final highlight_alpha_material_colored:I = 0x7f0600cb

.field public static final highlight_alpha_material_dark:I = 0x7f0600cc

.field public static final highlight_alpha_material_light:I = 0x7f0600cd

.field public static final hint_alpha_material_dark:I = 0x7f0600ce

.field public static final hint_alpha_material_light:I = 0x7f0600cf

.field public static final hint_pressed_alpha_material_dark:I = 0x7f0600d0

.field public static final hint_pressed_alpha_material_light:I = 0x7f0600d1

.field public static final notification_action_icon_size:I = 0x7f06016d

.field public static final notification_action_text_size:I = 0x7f06016e

.field public static final notification_big_circle_margin:I = 0x7f06016f

.field public static final notification_content_margin_start:I = 0x7f060170

.field public static final notification_large_icon_height:I = 0x7f060171

.field public static final notification_large_icon_width:I = 0x7f060172

.field public static final notification_main_column_padding_top:I = 0x7f060173

.field public static final notification_media_narrow_margin:I = 0x7f060174

.field public static final notification_right_icon_size:I = 0x7f060175

.field public static final notification_right_side_padding_top:I = 0x7f060176

.field public static final notification_small_icon_background_padding:I = 0x7f060177

.field public static final notification_small_icon_size_as_large:I = 0x7f060178

.field public static final notification_subtext_size:I = 0x7f060179

.field public static final notification_top_pad:I = 0x7f06017a

.field public static final notification_top_pad_large_text:I = 0x7f06017b

.field public static final tooltip_corner_radius:I = 0x7f060182

.field public static final tooltip_horizontal_padding:I = 0x7f060183

.field public static final tooltip_margin:I = 0x7f060184

.field public static final tooltip_precise_anchor_extra_offset:I = 0x7f060185

.field public static final tooltip_precise_anchor_threshold:I = 0x7f060186

.field public static final tooltip_vertical_padding:I = 0x7f060187

.field public static final tooltip_y_offset_non_touch:I = 0x7f060188

.field public static final tooltip_y_offset_touch:I = 0x7f060189


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
