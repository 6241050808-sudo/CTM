.class Lcom/github/zagum/speechrecognitionview/RecognitionProgressView$1;
.super Ljava/lang/Object;
.source "RecognitionProgressView.java"

# interfaces
.implements Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator$OnInterpolationFinishedListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->startTransformInterpolation()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;


# direct methods
.method constructor <init>(Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;)V
    .locals 0

    .line 306
    iput-object p1, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView$1;->this$0:Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onFinished()V
    .locals 1

    .line 309
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView$1;->this$0:Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;

    invoke-static {v0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->access$000(Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;)V

    return-void
.end method
