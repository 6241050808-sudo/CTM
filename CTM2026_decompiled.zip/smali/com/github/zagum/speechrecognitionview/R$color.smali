.class public final Lcom/github/zagum/speechrecognitionview/R$color;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/github/zagum/speechrecognitionview/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "color"
.end annotation


# static fields
.field public static final abc_background_cache_hint_selector_material_dark:I = 0x7f050000

.field public static final abc_background_cache_hint_selector_material_light:I = 0x7f050001

.field public static final abc_btn_colored_borderless_text_material:I = 0x7f050002

.field public static final abc_btn_colored_text_material:I = 0x7f050003

.field public static final abc_color_highlight_material:I = 0x7f050004

.field public static final abc_hint_foreground_material_dark:I = 0x7f050005

.field public static final abc_hint_foreground_material_light:I = 0x7f050006

.field public static final abc_input_method_navigation_guard:I = 0x7f050007

.field public static final abc_primary_text_disable_only_material_dark:I = 0x7f050008

.field public static final abc_primary_text_disable_only_material_light:I = 0x7f050009

.field public static final abc_primary_text_material_dark:I = 0x7f05000a

.field public static final abc_primary_text_material_light:I = 0x7f05000b

.field public static final abc_search_url_text:I = 0x7f05000c

.field public static final abc_search_url_text_normal:I = 0x7f05000d

.field public static final abc_search_url_text_pressed:I = 0x7f05000e

.field public static final abc_search_url_text_selected:I = 0x7f05000f

.field public static final abc_secondary_text_material_dark:I = 0x7f050010

.field public static final abc_secondary_text_material_light:I = 0x7f050011

.field public static final abc_tint_btn_checkable:I = 0x7f050012

.field public static final abc_tint_default:I = 0x7f050013

.field public static final abc_tint_edittext:I = 0x7f050014

.field public static final abc_tint_seek_thumb:I = 0x7f050015

.field public static final abc_tint_spinner:I = 0x7f050016

.field public static final abc_tint_switch_track:I = 0x7f050017

.field public static final accent_material_dark:I = 0x7f050018

.field public static final accent_material_light:I = 0x7f050019

.field public static final background_floating_material_dark:I = 0x7f05001a

.field public static final background_floating_material_light:I = 0x7f05001b

.field public static final background_material_dark:I = 0x7f05001c

.field public static final background_material_light:I = 0x7f05001d

.field public static final bright_foreground_disabled_material_dark:I = 0x7f05001e

.field public static final bright_foreground_disabled_material_light:I = 0x7f05001f

.field public static final bright_foreground_inverse_material_dark:I = 0x7f050020

.field public static final bright_foreground_inverse_material_light:I = 0x7f050021

.field public static final bright_foreground_material_dark:I = 0x7f050022

.field public static final bright_foreground_material_light:I = 0x7f050023

.field public static final button_material_dark:I = 0x7f050024

.field public static final button_material_light:I = 0x7f050025

.field public static final dim_foreground_disabled_material_dark:I = 0x7f0500e5

.field public static final dim_foreground_disabled_material_light:I = 0x7f0500e6

.field public static final dim_foreground_material_dark:I = 0x7f0500e7

.field public static final dim_foreground_material_light:I = 0x7f0500e8

.field public static final foreground_material_dark:I = 0x7f0500f3

.field public static final foreground_material_light:I = 0x7f0500f4

.field public static final highlighted_text_material_dark:I = 0x7f0500f5

.field public static final highlighted_text_material_light:I = 0x7f0500f6

.field public static final material_blue_grey_800:I = 0x7f0500fc

.field public static final material_blue_grey_900:I = 0x7f0500fd

.field public static final material_blue_grey_950:I = 0x7f0500fe

.field public static final material_deep_teal_200:I = 0x7f0500ff

.field public static final material_deep_teal_500:I = 0x7f050100

.field public static final material_grey_100:I = 0x7f050101

.field public static final material_grey_300:I = 0x7f050102

.field public static final material_grey_50:I = 0x7f050103

.field public static final material_grey_600:I = 0x7f050104

.field public static final material_grey_800:I = 0x7f050105

.field public static final material_grey_850:I = 0x7f050106

.field public static final material_grey_900:I = 0x7f050107

.field public static final notification_action_color_filter:I = 0x7f050145

.field public static final notification_icon_bg_color:I = 0x7f050146

.field public static final primary_dark_material_dark:I = 0x7f05014b

.field public static final primary_dark_material_light:I = 0x7f05014c

.field public static final primary_material_dark:I = 0x7f05014d

.field public static final primary_material_light:I = 0x7f05014e

.field public static final primary_text_default_material_dark:I = 0x7f05014f

.field public static final primary_text_default_material_light:I = 0x7f050150

.field public static final primary_text_disabled_material_dark:I = 0x7f050151

.field public static final primary_text_disabled_material_light:I = 0x7f050152

.field public static final ripple_material_dark:I = 0x7f0502aa

.field public static final ripple_material_light:I = 0x7f0502ab

.field public static final secondary_text_default_material_dark:I = 0x7f0502b8

.field public static final secondary_text_default_material_light:I = 0x7f0502b9

.field public static final secondary_text_disabled_material_dark:I = 0x7f0502ba

.field public static final secondary_text_disabled_material_light:I = 0x7f0502bb

.field public static final switch_thumb_disabled_material_dark:I = 0x7f0502c3

.field public static final switch_thumb_disabled_material_light:I = 0x7f0502c4

.field public static final switch_thumb_material_dark:I = 0x7f0502c5

.field public static final switch_thumb_material_light:I = 0x7f0502c6

.field public static final switch_thumb_normal_material_dark:I = 0x7f0502c7

.field public static final switch_thumb_normal_material_light:I = 0x7f0502c8

.field public static final tooltip_background_dark:I = 0x7f0502cb

.field public static final tooltip_background_light:I = 0x7f0502cc


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
