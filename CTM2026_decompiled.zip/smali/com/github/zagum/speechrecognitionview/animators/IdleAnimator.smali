.class public Lcom/github/zagum/speechrecognitionview/animators/IdleAnimator;
.super Ljava/lang/Object;
.source "IdleAnimator.java"

# interfaces
.implements Lcom/github/zagum/speechrecognitionview/animators/BarParamsAnimator;


# static fields
.field private static final IDLE_DURATION:J = 0x5dcL


# instance fields
.field private final bars:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/github/zagum/speechrecognitionview/RecognitionBar;",
            ">;"
        }
    .end annotation
.end field

.field private final floatingAmplitude:I

.field private isPlaying:Z

.field private startTimestamp:J


# direct methods
.method public constructor <init>(Ljava/util/List;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/github/zagum/speechrecognitionview/RecognitionBar;",
            ">;I)V"
        }
    .end annotation

    .line 33
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 34
    iput p2, p0, Lcom/github/zagum/speechrecognitionview/animators/IdleAnimator;->floatingAmplitude:I

    .line 35
    iput-object p1, p0, Lcom/github/zagum/speechrecognitionview/animators/IdleAnimator;->bars:Ljava/util/List;

    return-void
.end method

.method private updateCirclePosition(Lcom/github/zagum/speechrecognitionview/RecognitionBar;JI)V
    .locals 2

    long-to-float p2, p2

    const p3, 0x44bb8000    # 1500.0f

    div-float/2addr p2, p3

    const/high16 p3, 0x43b40000    # 360.0f

    mul-float p2, p2, p3

    int-to-float p3, p4

    const/high16 p4, 0x42f00000    # 120.0f

    mul-float p3, p3, p4

    add-float/2addr p2, p3

    float-to-double p2, p2

    .line 73
    invoke-static {p2, p3}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide p2

    invoke-static {p2, p3}, Ljava/lang/Math;->sin(D)D

    move-result-wide p2

    iget p4, p0, Lcom/github/zagum/speechrecognitionview/animators/IdleAnimator;->floatingAmplitude:I

    int-to-double v0, p4

    invoke-static {v0, v1}, Ljava/lang/Double;->isNaN(D)Z

    mul-double p2, p2, v0

    double-to-int p2, p2

    invoke-virtual {p1}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->getStartY()I

    move-result p3

    add-int/2addr p2, p3

    .line 74
    invoke-virtual {p1, p2}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->setY(I)V

    .line 75
    invoke-virtual {p1}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->update()V

    return-void
.end method


# virtual methods
.method public animate()V
    .locals 1

    .line 51
    iget-boolean v0, p0, Lcom/github/zagum/speechrecognitionview/animators/IdleAnimator;->isPlaying:Z

    if-eqz v0, :cond_0

    .line 52
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/animators/IdleAnimator;->bars:Ljava/util/List;

    invoke-virtual {p0, v0}, Lcom/github/zagum/speechrecognitionview/animators/IdleAnimator;->update(Ljava/util/List;)V

    :cond_0
    return-void
.end method

.method public start()V
    .locals 2

    const/4 v0, 0x1

    .line 40
    iput-boolean v0, p0, Lcom/github/zagum/speechrecognitionview/animators/IdleAnimator;->isPlaying:Z

    .line 41
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/github/zagum/speechrecognitionview/animators/IdleAnimator;->startTimestamp:J

    return-void
.end method

.method public stop()V
    .locals 1

    const/4 v0, 0x0

    .line 46
    iput-boolean v0, p0, Lcom/github/zagum/speechrecognitionview/animators/IdleAnimator;->isPlaying:Z

    return-void
.end method

.method public update(Ljava/util/List;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/github/zagum/speechrecognitionview/RecognitionBar;",
            ">;)V"
        }
    .end annotation

    .line 58
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    .line 59
    iget-wide v2, p0, Lcom/github/zagum/speechrecognitionview/animators/IdleAnimator;->startTimestamp:J

    sub-long v4, v0, v2

    const-wide/16 v6, 0x5dc

    cmp-long v8, v4, v6

    if-lez v8, :cond_0

    add-long/2addr v2, v6

    .line 60
    iput-wide v2, p0, Lcom/github/zagum/speechrecognitionview/animators/IdleAnimator;->startTimestamp:J

    .line 62
    :cond_0
    iget-wide v2, p0, Lcom/github/zagum/speechrecognitionview/animators/IdleAnimator;->startTimestamp:J

    sub-long/2addr v0, v2

    const/4 v2, 0x0

    .line 65
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    .line 66
    invoke-direct {p0, v3, v0, v1, v2}, Lcom/github/zagum/speechrecognitionview/animators/IdleAnimator;->updateCirclePosition(Lcom/github/zagum/speechrecognitionview/RecognitionBar;JI)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_1
    return-void
.end method
