.class public Lcom/github/zagum/speechrecognitionview/animators/RmsAnimator;
.super Ljava/lang/Object;
.source "RmsAnimator.java"

# interfaces
.implements Lcom/github/zagum/speechrecognitionview/animators/BarParamsAnimator;


# instance fields
.field private final barAnimators:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/util/List;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/github/zagum/speechrecognitionview/RecognitionBar;",
            ">;)V"
        }
    .end annotation

    .line 28
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 29
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/github/zagum/speechrecognitionview/animators/RmsAnimator;->barAnimators:Ljava/util/List;

    .line 30
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    .line 31
    iget-object v1, p0, Lcom/github/zagum/speechrecognitionview/animators/RmsAnimator;->barAnimators:Ljava/util/List;

    new-instance v2, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;

    invoke-direct {v2, v0}, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;-><init>(Lcom/github/zagum/speechrecognitionview/RecognitionBar;)V

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    return-void
.end method


# virtual methods
.method public animate()V
    .locals 2

    .line 51
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/animators/RmsAnimator;->barAnimators:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;

    .line 52
    invoke-virtual {v1}, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->animate()V

    goto :goto_0

    :cond_0
    return-void
.end method

.method public onRmsChanged(F)V
    .locals 2

    .line 57
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/animators/RmsAnimator;->barAnimators:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;

    .line 58
    invoke-virtual {v1, p1}, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->onRmsChanged(F)V

    goto :goto_0

    :cond_0
    return-void
.end method

.method public start()V
    .locals 2

    .line 37
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/animators/RmsAnimator;->barAnimators:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;

    .line 38
    invoke-virtual {v1}, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->start()V

    goto :goto_0

    :cond_0
    return-void
.end method

.method public stop()V
    .locals 2

    .line 44
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/animators/RmsAnimator;->barAnimators:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;

    .line 45
    invoke-virtual {v1}, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->stop()V

    goto :goto_0

    :cond_0
    return-void
.end method
