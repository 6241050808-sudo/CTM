.class public Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;
.super Ljava/lang/Object;
.source "RotatingAnimator.java"

# interfaces
.implements Lcom/github/zagum/speechrecognitionview/animators/BarParamsAnimator;


# static fields
.field private static final ACCELERATE_ROTATION_DURATION:J = 0x3e8L

.field private static final ACCELERATION_ROTATION_DEGREES:F = 40.0f

.field private static final DECELERATE_ROTATION_DURATION:J = 0x3e8L

.field private static final DURATION:J = 0x7d0L

.field private static final ROTATION_DEGREES:F = 720.0f


# instance fields
.field private final bars:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/github/zagum/speechrecognitionview/RecognitionBar;",
            ">;"
        }
    .end annotation
.end field

.field private final centerX:I

.field private final centerY:I

.field private isPlaying:Z

.field private final startPositions:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Landroid/graphics/Point;",
            ">;"
        }
    .end annotation
.end field

.field private startTimestamp:J


# direct methods
.method public constructor <init>(Ljava/util/List;II)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/github/zagum/speechrecognitionview/RecognitionBar;",
            ">;II)V"
        }
    .end annotation

    .line 42
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 43
    iput p2, p0, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->centerX:I

    .line 44
    iput p3, p0, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->centerY:I

    .line 45
    iput-object p1, p0, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->bars:Ljava/util/List;

    .line 46
    new-instance p2, Ljava/util/ArrayList;

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    iput-object p2, p0, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->startPositions:Ljava/util/List;

    .line 47
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    .line 48
    iget-object p3, p0, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->startPositions:Ljava/util/List;

    new-instance v0, Landroid/graphics/Point;

    invoke-virtual {p2}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->getX()I

    move-result v1

    invoke-virtual {p2}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->getY()I

    move-result p2

    invoke-direct {v0, v1, p2}, Landroid/graphics/Point;-><init>(II)V

    invoke-interface {p3, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    return-void
.end method

.method private accelerate(JI)F
    .locals 1

    .line 101
    new-instance v0, Landroid/view/animation/AccelerateDecelerateInterpolator;

    invoke-direct {v0}, Landroid/view/animation/AccelerateDecelerateInterpolator;-><init>()V

    long-to-float p1, p1

    const/high16 p2, 0x447a0000    # 1000.0f

    div-float/2addr p1, p2

    .line 102
    invoke-virtual {v0, p1}, Landroid/view/animation/AccelerateDecelerateInterpolator;->getInterpolation(F)F

    move-result p1

    int-to-float p2, p3

    const/high16 p3, 0x42200000    # 40.0f

    mul-float p2, p2, p3

    mul-float p1, p1, p2

    return p1
.end method

.method private decelerate(JI)F
    .locals 2

    const-wide/16 v0, 0x3e8

    sub-long/2addr p1, v0

    .line 93
    new-instance v0, Landroid/view/animation/AccelerateDecelerateInterpolator;

    invoke-direct {v0}, Landroid/view/animation/AccelerateDecelerateInterpolator;-><init>()V

    long-to-float p1, p1

    const/high16 p2, 0x447a0000    # 1000.0f

    div-float/2addr p1, p2

    .line 94
    invoke-virtual {v0, p1}, Landroid/view/animation/AccelerateDecelerateInterpolator;->getInterpolation(F)F

    move-result p1

    neg-float p1, p1

    int-to-float p2, p3

    const/high16 p3, 0x42200000    # 40.0f

    mul-float p2, p2, p3

    mul-float p1, p1, p2

    add-float/2addr p2, p1

    return p2
.end method

.method private rotate(Lcom/github/zagum/speechrecognitionview/RecognitionBar;DLandroid/graphics/Point;)V
    .locals 7

    .line 113
    invoke-static {p2, p3}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide p2

    .line 115
    iget v0, p0, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->centerX:I

    iget v1, p4, Landroid/graphics/Point;->x:I

    iget v2, p0, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->centerX:I

    sub-int/2addr v1, v2

    int-to-double v1, v1

    invoke-static {p2, p3}, Ljava/lang/Math;->cos(D)D

    move-result-wide v3

    invoke-static {v1, v2}, Ljava/lang/Double;->isNaN(D)Z

    mul-double v1, v1, v3

    iget v3, p4, Landroid/graphics/Point;->y:I

    iget v4, p0, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->centerY:I

    sub-int/2addr v3, v4

    int-to-double v3, v3

    .line 116
    invoke-static {p2, p3}, Ljava/lang/Math;->sin(D)D

    move-result-wide v5

    invoke-static {v3, v4}, Ljava/lang/Double;->isNaN(D)Z

    mul-double v3, v3, v5

    sub-double/2addr v1, v3

    double-to-int v1, v1

    add-int/2addr v0, v1

    .line 118
    iget v1, p0, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->centerY:I

    iget v2, p4, Landroid/graphics/Point;->x:I

    iget v3, p0, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->centerX:I

    sub-int/2addr v2, v3

    int-to-double v2, v2

    invoke-static {p2, p3}, Ljava/lang/Math;->sin(D)D

    move-result-wide v4

    invoke-static {v2, v3}, Ljava/lang/Double;->isNaN(D)Z

    mul-double v2, v2, v4

    iget p4, p4, Landroid/graphics/Point;->y:I

    iget v4, p0, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->centerY:I

    sub-int/2addr p4, v4

    int-to-double v4, p4

    .line 119
    invoke-static {p2, p3}, Ljava/lang/Math;->cos(D)D

    move-result-wide p2

    invoke-static {v4, v5}, Ljava/lang/Double;->isNaN(D)Z

    mul-double v4, v4, p2

    add-double/2addr v2, v4

    double-to-int p2, v2

    add-int/2addr v1, p2

    .line 121
    invoke-virtual {p1, v0}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->setX(I)V

    .line 122
    invoke-virtual {p1, v1}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->setY(I)V

    .line 123
    invoke-virtual {p1}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->update()V

    return-void
.end method


# virtual methods
.method public animate()V
    .locals 9

    .line 65
    iget-boolean v0, p0, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->isPlaying:Z

    if-nez v0, :cond_0

    return-void

    .line 67
    :cond_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    .line 68
    iget-wide v2, p0, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->startTimestamp:J

    sub-long v4, v0, v2

    const-wide/16 v6, 0x7d0

    cmp-long v8, v4, v6

    if-lez v8, :cond_1

    add-long/2addr v2, v6

    .line 69
    iput-wide v2, p0, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->startTimestamp:J

    .line 72
    :cond_1
    iget-wide v2, p0, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->startTimestamp:J

    sub-long/2addr v0, v2

    long-to-float v2, v0

    const/high16 v3, 0x44fa0000    # 2000.0f

    div-float/2addr v2, v3

    const/high16 v3, 0x44340000    # 720.0f

    mul-float v2, v2, v3

    const/4 v3, 0x0

    .line 79
    iget-object v4, p0, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->bars:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_4

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    if-lez v3, :cond_2

    const-wide/16 v6, 0x3e8

    cmp-long v8, v0, v6

    if-lez v8, :cond_2

    .line 82
    iget-object v6, p0, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->bars:Ljava/util/List;

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v6

    sub-int/2addr v6, v3

    invoke-direct {p0, v0, v1, v6}, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->decelerate(JI)F

    move-result v6

    goto :goto_1

    :cond_2
    if-lez v3, :cond_3

    .line 84
    iget-object v6, p0, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->bars:Ljava/util/List;

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v6

    sub-int/2addr v6, v3

    invoke-direct {p0, v0, v1, v6}, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->accelerate(JI)F

    move-result v6

    :goto_1
    add-float/2addr v6, v2

    goto :goto_2

    :cond_3
    move v6, v2

    :goto_2
    float-to-double v6, v6

    .line 86
    iget-object v8, p0, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->startPositions:Ljava/util/List;

    invoke-interface {v8, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroid/graphics/Point;

    invoke-direct {p0, v5, v6, v7, v8}, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->rotate(Lcom/github/zagum/speechrecognitionview/RecognitionBar;DLandroid/graphics/Point;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_4
    return-void
.end method

.method public start()V
    .locals 2

    const/4 v0, 0x1

    .line 54
    iput-boolean v0, p0, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->isPlaying:Z

    .line 55
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->startTimestamp:J

    return-void
.end method

.method public stop()V
    .locals 1

    const/4 v0, 0x0

    .line 60
    iput-boolean v0, p0, Lcom/github/zagum/speechrecognitionview/animators/RotatingAnimator;->isPlaying:Z

    return-void
.end method
