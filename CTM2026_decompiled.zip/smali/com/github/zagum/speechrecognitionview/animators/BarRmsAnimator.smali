.class public Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;
.super Ljava/lang/Object;
.source "BarRmsAnimator.java"

# interfaces
.implements Lcom/github/zagum/speechrecognitionview/animators/BarParamsAnimator;


# static fields
.field private static final BAR_ANIMATION_DOWN_DURATION:J = 0x1f4L

.field private static final BAR_ANIMATION_UP_DURATION:J = 0x82L

.field private static final MEDIUM_RMSDB_MAX:F = 5.5f

.field private static final QUIT_RMSDB_MAX:F = 2.0f


# instance fields
.field private final bar:Lcom/github/zagum/speechrecognitionview/RecognitionBar;

.field private fromHeightPart:F

.field private isPlaying:Z

.field private isUpAnimation:Z

.field private startTimestamp:J

.field private toHeightPart:F


# direct methods
.method public constructor <init>(Lcom/github/zagum/speechrecognitionview/RecognitionBar;)V
    .locals 0

    .line 40
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 41
    iput-object p1, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->bar:Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    return-void
.end method

.method private animateDown(J)V
    .locals 3

    .line 132
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->bar:Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    invoke-virtual {v0}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->getRadius()I

    move-result v0

    mul-int/lit8 v0, v0, 0x2

    .line 133
    iget-object v1, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->bar:Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    invoke-virtual {v1}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->getMaxHeight()I

    move-result v1

    int-to-float v1, v1

    iget v2, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->toHeightPart:F

    mul-float v1, v1, v2

    float-to-int v1, v1

    long-to-float p1, p1

    const/high16 p2, 0x43fa0000    # 500.0f

    div-float/2addr p1, p2

    .line 137
    new-instance p2, Landroid/view/animation/DecelerateInterpolator;

    invoke-direct {p2}, Landroid/view/animation/DecelerateInterpolator;-><init>()V

    .line 138
    invoke-virtual {p2, p1}, Landroid/view/animation/DecelerateInterpolator;->getInterpolation(F)F

    move-result p1

    const/high16 p2, 0x3f800000    # 1.0f

    sub-float/2addr p2, p1

    sub-int/2addr v1, v0

    int-to-float p1, v1

    mul-float p2, p2, p1

    float-to-int p1, p2

    add-int/2addr p1, v0

    .line 140
    iget-object p2, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->bar:Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    invoke-virtual {p2}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->getHeight()I

    move-result p2

    if-le p1, p2, :cond_0

    return-void

    :cond_0
    if-gt p1, v0, :cond_1

    .line 145
    invoke-direct {p0}, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->finish()V

    return-void

    .line 149
    :cond_1
    iget-object p2, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->bar:Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    invoke-virtual {p2, p1}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->setHeight(I)V

    .line 150
    iget-object p1, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->bar:Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    invoke-virtual {p1}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->update()V

    return-void
.end method

.method private animateUp(J)V
    .locals 3

    .line 105
    iget v0, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->fromHeightPart:F

    iget-object v1, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->bar:Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    invoke-virtual {v1}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->getMaxHeight()I

    move-result v1

    int-to-float v1, v1

    mul-float v0, v0, v1

    float-to-int v0, v0

    .line 106
    iget-object v1, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->bar:Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    invoke-virtual {v1}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->getMaxHeight()I

    move-result v1

    int-to-float v1, v1

    iget v2, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->toHeightPart:F

    mul-float v1, v1, v2

    float-to-int v1, v1

    long-to-float p1, p1

    const/high16 p2, 0x43020000    # 130.0f

    div-float/2addr p1, p2

    .line 110
    new-instance p2, Landroid/view/animation/AccelerateInterpolator;

    invoke-direct {p2}, Landroid/view/animation/AccelerateInterpolator;-><init>()V

    .line 111
    invoke-virtual {p2, p1}, Landroid/view/animation/AccelerateInterpolator;->getInterpolation(F)F

    move-result p1

    sub-int p2, v1, v0

    int-to-float p2, p2

    mul-float p1, p1, p2

    float-to-int p1, p1

    add-int/2addr v0, p1

    .line 113
    iget-object p1, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->bar:Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    invoke-virtual {p1}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->getHeight()I

    move-result p1

    if-ge v0, p1, :cond_0

    return-void

    :cond_0
    const/4 p1, 0x0

    if-lt v0, v1, :cond_1

    const/4 p2, 0x1

    goto :goto_0

    :cond_1
    move v1, v0

    const/4 p2, 0x0

    .line 122
    :goto_0
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->bar:Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    invoke-virtual {v0, v1}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->setHeight(I)V

    .line 123
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->bar:Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    invoke-virtual {v0}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->update()V

    if-eqz p2, :cond_2

    .line 126
    iput-boolean p1, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->isUpAnimation:Z

    .line 127
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide p1

    iput-wide p1, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->startTimestamp:J

    :cond_2
    return-void
.end method

.method private finish()V
    .locals 2

    .line 154
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->bar:Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    invoke-virtual {v0}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->getRadius()I

    move-result v1

    mul-int/lit8 v1, v1, 0x2

    invoke-virtual {v0, v1}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->setHeight(I)V

    .line 155
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->bar:Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    invoke-virtual {v0}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->update()V

    const/4 v0, 0x0

    .line 156
    iput-boolean v0, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->isPlaying:Z

    return-void
.end method

.method private newHeightIsSmallerCurrent(F)Z
    .locals 2

    .line 88
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->bar:Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    invoke-virtual {v0}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->getHeight()I

    move-result v0

    int-to-float v0, v0

    iget-object v1, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->bar:Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    invoke-virtual {v1}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->getMaxHeight()I

    move-result v1

    int-to-float v1, v1

    div-float/2addr v0, v1

    cmpl-float p1, v0, p1

    if-lez p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method private update()V
    .locals 4

    .line 93
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    .line 94
    iget-wide v2, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->startTimestamp:J

    sub-long/2addr v0, v2

    .line 96
    iget-boolean v2, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->isUpAnimation:Z

    if-eqz v2, :cond_0

    .line 97
    invoke-direct {p0, v0, v1}, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->animateUp(J)V

    goto :goto_0

    .line 99
    :cond_0
    invoke-direct {p0, v0, v1}, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->animateDown(J)V

    :goto_0
    return-void
.end method


# virtual methods
.method public animate()V
    .locals 1

    .line 56
    iget-boolean v0, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->isPlaying:Z

    if-eqz v0, :cond_0

    .line 57
    invoke-direct {p0}, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->update()V

    :cond_0
    return-void
.end method

.method public onRmsChanged(F)V
    .locals 4

    const v0, 0x3f19999a    # 0.6f

    const/high16 v1, 0x3f800000    # 1.0f

    const/high16 v2, 0x40000000    # 2.0f

    cmpg-float v3, p1, v2

    if-gez v3, :cond_0

    const v0, 0x3e4ccccd    # 0.2f

    goto :goto_0

    :cond_0
    cmpl-float v2, p1, v2

    if-ltz v2, :cond_2

    const/high16 v2, 0x40b00000    # 5.5f

    cmpg-float p1, p1, v2

    if-gtz p1, :cond_2

    const p1, 0x3e99999a    # 0.3f

    .line 67
    new-instance v1, Ljava/util/Random;

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    invoke-virtual {v1}, Ljava/util/Random;->nextFloat()F

    move-result v1

    add-float/2addr v1, p1

    cmpl-float p1, v1, v0

    if-lez p1, :cond_1

    goto :goto_0

    :cond_1
    move v0, v1

    goto :goto_0

    :cond_2
    const p1, 0x3f333333    # 0.7f

    .line 70
    new-instance v0, Ljava/util/Random;

    invoke-direct {v0}, Ljava/util/Random;-><init>()V

    invoke-virtual {v0}, Ljava/util/Random;->nextFloat()F

    move-result v0

    add-float/2addr v0, p1

    cmpl-float p1, v0, v1

    if-lez p1, :cond_3

    const/high16 v0, 0x3f800000    # 1.0f

    .line 75
    :cond_3
    :goto_0
    invoke-direct {p0, v0}, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->newHeightIsSmallerCurrent(F)Z

    move-result p1

    if-eqz p1, :cond_4

    return-void

    .line 79
    :cond_4
    iget-object p1, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->bar:Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    invoke-virtual {p1}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->getHeight()I

    move-result p1

    int-to-float p1, p1

    iget-object v1, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->bar:Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    invoke-virtual {v1}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->getMaxHeight()I

    move-result v1

    int-to-float v1, v1

    div-float/2addr p1, v1

    iput p1, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->fromHeightPart:F

    .line 80
    iput v0, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->toHeightPart:F

    .line 82
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->startTimestamp:J

    const/4 p1, 0x1

    .line 83
    iput-boolean p1, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->isUpAnimation:Z

    .line 84
    iput-boolean p1, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->isPlaying:Z

    return-void
.end method

.method public start()V
    .locals 1

    const/4 v0, 0x1

    .line 46
    iput-boolean v0, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->isPlaying:Z

    return-void
.end method

.method public stop()V
    .locals 1

    const/4 v0, 0x0

    .line 51
    iput-boolean v0, p0, Lcom/github/zagum/speechrecognitionview/animators/BarRmsAnimator;->isPlaying:Z

    return-void
.end method
