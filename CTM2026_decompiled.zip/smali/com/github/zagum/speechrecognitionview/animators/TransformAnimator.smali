.class public Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;
.super Ljava/lang/Object;
.source "TransformAnimator.java"

# interfaces
.implements Lcom/github/zagum/speechrecognitionview/animators/BarParamsAnimator;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator$OnInterpolationFinishedListener;
    }
.end annotation


# static fields
.field private static final DURATION:J = 0x12cL


# instance fields
.field private final bars:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/github/zagum/speechrecognitionview/RecognitionBar;",
            ">;"
        }
    .end annotation
.end field

.field private final centerX:I

.field private final centerY:I

.field private final finalPositions:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Landroid/graphics/Point;",
            ">;"
        }
    .end annotation
.end field

.field private isPlaying:Z

.field private listener:Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator$OnInterpolationFinishedListener;

.field private final radius:I

.field private startTimestamp:J


# direct methods
.method public constructor <init>(Ljava/util/List;III)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/github/zagum/speechrecognitionview/RecognitionBar;",
            ">;III)V"
        }
    .end annotation

    .line 42
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 39
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->finalPositions:Ljava/util/List;

    .line 43
    iput p2, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->centerX:I

    .line 44
    iput p3, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->centerY:I

    .line 45
    iput-object p1, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->bars:Ljava/util/List;

    .line 46
    iput p4, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->radius:I

    return-void
.end method

.method private initFinalPositions()V
    .locals 7

    .line 92
    new-instance v0, Landroid/graphics/Point;

    invoke-direct {v0}, Landroid/graphics/Point;-><init>()V

    .line 93
    iget v1, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->centerX:I

    iput v1, v0, Landroid/graphics/Point;->x:I

    .line 94
    iget v1, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->centerY:I

    iget v2, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->radius:I

    sub-int/2addr v1, v2

    iput v1, v0, Landroid/graphics/Point;->y:I

    const/4 v1, 0x0

    :goto_0
    const/4 v2, 0x5

    if-ge v1, v2, :cond_0

    .line 96
    new-instance v2, Landroid/graphics/Point;

    invoke-direct {v2, v0}, Landroid/graphics/Point;-><init>(Landroid/graphics/Point;)V

    const-wide/high16 v3, 0x4052000000000000L    # 72.0

    int-to-double v5, v1

    .line 97
    invoke-static {v5, v6}, Ljava/lang/Double;->isNaN(D)Z

    mul-double v5, v5, v3

    invoke-direct {p0, v5, v6, v2}, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->rotate(DLandroid/graphics/Point;)V

    .line 98
    iget-object v3, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->finalPositions:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method private rotate(DLandroid/graphics/Point;)V
    .locals 7

    .line 108
    invoke-static {p1, p2}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide p1

    .line 110
    iget v0, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->centerX:I

    iget v1, p3, Landroid/graphics/Point;->x:I

    iget v2, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->centerX:I

    sub-int/2addr v1, v2

    int-to-double v1, v1

    invoke-static {p1, p2}, Ljava/lang/Math;->cos(D)D

    move-result-wide v3

    invoke-static {v1, v2}, Ljava/lang/Double;->isNaN(D)Z

    mul-double v1, v1, v3

    iget v3, p3, Landroid/graphics/Point;->y:I

    iget v4, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->centerY:I

    sub-int/2addr v3, v4

    int-to-double v3, v3

    .line 111
    invoke-static {p1, p2}, Ljava/lang/Math;->sin(D)D

    move-result-wide v5

    invoke-static {v3, v4}, Ljava/lang/Double;->isNaN(D)Z

    mul-double v3, v3, v5

    sub-double/2addr v1, v3

    double-to-int v1, v1

    add-int/2addr v0, v1

    .line 113
    iget v1, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->centerY:I

    iget v2, p3, Landroid/graphics/Point;->x:I

    iget v3, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->centerX:I

    sub-int/2addr v2, v3

    int-to-double v2, v2

    invoke-static {p1, p2}, Ljava/lang/Math;->sin(D)D

    move-result-wide v4

    invoke-static {v2, v3}, Ljava/lang/Double;->isNaN(D)Z

    mul-double v2, v2, v4

    iget v4, p3, Landroid/graphics/Point;->y:I

    iget v5, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->centerY:I

    sub-int/2addr v4, v5

    int-to-double v4, v4

    .line 114
    invoke-static {p1, p2}, Ljava/lang/Math;->cos(D)D

    move-result-wide p1

    invoke-static {v4, v5}, Ljava/lang/Double;->isNaN(D)Z

    mul-double v4, v4, p1

    add-double/2addr v2, v4

    double-to-int p1, v2

    add-int/2addr v1, p1

    .line 116
    iput v0, p3, Landroid/graphics/Point;->x:I

    .line 117
    iput v1, p3, Landroid/graphics/Point;->y:I

    return-void
.end method


# virtual methods
.method public animate()V
    .locals 11

    .line 66
    iget-boolean v0, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->isPlaying:Z

    if-nez v0, :cond_0

    return-void

    .line 68
    :cond_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    .line 69
    iget-wide v2, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->startTimestamp:J

    sub-long/2addr v0, v2

    const-wide/16 v2, 0x12c

    cmp-long v4, v0, v2

    if-lez v4, :cond_1

    move-wide v0, v2

    :cond_1
    const/4 v4, 0x0

    .line 74
    :goto_0
    iget-object v5, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->bars:Ljava/util/List;

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v5

    if-ge v4, v5, :cond_2

    .line 75
    iget-object v5, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->bars:Ljava/util/List;

    invoke-interface {v5, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/github/zagum/speechrecognitionview/RecognitionBar;

    .line 77
    invoke-virtual {v5}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->getStartX()I

    move-result v6

    iget-object v7, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->finalPositions:Ljava/util/List;

    invoke-interface {v7, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroid/graphics/Point;

    iget v7, v7, Landroid/graphics/Point;->x:I

    invoke-virtual {v5}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->getStartX()I

    move-result v8

    sub-int/2addr v7, v8

    int-to-float v7, v7

    long-to-float v8, v0

    const/high16 v9, 0x43960000    # 300.0f

    div-float/2addr v8, v9

    mul-float v7, v7, v8

    float-to-int v7, v7

    add-int/2addr v6, v7

    .line 78
    invoke-virtual {v5}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->getStartY()I

    move-result v7

    iget-object v9, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->finalPositions:Ljava/util/List;

    invoke-interface {v9, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Landroid/graphics/Point;

    iget v9, v9, Landroid/graphics/Point;->y:I

    invoke-virtual {v5}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->getStartY()I

    move-result v10

    sub-int/2addr v9, v10

    int-to-float v9, v9

    mul-float v9, v9, v8

    float-to-int v8, v9

    add-int/2addr v7, v8

    .line 80
    invoke-virtual {v5, v6}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->setX(I)V

    .line 81
    invoke-virtual {v5, v7}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->setY(I)V

    .line 82
    invoke-virtual {v5}, Lcom/github/zagum/speechrecognitionview/RecognitionBar;->update()V

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :cond_2
    cmp-long v4, v0, v2

    if-nez v4, :cond_3

    .line 87
    invoke-virtual {p0}, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->stop()V

    :cond_3
    return-void
.end method

.method public setOnInterpolationFinishedListener(Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator$OnInterpolationFinishedListener;)V
    .locals 0

    .line 121
    iput-object p1, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->listener:Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator$OnInterpolationFinishedListener;

    return-void
.end method

.method public start()V
    .locals 2

    const/4 v0, 0x1

    .line 51
    iput-boolean v0, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->isPlaying:Z

    .line 52
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->startTimestamp:J

    .line 53
    invoke-direct {p0}, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->initFinalPositions()V

    return-void
.end method

.method public stop()V
    .locals 1

    const/4 v0, 0x0

    .line 58
    iput-boolean v0, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->isPlaying:Z

    .line 59
    iget-object v0, p0, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;->listener:Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator$OnInterpolationFinishedListener;

    if-eqz v0, :cond_0

    .line 60
    invoke-interface {v0}, Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator$OnInterpolationFinishedListener;->onFinished()V

    :cond_0
    return-void
.end method
