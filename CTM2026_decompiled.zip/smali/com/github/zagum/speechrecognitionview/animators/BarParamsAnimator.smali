.class public interface abstract Lcom/github/zagum/speechrecognitionview/animators/BarParamsAnimator;
.super Ljava/lang/Object;
.source "BarParamsAnimator.java"


# virtual methods
.method public abstract animate()V
.end method

.method public abstract start()V
.end method

.method public abstract stop()V
.end method
