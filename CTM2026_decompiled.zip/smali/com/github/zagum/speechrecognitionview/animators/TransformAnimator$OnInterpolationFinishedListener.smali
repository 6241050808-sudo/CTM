.class public interface abstract Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator$OnInterpolationFinishedListener;
.super Ljava/lang/Object;
.source "TransformAnimator.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/github/zagum/speechrecognitionview/animators/TransformAnimator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnInterpolationFinishedListener"
.end annotation


# virtual methods
.method public abstract onFinished()V
.end method
