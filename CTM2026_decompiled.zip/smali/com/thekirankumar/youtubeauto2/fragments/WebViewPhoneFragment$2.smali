.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$2;
.super Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;
.source "WebViewPhoneFragment.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private mLoadedUrls:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)V
    .locals 1

    .line 268
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$2;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$1;)V

    .line 269
    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$2;->mLoadedUrls:Ljava/util/Map;

    return-void
.end method


# virtual methods
.method public shouldInterceptRequest(Landroid/webkit/WebView;Ljava/lang/String;)Landroid/webkit/WebResourceResponse;
    .locals 3

    .line 276
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$2;->mLoadedUrls:Ljava/util/Map;

    invoke-interface {v0, p2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 277
    invoke-static {p2}, Lcom/thekirankumar/youtubeauto2/utils/AdBlocker;->isAd(Ljava/lang/String;)Z

    move-result v0

    .line 278
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$2;->mLoadedUrls:Ljava/util/Map;

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-interface {v1, p2, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    .line 280
    :cond_0
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$2;->mLoadedUrls:Ljava/util/Map;

    invoke-interface {v0, p2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    :goto_0
    if-eqz v0, :cond_1

    .line 282
    invoke-static {}, Lcom/thekirankumar/youtubeauto2/utils/AdBlocker;->createEmptyResource()Landroid/webkit/WebResourceResponse;

    move-result-object p1

    goto :goto_1

    .line 283
    :cond_1
    invoke-super {p0, p1, p2}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;->shouldInterceptRequest(Landroid/webkit/WebView;Ljava/lang/String;)Landroid/webkit/WebResourceResponse;

    move-result-object p1

    :goto_1
    return-object p1
.end method
