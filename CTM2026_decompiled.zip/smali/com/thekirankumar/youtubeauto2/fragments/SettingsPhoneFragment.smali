.class public Lcom/thekirankumar/youtubeauto2/fragments/SettingsPhoneFragment;
.super Landroid/preference/PreferenceFragment;
.source "SettingsPhoneFragment.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 11
    invoke-direct {p0}, Landroid/preference/PreferenceFragment;-><init>()V

    return-void
.end method


# virtual methods
.method public onCreate(Landroid/os/Bundle;)V
    .locals 0

    .line 16
    invoke-super {p0, p1}, Landroid/preference/PreferenceFragment;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f130001

    .line 17
    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/SettingsPhoneFragment;->addPreferencesFromResource(I)V

    return-void
.end method
