.class public interface abstract Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$FragmentInteractionListener;
.super Ljava/lang/Object;
.source "SafetyWarningFragment.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "FragmentInteractionListener"
.end annotation


# virtual methods
.method public abstract onReadyToExitSafetyInstructions(Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;)V
.end method
