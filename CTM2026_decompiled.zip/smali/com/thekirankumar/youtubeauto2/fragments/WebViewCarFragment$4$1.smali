.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4$1;
.super Landroid/support/v4/media/MediaBrowserCompat$ConnectionCallback;
.source "WebViewCarFragment.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;->onConnected(Landroid/support/car/Car;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;)V
    .locals 0

    .line 214
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4$1;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;

    invoke-direct {p0}, Landroid/support/v4/media/MediaBrowserCompat$ConnectionCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public onConnected()V
    .locals 3

    .line 218
    :try_start_0
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4$1;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;

    iget-object v0, v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    .line 219
    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$700(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/support/v4/media/MediaBrowserCompat;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/media/MediaBrowserCompat;->getSessionToken()Landroid/support/v4/media/session/MediaSessionCompat$Token;

    move-result-object v0

    .line 220
    new-instance v1, Landroid/support/v4/media/session/MediaControllerCompat;

    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4$1;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;

    iget-object v2, v2, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    .line 221
    invoke-virtual {v2}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-direct {v1, v2, v0}, Landroid/support/v4/media/session/MediaControllerCompat;-><init>(Landroid/content/Context;Landroid/support/v4/media/session/MediaSessionCompat$Token;)V

    .line 222
    new-instance v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4$1$1;

    invoke-direct {v0, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4$1$1;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4$1;)V

    invoke-virtual {v1, v0}, Landroid/support/v4/media/session/MediaControllerCompat;->registerCallback(Landroid/support/v4/media/session/MediaControllerCompat$Callback;)V

    .line 229
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4$1;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;

    iget-object v0, v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v0, v1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$802(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Landroid/support/v4/media/session/MediaControllerCompat;)Landroid/support/v4/media/session/MediaControllerCompat;
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method

.method public onConnectionFailed()V
    .locals 0

    .line 243
    invoke-super {p0}, Landroid/support/v4/media/MediaBrowserCompat$ConnectionCallback;->onConnectionFailed()V

    return-void
.end method

.method public onConnectionSuspended()V
    .locals 0

    .line 238
    invoke-super {p0}, Landroid/support/v4/media/MediaBrowserCompat$ConnectionCallback;->onConnectionSuspended()V

    return-void
.end method
