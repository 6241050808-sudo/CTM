.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12$2;
.super Ljava/lang/Object;
.source "WebViewCarFragment.java"

# interfaces
.implements Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener$OnCompleteListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->onClick(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;

.field final synthetic val$recognitionProgressView:Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;)V
    .locals 0

    .line 396
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12$2;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12$2;->val$recognitionProgressView:Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onEnd()V
    .locals 0

    return-void
.end method

.method public onError(I)V
    .locals 1

    .line 414
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12$2;->val$recognitionProgressView:Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;

    invoke-virtual {p1}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->stop()V

    .line 415
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12$2;->val$recognitionProgressView:Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;

    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->setVisibility(I)V

    .line 416
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12$2;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;

    iget-object p1, p1, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1600(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/speech/SpeechRecognizer;

    move-result-object p1

    if-eqz p1, :cond_0

    .line 417
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12$2;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;

    iget-object p1, p1, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1600(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/speech/SpeechRecognizer;

    move-result-object p1

    invoke-virtual {p1}, Landroid/speech/SpeechRecognizer;->destroy()V

    .line 418
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12$2;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;

    iget-object p1, p1, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1602(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Landroid/speech/SpeechRecognizer;)Landroid/speech/SpeechRecognizer;

    :cond_0
    return-void
.end method

.method public onVoiceRecognitionComplete(Ljava/lang/String;)V
    .locals 1

    .line 399
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12$2;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;

    iget-object v0, v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1100(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Ljava/lang/String;)V

    .line 400
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12$2;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;

    iget-object p1, p1, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1600(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/speech/SpeechRecognizer;

    move-result-object p1

    if-eqz p1, :cond_0

    .line 401
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12$2;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;

    iget-object p1, p1, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1600(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/speech/SpeechRecognizer;

    move-result-object p1

    invoke-virtual {p1}, Landroid/speech/SpeechRecognizer;->destroy()V

    .line 402
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12$2;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;

    iget-object p1, p1, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1602(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Landroid/speech/SpeechRecognizer;)Landroid/speech/SpeechRecognizer;

    .line 404
    :cond_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12$2;->val$recognitionProgressView:Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;

    invoke-virtual {p1}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->stop()V

    .line 405
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12$2;->val$recognitionProgressView:Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;

    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->setVisibility(I)V

    return-void
.end method
