.class public Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;
.super Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;
.source "WebViewPhoneFragment.java"

# interfaces
.implements Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;
.implements Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$OnFragmentInteractionListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;
    }
.end annotation


# static fields
.field private static final BOOKMARKS_FRAGMENT_TAG:Ljava/lang/String; = "bookmarks"

.field private static final PLAYER_FRAGMENT_TAG:Ljava/lang/String; = "player"

.field private static final PREFS:Ljava/lang/String; = "phone_prefs"

.field private static final READ_STORAGE_PERMISSION_REQUEST_CODE:I = 0xa


# instance fields
.field private final TAG:Ljava/lang/String;

.field private editText:Landroid/widget/EditText;

.field private mediaBrowser:Landroid/support/v4/media/MediaBrowserCompat;

.field private mediaSessionCompat:Landroid/support/v4/media/session/MediaSessionCompat;

.field private progressBar:Landroid/widget/ProgressBar;

.field private sharedPrefs:Landroid/content/SharedPreferences;

.field private webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 95
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;-><init>()V

    const-string v0, "WebViewCarFragment"

    .line 87
    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->TAG:Ljava/lang/String;

    return-void
.end method

.method static synthetic access$000(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)Landroid/support/v4/media/MediaBrowserCompat;
    .locals 0

    .line 82
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->mediaBrowser:Landroid/support/v4/media/MediaBrowserCompat;

    return-object p0
.end method

.method static synthetic access$200(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)Landroid/widget/EditText;
    .locals 0

    .line 82
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->editText:Landroid/widget/EditText;

    return-object p0
.end method

.method static synthetic access$300(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;
    .locals 0

    .line 82
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    return-object p0
.end method

.method static synthetic access$400(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;Landroid/widget/EditText;Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;)V
    .locals 0

    .line 82
    invoke-direct {p0, p1, p2}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->onDone(Landroid/widget/EditText;Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;)V

    return-void
.end method

.method static synthetic access$500(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;Landroid/widget/EditText;)V
    .locals 0

    .line 82
    invoke-direct {p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->hideKeyboard(Landroid/widget/EditText;)V

    return-void
.end method

.method static synthetic access$600(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;Ljava/lang/String;)V
    .locals 0

    .line 82
    invoke-direct {p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->showNativePlayer(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$700(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)Landroid/widget/ProgressBar;
    .locals 0

    .line 82
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->progressBar:Landroid/widget/ProgressBar;

    return-object p0
.end method

.method static synthetic access$800(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)Landroid/content/SharedPreferences;
    .locals 0

    .line 82
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getSharedPrefs()Landroid/content/SharedPreferences;

    move-result-object p0

    return-object p0
.end method

.method private getAvailableActions()J
    .locals 2

    const-wide/16 v0, 0xe30

    return-wide v0
.end method

.method private getSharedPrefs()Landroid/content/SharedPreferences;
    .locals 3

    .line 120
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->sharedPrefs:Landroid/content/SharedPreferences;

    if-eqz v0, :cond_0

    return-object v0

    .line 123
    :cond_0
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v1, 0x0

    const-string v2, "phone_prefs"

    invoke-virtual {v0, v2, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->sharedPrefs:Landroid/content/SharedPreferences;

    return-object v0
.end method

.method private handleExternalSdCard()V
    .locals 1

    .line 377
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->isReadExternalFilesGranted()Z

    move-result v0

    if-nez v0, :cond_0

    .line 378
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->requestPermissionForReadExtertalStorage()V

    :cond_0
    return-void
.end method

.method private hideBookmarksScreen()V
    .locals 3

    .line 447
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->isAdded()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 448
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getView()Landroid/view/View;

    move-result-object v0

    const v1, 0x7f0800b0

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 449
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getChildFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const-string v1, "bookmarks"

    .line 450
    invoke-virtual {v0, v1}, Landroidx/fragment/app/FragmentManager;->findFragmentByTag(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v1

    if-eqz v1, :cond_0

    .line 452
    invoke-virtual {v0}, Landroidx/fragment/app/FragmentManager;->beginTransaction()Landroidx/fragment/app/FragmentTransaction;

    move-result-object v0

    .line 453
    invoke-virtual {v0, v1}, Landroidx/fragment/app/FragmentTransaction;->remove(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/FragmentTransaction;

    const/high16 v1, 0x10b0000

    const v2, 0x10b0001

    .line 454
    invoke-virtual {v0, v1, v2}, Landroidx/fragment/app/FragmentTransaction;->setCustomAnimations(II)Landroidx/fragment/app/FragmentTransaction;

    .line 455
    invoke-virtual {v0}, Landroidx/fragment/app/FragmentTransaction;->commitAllowingStateLoss()I

    .line 458
    :cond_0
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->requestFocus()Z

    return-void
.end method

.method private hideKeyboard(Landroid/widget/EditText;)V
    .locals 2

    .line 348
    invoke-virtual {p1}, Landroid/widget/EditText;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "input_method"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/inputmethod/InputMethodManager;

    if-eqz v0, :cond_0

    .line 350
    invoke-virtual {p1}, Landroid/widget/EditText;->getWindowToken()Landroid/os/IBinder;

    move-result-object p1

    const/4 v1, 0x0

    invoke-virtual {v0, p1, v1}, Landroid/view/inputmethod/InputMethodManager;->hideSoftInputFromWindow(Landroid/os/IBinder;I)Z

    :cond_0
    return-void
.end method

.method private hideNativePlayer()V
    .locals 3

    .line 494
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->isAdded()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 495
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getView()Landroid/view/View;

    move-result-object v0

    const v1, 0x7f0800b0

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 496
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const-string v1, "player"

    .line 497
    invoke-virtual {v0, v1}, Landroidx/fragment/app/FragmentManager;->findFragmentByTag(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v1

    if-eqz v1, :cond_0

    .line 499
    invoke-virtual {v0}, Landroidx/fragment/app/FragmentManager;->beginTransaction()Landroidx/fragment/app/FragmentTransaction;

    move-result-object v0

    .line 500
    invoke-virtual {v0, v1}, Landroidx/fragment/app/FragmentTransaction;->remove(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/FragmentTransaction;

    const/high16 v1, 0x10b0000

    const v2, 0x10b0001

    .line 501
    invoke-virtual {v0, v1, v2}, Landroidx/fragment/app/FragmentTransaction;->setCustomAnimations(II)Landroidx/fragment/app/FragmentTransaction;

    .line 502
    invoke-virtual {v0}, Landroidx/fragment/app/FragmentTransaction;->commitAllowingStateLoss()I

    .line 505
    :cond_0
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->requestFocus()Z

    return-void
.end method

.method private isReadExternalFilesGranted()Z
    .locals 2

    .line 392
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "android.permission.READ_EXTERNAL_STORAGE"

    invoke-static {v0, v1}, Landroidx/core/content/ContextCompat;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private onDone(Landroid/widget/EditText;Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;)V
    .locals 2

    .line 355
    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    .line 356
    invoke-static {p1}, Landroid/webkit/URLUtil;->isValidUrl(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 359
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "http://"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 360
    invoke-static {p1}, Landroid/webkit/URLUtil;->isValidUrl(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 361
    invoke-virtual {p2, p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->loadUrl(Ljava/lang/String;)V

    goto :goto_0

    .line 364
    :cond_0
    invoke-virtual {p2, p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->loadUrl(Ljava/lang/String;)V

    :cond_1
    :goto_0
    return-void
.end method

.method private showBookmarksScreen()V
    .locals 4

    .line 462
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->isAdded()Z

    move-result v0

    if-eqz v0, :cond_1

    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getView()Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_1

    .line 463
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getView()Landroid/view/View;

    move-result-object v0

    const v1, 0x7f0800b0

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 464
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getChildFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const-string v2, "bookmarks"

    .line 465
    invoke-virtual {v0, v2}, Landroidx/fragment/app/FragmentManager;->findFragmentByTag(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v3

    check-cast v3, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;

    if-nez v3, :cond_0

    .line 467
    new-instance v3, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;

    invoke-direct {v3}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;-><init>()V

    .line 469
    :cond_0
    invoke-virtual {v0}, Landroidx/fragment/app/FragmentManager;->beginTransaction()Landroidx/fragment/app/FragmentTransaction;

    move-result-object v0

    .line 470
    invoke-virtual {v0, v1, v3, v2}, Landroidx/fragment/app/FragmentTransaction;->replace(ILandroidx/fragment/app/Fragment;Ljava/lang/String;)Landroidx/fragment/app/FragmentTransaction;

    const/high16 v1, 0x10b0000

    const v2, 0x10b0001

    .line 471
    invoke-virtual {v0, v1, v2}, Landroidx/fragment/app/FragmentTransaction;->setCustomAnimations(II)Landroidx/fragment/app/FragmentTransaction;

    .line 472
    invoke-virtual {v0}, Landroidx/fragment/app/FragmentTransaction;->commitAllowingStateLoss()I

    :cond_1
    return-void
.end method

.method private showNativePlayer(Ljava/lang/String;)V
    .locals 3

    .line 478
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->isAdded()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 479
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getView()Landroid/view/View;

    move-result-object v0

    const v1, 0x7f0800b0

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 480
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const-string v1, "player"

    .line 481
    invoke-virtual {v0, v1}, Landroidx/fragment/app/FragmentManager;->findFragmentByTag(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v2

    check-cast v2, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;

    if-nez v2, :cond_0

    .line 483
    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->newInstance(Ljava/lang/String;)Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;

    move-result-object v2

    .line 485
    :cond_0
    invoke-virtual {v0}, Landroidx/fragment/app/FragmentManager;->beginTransaction()Landroidx/fragment/app/FragmentTransaction;

    move-result-object p1

    const v0, 0x7f080067

    .line 486
    invoke-virtual {p1, v0, v2, v1}, Landroidx/fragment/app/FragmentTransaction;->replace(ILandroidx/fragment/app/Fragment;Ljava/lang/String;)Landroidx/fragment/app/FragmentTransaction;

    const-string v0, "native"

    .line 487
    invoke-virtual {p1, v0}, Landroidx/fragment/app/FragmentTransaction;->addToBackStack(Ljava/lang/String;)Landroidx/fragment/app/FragmentTransaction;

    const/high16 v0, 0x10b0000

    const v1, 0x10b0001

    .line 488
    invoke-virtual {p1, v0, v1}, Landroidx/fragment/app/FragmentTransaction;->setCustomAnimations(II)Landroidx/fragment/app/FragmentTransaction;

    .line 489
    invoke-virtual {p1}, Landroidx/fragment/app/FragmentTransaction;->commitAllowingStateLoss()I

    :cond_1
    return-void
.end method

.method private unlock()V
    .locals 8

    const-string v0, "\", 1);"

    const-string v1, "Error in executing commands : "

    .line 180
    invoke-static {}, Leu/chainfire/libsuperuser/Shell$SU;->available()Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v2, :cond_3

    .line 182
    :try_start_0
    sget-object v2, Leu/chainfire/libsuperuser/Shell$Pool;->SU:Leu/chainfire/libsuperuser/Shell$PoolWrapper;

    const-string v4, "pm disable --user 0 com.google.android.gms/.phenotype.service.sync.PhenotypeConfigurator"

    invoke-virtual {v2, v4}, Leu/chainfire/libsuperuser/Shell$PoolWrapper;->run(Ljava/lang/Object;)I

    .line 183
    sget-object v2, Leu/chainfire/libsuperuser/Shell$Pool;->SU:Leu/chainfire/libsuperuser/Shell$PoolWrapper;

    const-string v4, "pm disable --user 0 com.google.android.gms/.phenotype.service.PhenotypeService"

    invoke-virtual {v2, v4}, Leu/chainfire/libsuperuser/Shell$PoolWrapper;->run(Ljava/lang/Object;)I

    .line 184
    sget-object v2, Leu/chainfire/libsuperuser/Shell$Pool;->SU:Leu/chainfire/libsuperuser/Shell$PoolWrapper;

    const-string v4, "chmod 777 /data/data/com.google.android.gms/databases/phenotype.db*"

    invoke-virtual {v2, v4}, Leu/chainfire/libsuperuser/Shell$PoolWrapper;->run(Ljava/lang/Object;)I

    const-string v2, "/data/data/com.google.android.gms/databases/phenotype.db"

    const/4 v4, 0x0

    const/4 v5, 0x0

    .line 185
    invoke-static {v2, v4, v5}, Landroid/database/sqlite/SQLiteDatabase;->openDatabase(Ljava/lang/String;Landroid/database/sqlite/SQLiteDatabase$CursorFactory;I)Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v2

    if-eqz v2, :cond_2

    const-string v4, "SELECT stringVal FROM Flags WHERE packageName=? AND name=?;"

    const/4 v6, 0x2

    new-array v6, v6, [Ljava/lang/String;

    const-string v7, "com.google.android.gms.car"

    aput-object v7, v6, v5

    const-string v5, "app_white_list"

    aput-object v5, v6, v3

    .line 187
    invoke-virtual {v2, v4, v6}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v4

    .line 188
    new-instance v5, Ljava/util/HashSet;

    invoke-direct {v5}, Ljava/util/HashSet;-><init>()V

    .line 189
    invoke-interface {v4}, Landroid/database/Cursor;->getCount()I

    move-result v6

    if-lez v6, :cond_1

    .line 190
    :cond_0
    :goto_0
    invoke-interface {v4}, Landroid/database/Cursor;->moveToNext()Z

    move-result v6

    if-eqz v6, :cond_1

    const-string v6, "stringVal"

    .line 191
    invoke-interface {v4, v6}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v6

    invoke-interface {v4, v6}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v6

    if-eqz v6, :cond_0

    .line 193
    invoke-virtual {v5, v6}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 197
    :cond_1
    invoke-interface {v4}, Landroid/database/Cursor;->close()V

    .line 198
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/fragment/app/FragmentActivity;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v5, v4}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    const-string v4, "DELETE FROM Flags WHERE packageName=\"com.google.android.gms.car\" AND name=\"app_white_list\";"

    .line 199
    invoke-virtual {v2, v4}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    const-string v4, ","

    .line 200
    invoke-static {v4, v5}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v4

    .line 201
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "INSERT INTO Flags (packageName, version, flagType, partitionId, user, name, stringVal, committed) VALUES (\"com.google.android.gms.car\", 209, 0, 0, \"\", \"app_white_list\", \""

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 202
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "INSERT INTO Flags (packageName, version, flagType, partitionId, user, name, stringVal, committed) VALUES (\"com.google.android.gms.car\", 224, 0, 0, \"\", \"app_white_list\", \""

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    .line 203
    invoke-virtual {v2}, Landroid/database/sqlite/SQLiteDatabase;->close()V

    .line 204
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const-string v2, "Successfully unlocked. Reboot phone and connect to Android Auto"

    invoke-static {v0, v2, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catch Leu/chainfire/libsuperuser/Shell$ShellDiedException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception v0

    .line 212
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "sql exception : "

    .line 213
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 214
    invoke-virtual {v0}, Ljava/lang/Exception;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 215
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    goto :goto_1

    :catch_1
    move-exception v0

    .line 207
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "shellException : "

    .line 208
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 209
    invoke-virtual {v0}, Leu/chainfire/libsuperuser/Shell$ShellDiedException;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 210
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :cond_2
    :goto_1
    const-string v0, "chmod 660 /data/data/com.google.android.gms/databases/phenotype.db*"

    .line 217
    invoke-static {v0}, Leu/chainfire/libsuperuser/Shell$SU;->run(Ljava/lang/String;)Ljava/util/List;

    return-void

    .line 220
    :cond_3
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const-string v1, "Root not available, install SuperSU and perform root first."

    invoke-static {v0, v1, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method


# virtual methods
.method public askForRecordAudioPermission()V
    .locals 5

    .line 397
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const-string v1, "android.permission.RECORD_AUDIO"

    invoke-static {v0, v1}, Landroidx/core/app/ActivityCompat;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    if-eqz v0, :cond_1

    .line 398
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    invoke-static {v0, v1}, Landroidx/core/app/ActivityCompat;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 400
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v1, "Need Microphone Permission"

    .line 401
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    const-string v1, "To use voice input feature in your car, you need to grant permissions. With voice input, you can search on Youtube with your voice. \nFor e.g., say \'Coldplay\' and it will search for Coldplay on Youtube"

    .line 402
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 403
    new-instance v1, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$5;

    invoke-direct {v1, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$5;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)V

    const-string v2, "Grant"

    invoke-virtual {v0, v2, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 410
    new-instance v1, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$6;

    invoke-direct {v1, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$6;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)V

    const-string v2, "Cancel"

    invoke-virtual {v0, v2, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 416
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    goto :goto_0

    .line 419
    :cond_0
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v2, 0x1

    new-array v3, v2, [Ljava/lang/String;

    const/4 v4, 0x0

    aput-object v1, v3, v4

    invoke-static {v0, v3, v2}, Landroidx/core/app/ActivityCompat;->requestPermissions(Landroid/app/Activity;[Ljava/lang/String;I)V

    :cond_1
    :goto_0
    return-void
.end method

.method public getAspectRatio()Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public onAttach(Landroid/app/Activity;)V
    .locals 0

    .line 115
    invoke-super {p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;->onAttach(Landroid/app/Activity;)V

    return-void
.end method

.method public onAttach(Landroid/content/Context;)V
    .locals 0

    .line 109
    invoke-super {p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;->onAttach(Landroid/content/Context;)V

    return-void
.end method

.method public onBookmarkAddCurrentPage()V
    .locals 1

    .line 433
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils;->addBookmark(Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;)V

    return-void
.end method

.method public onBookmarkDelete(Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V
    .locals 0

    .line 438
    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils;->deleteBookmark(Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V

    return-void
.end method

.method public onBookmarkFragmentClose()V
    .locals 0

    .line 443
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->hideBookmarksScreen()V

    return-void
.end method

.method public onBookmarkSelected(Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V
    .locals 1

    .line 428
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->getUrl()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 0

    .line 101
    invoke-super {p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;->onCreate(Landroid/os/Bundle;)V

    const/4 p1, 0x1

    .line 102
    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->setHasOptionsMenu(Z)V

    .line 103
    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->setRetainInstance(Z)V

    return-void
.end method

.method public onCreateOptionsMenu(Landroid/view/Menu;Landroid/view/MenuInflater;)V
    .locals 1

    .line 150
    invoke-super {p0, p1, p2}, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;->onCreateOptionsMenu(Landroid/view/Menu;Landroid/view/MenuInflater;)V

    const/high16 v0, 0x7f0c0000

    .line 151
    invoke-virtual {p2, v0, p1}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    const p2, 0x7f080046

    .line 152
    invoke-interface {p1, p2}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    move-result-object p1

    .line 153
    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const v0, 0x7f1000af

    invoke-virtual {p0, v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " v"

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "2.0.5"

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-interface {p1, p2}, Landroid/view/MenuItem;->setTitle(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    const/4 p2, 0x0

    .line 154
    invoke-interface {p1, p2}, Landroid/view/MenuItem;->setEnabled(Z)Landroid/view/MenuItem;

    return-void
.end method

.method public onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .locals 1

    const p3, 0x7f0b0042

    const/4 v0, 0x0

    .line 145
    invoke-virtual {p1, p3, p2, v0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    return-object p1
.end method

.method public onNativePlayerControlsVisibilityChange(I)V
    .locals 0

    return-void
.end method

.method public onOptionsItemSelected(Landroid/view/MenuItem;)Z
    .locals 3

    .line 159
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v0

    const v1, 0x7f08000a

    if-ne v0, v1, :cond_0

    .line 161
    new-instance p1, Landroid/content/Intent;

    const-string v0, "android.intent.action.VIEW"

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v0, "http://www.thekirankumar.com/blog/2017/12/29/play-youtube-video-android-auto-app/?from_app=true"

    .line 162
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 163
    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->startActivity(Landroid/content/Intent;)V

    const/4 p1, 0x1

    return p1

    .line 165
    :cond_0
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v0

    const v1, 0x7f08004b

    if-ne v0, v1, :cond_1

    .line 166
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->goBack()V

    goto :goto_0

    .line 167
    :cond_1
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v0

    const v1, 0x7f080111

    if-ne v0, v1, :cond_2

    .line 168
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->reload()V

    goto :goto_0

    .line 169
    :cond_2
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v0

    const v1, 0x7f080050

    if-ne v0, v1, :cond_3

    .line 170
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->showBookmarksScreen()V

    goto :goto_0

    .line 171
    :cond_3
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v0

    const v1, 0x7f080130

    if-ne v0, v1, :cond_4

    .line 172
    new-instance v0, Landroid/content/Intent;

    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getContext()Landroid/content/Context;

    move-result-object v1

    const-class v2, Lcom/thekirankumar/youtubeauto2/activity/SettingsPhoneActivity;

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    invoke-virtual {p0, v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->startActivity(Landroid/content/Intent;)V

    goto :goto_0

    .line 173
    :cond_4
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result v0

    const v1, 0x7f080175

    if-ne v0, v1, :cond_5

    .line 174
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->unlock()V

    .line 176
    :cond_5
    :goto_0
    invoke-super {p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;->onOptionsItemSelected(Landroid/view/MenuItem;)Z

    move-result p1

    return p1
.end method

.method public onResume()V
    .locals 1

    .line 370
    invoke-super {p0}, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;->onResume()V

    .line 371
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->requestFocus()Z

    .line 372
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->askForRecordAudioPermission()V

    .line 373
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->handleExternalSdCard()V

    return-void
.end method

.method public onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
    .locals 4

    .line 226
    invoke-super {p0, p1, p2}, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V

    const p2, 0x7f08010b

    .line 227
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/ProgressBar;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->progressBar:Landroid/widget/ProgressBar;

    const p2, 0x7f08017c

    .line 228
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    const p2, 0x7f080080

    .line 229
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/EditText;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->editText:Landroid/widget/EditText;

    .line 230
    new-instance p2, Landroid/content/Intent;

    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const-class v1, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;

    invoke-direct {p2, v0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 231
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    invoke-virtual {v0, p2}, Landroidx/fragment/app/FragmentActivity;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 233
    new-instance p2, Landroid/support/v4/media/MediaBrowserCompat;

    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    new-instance v1, Landroid/content/ComponentName;

    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v2

    const-class v3, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;

    invoke-direct {v1, v2, v3}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    new-instance v2, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$1;

    invoke-direct {v2, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$1;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)V

    const/4 v3, 0x0

    invoke-direct {p2, v0, v1, v2, v3}, Landroid/support/v4/media/MediaBrowserCompat;-><init>(Landroid/content/Context;Landroid/content/ComponentName;Landroid/support/v4/media/MediaBrowserCompat$ConnectionCallback;Landroid/os/Bundle;)V

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->mediaBrowser:Landroid/support/v4/media/MediaBrowserCompat;

    .line 265
    invoke-virtual {p2}, Landroid/support/v4/media/MediaBrowserCompat;->connect()V

    const p2, 0x7f080067

    .line 266
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/view/ViewGroup;

    const v0, 0x7f0800b0

    .line 267
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/view/ViewGroup;

    .line 268
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    new-instance v1, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$2;

    invoke-direct {v1, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$2;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)V

    invoke-virtual {v0, v1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    .line 286
    new-instance v0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;

    new-instance v1, Landroid/widget/ProgressBar;

    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/widget/ProgressBar;-><init>(Landroid/content/Context;)V

    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-direct {v0, p2, p1, v1, v2}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;-><init>(Landroid/view/View;Landroid/view/ViewGroup;Landroid/view/View;Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;)V

    .line 287
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {p1, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->setWebChromeClient(Landroid/webkit/WebChromeClient;)V

    .line 288
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object p1

    const/4 p2, 0x1

    invoke-virtual {p1, p2}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    .line 289
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object p1

    invoke-virtual {p1, p2}, Landroid/webkit/WebSettings;->setAllowFileAccess(Z)V

    .line 290
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object p1

    invoke-virtual {p1, p2}, Landroid/webkit/WebSettings;->setDomStorageEnabled(Z)V

    .line 291
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p1

    .line 292
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    const/4 v1, 0x0

    const-string v2, "pref_enable_desktop_mode"

    invoke-interface {p1, v2, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p1

    invoke-static {v0, p1}, Lcom/thekirankumar/youtubeauto2/utils/WebviewUtils;->setDesktopMode(Landroid/webkit/WebView;Z)V

    .line 293
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x10

    if-lt p1, v0, :cond_0

    .line 294
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object p1

    invoke-virtual {p1, p2}, Landroid/webkit/WebSettings;->setAllowUniversalAccessFromFileURLs(Z)V

    .line 296
    :cond_0
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt p1, v0, :cond_1

    .line 297
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object p1

    invoke-virtual {p1, p2}, Landroid/webkit/WebSettings;->setAllowFileAccessFromFileURLs(Z)V

    .line 299
    :cond_1
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x11

    if-lt p1, v0, :cond_2

    .line 300
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object p1

    invoke-virtual {p1, v1}, Landroid/webkit/WebSettings;->setMediaPlaybackRequiresUserGesture(Z)V

    .line 302
    :cond_2
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object p1

    invoke-virtual {p1, p2}, Landroid/webkit/WebSettings;->setAllowContentAccess(Z)V

    .line 308
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getSharedPrefs()Landroid/content/SharedPreferences;

    move-result-object p1

    const-string p2, "home_url"

    const-string v0, "https://www.youtube.com"

    invoke-interface {p1, p2, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 309
    iget-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {p2, p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->loadUrl(Ljava/lang/String;)V

    .line 310
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->requestFocus()Z

    .line 311
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    new-instance p2, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$3;

    invoke-direct {p2, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$3;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)V

    invoke-virtual {p1, p2}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 328
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->editText:Landroid/widget/EditText;

    new-instance p2, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$4;

    invoke-direct {p2, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$4;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)V

    invoke-virtual {p1, p2}, Landroid/widget/EditText;->setOnEditorActionListener(Landroid/widget/TextView$OnEditorActionListener;)V

    return-void
.end method

.method public requestPermissionForReadExtertalStorage()V
    .locals 4

    .line 384
    :try_start_0
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    const/4 v1, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v2, 0x0

    const-string v3, "android.permission.READ_EXTERNAL_STORAGE"

    aput-object v3, v1, v2

    const/16 v2, 0xa

    invoke-static {v0, v1, v2}, Landroidx/core/app/ActivityCompat;->requestPermissions(Landroid/app/Activity;[Ljava/lang/String;I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .line 387
    invoke-virtual {v0}, Ljava/lang/Exception;->printStackTrace()V

    :goto_0
    return-void
.end method
