.class Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$1;
.super Ljava/lang/Object;
.source "SafetyWarningFragment.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;)V
    .locals 0

    .line 38
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$1;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1

    .line 41
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$1;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;->access$000(Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;)Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$FragmentInteractionListener;

    move-result-object p1

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$1;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;

    invoke-interface {p1, v0}, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$FragmentInteractionListener;->onReadyToExitSafetyInstructions(Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;)V

    return-void
.end method
