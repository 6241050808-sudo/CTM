.class public Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;
.super Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;
.source "WebViewCarFragment.java"

# interfaces
.implements Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity$ActivityCallbacks;
.implements Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$JSCallbacks;
.implements Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$FragmentInteractionListener;
.implements Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;
.implements Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$OnFragmentInteractionListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$CustomWebViewClient;,
        Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;
    }
.end annotation


# static fields
.field private static final ASPECT_RATIO_KEY:Ljava/lang/String; = "aspect_ratio"

.field public static final AUTOSUGGEST_DEBOUNCE_DELAY_MILLIS:I = 0x1f4

.field public static final BOOKMARKS_FRAGMENT_TAG:Ljava/lang/String; = "bookmarks"

.field private static final FULLSCREEN_KEY:Ljava/lang/String; = "fullscreen"

.field public static final GOOGLE_AUTOSUGGEST_URL_BASE:Ljava/lang/String; = "http://suggestqueries.google.com/complete/search?client=chrome&q="

.field public static final GOOGLE_SEARCH_URL_BASE:Ljava/lang/String; = "https://www.google.com/#q="

.field public static final HOME_URL:Ljava/lang/String; = "home_url"

.field public static final JAVASCRIPT_INTERFACE:Ljava/lang/String; = "nativecallbacks"

.field private static final PLAYER_FRAGMENT_TAG:Ljava/lang/String; = "player"

.field public static final PREFS:Ljava/lang/String; = "car"

.field public static final SAFETY_WARNING_FRAGMENT_TAG:Ljava/lang/String; = "safety"

.field private static final TAG:Ljava/lang/String; = "WebViewCarFragment"

.field public static final YOUTUBE_AUTOSUGGEST_URL_BASE:Ljava/lang/String; = "http://suggestqueries.google.com/complete/search?client=firefox&ds=yt&q="

.field public static final YOUTUBE_HOME_URL_BASE:Ljava/lang/String; = "https://www.youtube.com"

.field public static final YOUTUBE_OFFLINE_URL_BASE:Ljava/lang/String;

.field public static final YOUTUBE_SEARCH_URL_BASE:Ljava/lang/String; = "https://www.youtube.com/results?search_query="


# instance fields
.field private aspectButton:Landroid/widget/Button;

.field private car:Landroid/support/car/Car;

.field private carSpeedView:Landroid/widget/TextView;

.field private clickFirstVideoAfterPageLoad:Z

.field private cornerControls:Landroid/view/View;

.field private cornerControlsHideRunnable:Ljava/lang/Runnable;

.field private currentAspectRatio:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

.field private currentVideoTime:Ljava/lang/Integer;

.field private fakeEditText:Lcom/thekirankumar/youtubeauto2/utils/CarEditText;

.field private fullScreenRequested:Z

.field private handler:Landroid/os/Handler;

.field private handlerThread:Landroid/os/HandlerThread;

.field private isNightMode:Z

.field private isParkingEngaged:Z

.field private isSearchShown:Z

.field private final mCarConnectionCallback:Landroid/support/car/CarConnectionCallback;

.field private final mSensorsListener:Landroid/support/car/hardware/CarSensorManager$OnSensorChangedListener;

.field private mediaBrowser:Landroid/support/v4/media/MediaBrowserCompat;

.field private mediaController:Landroid/support/v4/media/session/MediaControllerCompat;

.field private mediaSessionCompat:Landroid/support/v4/media/session/MediaSessionCompat;

.field private nativePlayerActive:Z

.field private nativePlayerFragment:Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;

.field private playerState:I

.field private progressBar:Landroid/widget/ProgressBar;

.field private searchMode:Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

.field private searchRunnable:Ljava/lang/Runnable;

.field private sensorManager:Landroid/support/car/hardware/CarSensorManager;

.field private sharedPrefs:Landroid/content/SharedPreferences;

.field private speechRecognizer:Landroid/speech/SpeechRecognizer;

.field private speechRecognizerIntent:Landroid/content/Intent;

.field private toolbar:Landroid/view/View;

.field private toolbarHideRunnable:Ljava/lang/Runnable;

.field private warningAccepted:Z

.field private warningScreenOpen:Z

.field private webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 109
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "file:///"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v1}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "/"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->YOUTUBE_OFFLINE_URL_BASE:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 264
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;-><init>()V

    const/4 v0, 0x0

    .line 128
    iput-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->isSearchShown:Z

    .line 134
    sget-object v0, Lcom/thekirankumar/youtubeauto2/utils/SearchMode;->YOUTUBE:Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->searchMode:Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    .line 140
    new-instance v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$1;

    invoke-direct {v0, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$1;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toolbarHideRunnable:Ljava/lang/Runnable;

    const/4 v0, 0x1

    .line 146
    iput-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->isNightMode:Z

    .line 149
    iput-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->warningAccepted:Z

    .line 154
    new-instance v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$2;

    invoke-direct {v0, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$2;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->cornerControlsHideRunnable:Ljava/lang/Runnable;

    const/4 v0, 0x2

    .line 161
    iput v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->playerState:I

    .line 163
    new-instance v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$3;

    invoke-direct {v0, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$3;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->mSensorsListener:Landroid/support/car/hardware/CarSensorManager$OnSensorChangedListener;

    .line 189
    new-instance v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;

    invoke-direct {v0, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->mCarConnectionCallback:Landroid/support/car/CarConnectionCallback;

    return-void
.end method

.method static synthetic access$000(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V
    .locals 0

    .line 107
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->hideToolbar()V

    return-void
.end method

.method static synthetic access$100(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Z)V
    .locals 0

    .line 107
    invoke-direct {p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->hideCornerControls(Z)V

    return-void
.end method

.method static synthetic access$1000(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Z
    .locals 0

    .line 107
    iget-boolean p0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->clickFirstVideoAfterPageLoad:Z

    return p0
.end method

.method static synthetic access$1002(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Z)Z
    .locals 0

    .line 107
    iput-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->clickFirstVideoAfterPageLoad:Z

    return p1
.end method

.method static synthetic access$1100(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Ljava/lang/String;)V
    .locals 0

    .line 107
    invoke-direct {p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->search(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$1200(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Z
    .locals 0

    .line 107
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->goBack()Z

    move-result p0

    return p0
.end method

.method static synthetic access$1300(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V
    .locals 0

    .line 107
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toggleAspectRatio()V

    return-void
.end method

.method static synthetic access$1400(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V
    .locals 0

    .line 107
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->showAndHideCornerControlsAnimation()V

    return-void
.end method

.method static synthetic access$1500(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V
    .locals 0

    .line 107
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->showAndHideToolbarAnimation()V

    return-void
.end method

.method static synthetic access$1600(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/speech/SpeechRecognizer;
    .locals 0

    .line 107
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->speechRecognizer:Landroid/speech/SpeechRecognizer;

    return-object p0
.end method

.method static synthetic access$1602(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Landroid/speech/SpeechRecognizer;)Landroid/speech/SpeechRecognizer;
    .locals 0

    .line 107
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->speechRecognizer:Landroid/speech/SpeechRecognizer;

    return-object p1
.end method

.method static synthetic access$1700(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/content/Intent;
    .locals 0

    .line 107
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->speechRecognizerIntent:Landroid/content/Intent;

    return-object p0
.end method

.method static synthetic access$1702(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Landroid/content/Intent;)Landroid/content/Intent;
    .locals 0

    .line 107
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->speechRecognizerIntent:Landroid/content/Intent;

    return-object p1
.end method

.method static synthetic access$1800(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Z
    .locals 0

    .line 107
    iget-boolean p0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->fullScreenRequested:Z

    return p0
.end method

.method static synthetic access$1802(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Z)Z
    .locals 0

    .line 107
    iput-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->fullScreenRequested:Z

    return p1
.end method

.method static synthetic access$1900(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Z
    .locals 0

    .line 107
    iget-boolean p0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->isSearchShown:Z

    return p0
.end method

.method static synthetic access$1902(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Z)Z
    .locals 0

    .line 107
    iput-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->isSearchShown:Z

    return p1
.end method

.method static synthetic access$200(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/widget/TextView;
    .locals 0

    .line 107
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->carSpeedView:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$2000(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Lcom/thekirankumar/youtubeauto2/utils/SearchMode;
    .locals 0

    .line 107
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->searchMode:Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    return-object p0
.end method

.method static synthetic access$2002(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Lcom/thekirankumar/youtubeauto2/utils/SearchMode;)Lcom/thekirankumar/youtubeauto2/utils/SearchMode;
    .locals 0

    .line 107
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->searchMode:Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    return-object p1
.end method

.method static synthetic access$2100(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V
    .locals 0

    .line 107
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->showBookmarksScreen()V

    return-void
.end method

.method static synthetic access$2300(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/content/SharedPreferences;
    .locals 0

    .line 107
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getSharedPrefs()Landroid/content/SharedPreferences;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$2400(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Ljava/lang/Runnable;
    .locals 0

    .line 107
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->searchRunnable:Ljava/lang/Runnable;

    return-object p0
.end method

.method static synthetic access$2402(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Ljava/lang/Runnable;)Ljava/lang/Runnable;
    .locals 0

    .line 107
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->searchRunnable:Ljava/lang/Runnable;

    return-object p1
.end method

.method static synthetic access$2500(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/os/Handler;
    .locals 0

    .line 107
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->handler:Landroid/os/Handler;

    return-object p0
.end method

.method static synthetic access$2600(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V
    .locals 0

    .line 107
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->showToolbar()V

    return-void
.end method

.method static synthetic access$2700(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V
    .locals 0

    .line 107
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toggleToolbarAnimation()V

    return-void
.end method

.method static synthetic access$2800(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V
    .locals 0

    .line 107
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toggleCornerControlsAnimation()V

    return-void
.end method

.method static synthetic access$2900(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/widget/ProgressBar;
    .locals 0

    .line 107
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->progressBar:Landroid/widget/ProgressBar;

    return-object p0
.end method

.method static synthetic access$3000(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Z
    .locals 0

    .line 107
    iget-boolean p0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->warningScreenOpen:Z

    return p0
.end method

.method static synthetic access$302(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Landroid/support/car/hardware/CarSensorManager;)Landroid/support/car/hardware/CarSensorManager;
    .locals 0

    .line 107
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->sensorManager:Landroid/support/car/hardware/CarSensorManager;

    return-object p1
.end method

.method static synthetic access$3100(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V
    .locals 0

    .line 107
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->showCornerControls()V

    return-void
.end method

.method static synthetic access$3200(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/view/View;
    .locals 0

    .line 107
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->cornerControls:Landroid/view/View;

    return-object p0
.end method

.method static synthetic access$3300(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)I
    .locals 0

    .line 107
    iget p0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->playerState:I

    return p0
.end method

.method static synthetic access$3400(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Z
    .locals 0

    .line 107
    iget-boolean p0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->nativePlayerActive:Z

    return p0
.end method

.method static synthetic access$3500(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V
    .locals 0

    .line 107
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->hideNativePlayer()V

    return-void
.end method

.method static synthetic access$3600(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Ljava/lang/String;)V
    .locals 0

    .line 107
    invoke-direct {p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->showNativePlayer(Ljava/lang/String;)V

    return-void
.end method

.method static synthetic access$402(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Landroid/support/car/Car;)Landroid/support/car/Car;
    .locals 0

    .line 107
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->car:Landroid/support/car/Car;

    return-object p1
.end method

.method static synthetic access$500(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V
    .locals 0

    .line 107
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->gainAudioFocus()V

    return-void
.end method

.method static synthetic access$600(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/support/car/hardware/CarSensorManager$OnSensorChangedListener;
    .locals 0

    .line 107
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->mSensorsListener:Landroid/support/car/hardware/CarSensorManager$OnSensorChangedListener;

    return-object p0
.end method

.method static synthetic access$700(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/support/v4/media/MediaBrowserCompat;
    .locals 0

    .line 107
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->mediaBrowser:Landroid/support/v4/media/MediaBrowserCompat;

    return-object p0
.end method

.method static synthetic access$702(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Landroid/support/v4/media/MediaBrowserCompat;)Landroid/support/v4/media/MediaBrowserCompat;
    .locals 0

    .line 107
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->mediaBrowser:Landroid/support/v4/media/MediaBrowserCompat;

    return-object p1
.end method

.method static synthetic access$802(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Landroid/support/v4/media/session/MediaControllerCompat;)Landroid/support/v4/media/session/MediaControllerCompat;
    .locals 0

    .line 107
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->mediaController:Landroid/support/v4/media/session/MediaControllerCompat;

    return-object p1
.end method

.method static synthetic access$900(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;
    .locals 0

    .line 107
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    return-object p0
.end method

.method private gainAudioFocus()V
    .locals 5

    .line 897
    :try_start_0
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->car:Landroid/support/car/Car;

    const-class v1, Landroid/support/car/media/CarAudioManager;

    invoke-virtual {v0, v1}, Landroid/support/car/Car;->getCarManager(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/car/media/CarAudioManager;

    const/4 v1, 0x1

    .line 898
    invoke-virtual {v0, v1}, Landroid/support/car/media/CarAudioManager;->getAudioAttributesForCarUsage(I)Landroid/media/AudioAttributes;

    move-result-object v2

    const/4 v3, 0x0

    const/4 v4, 0x0

    .line 900
    invoke-virtual {v0, v3, v2, v1, v4}, Landroid/support/car/media/CarAudioManager;->requestAudioFocus(Landroid/media/AudioManager$OnAudioFocusChangeListener;Landroid/media/AudioAttributes;II)I
    :try_end_0
    .catch Landroid/support/car/CarNotConnectedException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .line 903
    invoke-virtual {v0}, Landroid/support/car/CarNotConnectedException;->printStackTrace()V

    :goto_0
    return-void
.end method

.method private getHumanText(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;)Ljava/lang/String;
    .locals 1

    .line 1168
    sget-object v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$27;->$SwitchMap$com$thekirankumar$youtubeauto2$fragments$WebViewCarFragment$AspectRatio:[I

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;->ordinal()I

    move-result p1

    aget p1, v0, p1

    const/4 v0, 0x1

    if-eq p1, v0, :cond_2

    const/4 v0, 0x2

    if-eq p1, v0, :cond_1

    const/4 v0, 0x3

    if-eq p1, v0, :cond_0

    const-string p1, ""

    return-object p1

    :cond_0
    const p1, 0x7f100020

    .line 1174
    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getString(I)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_1
    const p1, 0x7f100021

    .line 1172
    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getString(I)Ljava/lang/String;

    move-result-object p1

    return-object p1

    :cond_2
    const p1, 0x7f100022

    .line 1170
    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getString(I)Ljava/lang/String;

    move-result-object p1

    return-object p1
.end method

.method private getSearchUrlBase()Ljava/lang/String;
    .locals 2

    .line 849
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->searchMode:Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    sget-object v1, Lcom/thekirankumar/youtubeauto2/utils/SearchMode;->YOUTUBE:Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    if-ne v0, v1, :cond_0

    const-string v0, "https://www.youtube.com/results?search_query="

    return-object v0

    .line 851
    :cond_0
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->searchMode:Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    sget-object v1, Lcom/thekirankumar/youtubeauto2/utils/SearchMode;->GOOGLE:Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    if-ne v0, v1, :cond_1

    const-string v0, "https://www.google.com/#q="

    return-object v0

    :cond_1
    const/4 v0, 0x0

    return-object v0
.end method

.method private getSharedPrefs()Landroid/content/SharedPreferences;
    .locals 3

    .line 743
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->sharedPrefs:Landroid/content/SharedPreferences;

    if-eqz v0, :cond_0

    return-object v0

    .line 746
    :cond_0
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v1, 0x0

    const-string v2, "car"

    invoke-virtual {v0, v2, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->sharedPrefs:Landroid/content/SharedPreferences;

    return-object v0
.end method

.method private goBack()Z
    .locals 2

    .line 761
    iget-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->nativePlayerActive:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    .line 762
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->hideNativePlayer()V

    return v1

    .line 765
    :cond_0
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->isVideoFullscreen()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 766
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->exitFullScreen()V

    return v1

    .line 769
    :cond_1
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->canGoBack()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->hasFocus()Z

    move-result v0

    if-eqz v0, :cond_2

    .line 770
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->goBack()V

    return v1

    :cond_2
    const/4 v0, 0x0

    return v0
.end method

.method private handleVoiceVisibility()V
    .locals 2

    .line 921
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getView()Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_1

    .line 922
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getView()Landroid/view/View;

    move-result-object v0

    const v1, 0x7f08017b

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageButton;

    .line 923
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->isRecordAudioGranted()Z

    move-result v1

    if-nez v1, :cond_0

    const/16 v1, 0x8

    .line 924
    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setVisibility(I)V

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    .line 926
    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setVisibility(I)V

    :cond_1
    :goto_0
    return-void
.end method

.method private hideBookmarksScreen()V
    .locals 3

    .line 1097
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->isAdded()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 1098
    iget-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->nativePlayerActive:Z

    if-nez v0, :cond_0

    .line 1099
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->setVisibility(I)V

    .line 1100
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toolbar:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 1101
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->showToolbar()V

    .line 1103
    :cond_0
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getChildFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const-string v1, "bookmarks"

    .line 1104
    invoke-virtual {v0, v1}, Landroidx/fragment/app/FragmentManager;->findFragmentByTag(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v1

    if-eqz v1, :cond_1

    .line 1106
    invoke-virtual {v0}, Landroidx/fragment/app/FragmentManager;->beginTransaction()Landroidx/fragment/app/FragmentTransaction;

    move-result-object v0

    .line 1107
    invoke-virtual {v0, v1}, Landroidx/fragment/app/FragmentTransaction;->remove(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/FragmentTransaction;

    const/high16 v1, 0x10b0000

    const v2, 0x10b0001

    .line 1108
    invoke-virtual {v0, v1, v2}, Landroidx/fragment/app/FragmentTransaction;->setCustomAnimations(II)Landroidx/fragment/app/FragmentTransaction;

    .line 1109
    invoke-virtual {v0}, Landroidx/fragment/app/FragmentTransaction;->commitNow()V

    .line 1112
    :cond_1
    iget-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->nativePlayerActive:Z

    if-nez v0, :cond_2

    .line 1113
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->requestFocus()Z

    :cond_2
    return-void
.end method

.method private hideCornerControls(Z)V
    .locals 2

    .line 784
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->cornerControls:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->clearFocus()V

    if-eqz p1, :cond_0

    .line 786
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->cornerControls:Landroid/view/View;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 787
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->cornerControls:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->clearAnimation()V

    .line 788
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->cornerControls:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->getTranslationX()F

    move-result p1

    const/4 v0, 0x0

    cmpl-float p1, p1, v0

    if-nez p1, :cond_1

    .line 789
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->cornerControls:Landroid/view/View;

    invoke-virtual {p1}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    const-wide/16 v0, 0xc8

    invoke-virtual {p1, v0, v1}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object p1

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->cornerControls:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v0

    int-to-float v0, v0

    invoke-virtual {p1, v0}, Landroid/view/ViewPropertyAnimator;->translationX(F)Landroid/view/ViewPropertyAnimator;

    goto :goto_0

    .line 792
    :cond_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->cornerControls:Landroid/view/View;

    const/high16 v0, 0x43fa0000    # 500.0f

    invoke-virtual {p1, v0}, Landroid/view/View;->setTranslationX(F)V

    :cond_1
    :goto_0
    return-void
.end method

.method private hideNativePlayer()V
    .locals 3

    .line 1220
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->isAdded()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    .line 1221
    iput-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->nativePlayerActive:Z

    const/4 v1, 0x0

    .line 1222
    iput-object v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->nativePlayerFragment:Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;

    .line 1223
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v1, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->setVisibility(I)V

    .line 1224
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getView()Landroid/view/View;

    move-result-object v0

    const v1, 0x7f0800b0

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 1225
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getChildFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const-string v1, "player"

    .line 1226
    invoke-virtual {v0, v1}, Landroidx/fragment/app/FragmentManager;->findFragmentByTag(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v1

    if-eqz v1, :cond_0

    .line 1228
    invoke-virtual {v0}, Landroidx/fragment/app/FragmentManager;->beginTransaction()Landroidx/fragment/app/FragmentTransaction;

    move-result-object v0

    .line 1229
    invoke-virtual {v0, v1}, Landroidx/fragment/app/FragmentTransaction;->remove(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/FragmentTransaction;

    const/high16 v1, 0x10b0000

    const v2, 0x10b0001

    .line 1230
    invoke-virtual {v0, v1, v2}, Landroidx/fragment/app/FragmentTransaction;->setCustomAnimations(II)Landroidx/fragment/app/FragmentTransaction;

    .line 1231
    invoke-virtual {v0}, Landroidx/fragment/app/FragmentTransaction;->commitAllowingStateLoss()I

    .line 1234
    :cond_0
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->requestFocus()Z

    return-void
.end method

.method private hideToolbar()V
    .locals 3

    .line 777
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toolbar:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->clearAnimation()V

    .line 778
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toolbar:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getTranslationY()F

    move-result v0

    const/4 v1, 0x0

    cmpl-float v0, v0, v1

    if-nez v0, :cond_0

    .line 779
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toolbar:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const-wide/16 v1, 0xc8

    invoke-virtual {v0, v1, v2}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toolbar:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getMeasuredHeight()I

    move-result v1

    neg-int v1, v1

    int-to-float v1, v1

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->translationY(F)Landroid/view/ViewPropertyAnimator;

    :cond_0
    return-void
.end method

.method private hideWarningScreen()V
    .locals 3

    .line 1060
    iget-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->warningScreenOpen:Z

    if-eqz v0, :cond_1

    .line 1061
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->isAdded()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 1062
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->setVisibility(I)V

    .line 1063
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toolbar:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 1064
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getChildFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const-string v2, "safety"

    .line 1065
    invoke-virtual {v0, v2}, Landroidx/fragment/app/FragmentManager;->findFragmentByTag(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v2

    if-eqz v2, :cond_0

    .line 1067
    iput-boolean v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->warningScreenOpen:Z

    .line 1068
    invoke-virtual {v0}, Landroidx/fragment/app/FragmentManager;->beginTransaction()Landroidx/fragment/app/FragmentTransaction;

    move-result-object v0

    .line 1069
    invoke-virtual {v0, v2}, Landroidx/fragment/app/FragmentTransaction;->remove(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/FragmentTransaction;

    const/high16 v1, 0x10b0000

    const v2, 0x10b0001

    .line 1070
    invoke-virtual {v0, v1, v2}, Landroidx/fragment/app/FragmentTransaction;->setCustomAnimations(II)Landroidx/fragment/app/FragmentTransaction;

    .line 1071
    invoke-virtual {v0}, Landroidx/fragment/app/FragmentTransaction;->commitAllowingStateLoss()I

    .line 1074
    :cond_0
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->requestFocus()Z

    :cond_1
    return-void
.end method

.method private isRecordAudioGranted()Z
    .locals 2

    .line 843
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "android.permission.RECORD_AUDIO"

    invoke-static {v0, v1}, Landroidx/core/content/ContextCompat;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method private loseAudioFocus()V
    .locals 3

    .line 910
    :try_start_0
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->car:Landroid/support/car/Car;

    const-class v1, Landroid/support/car/media/CarAudioManager;

    invoke-virtual {v0, v1}, Landroid/support/car/Car;->getCarManager(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/car/media/CarAudioManager;

    const/4 v1, 0x1

    .line 912
    invoke-virtual {v0, v1}, Landroid/support/car/media/CarAudioManager;->getAudioAttributesForCarUsage(I)Landroid/media/AudioAttributes;

    move-result-object v1

    const/4 v2, 0x0

    .line 914
    invoke-virtual {v0, v2, v1}, Landroid/support/car/media/CarAudioManager;->abandonAudioFocus(Landroid/media/AudioManager$OnAudioFocusChangeListener;Landroid/media/AudioAttributes;)V
    :try_end_0
    .catch Landroid/support/car/CarNotConnectedException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .line 916
    invoke-virtual {v0}, Landroid/support/car/CarNotConnectedException;->printStackTrace()V

    :goto_0
    return-void
.end method

.method private search(Ljava/lang/String;)V
    .locals 3

    :try_start_0
    const-string v0, "utf-8"

    .line 753
    invoke-static {p1, v0}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    .line 755
    invoke-virtual {p1}, Ljava/io/UnsupportedEncodingException;->printStackTrace()V

    const/4 p1, 0x0

    .line 757
    :goto_0
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getSearchUrlBase()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method

.method private setupEditTextMirroring(Lcom/thekirankumar/youtubeauto2/utils/CarEditText;)V
    .locals 1

    .line 703
    new-instance v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$23;

    invoke-direct {v0, p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$23;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Lcom/thekirankumar/youtubeauto2/utils/CarEditText;)V

    invoke-virtual {p1, v0}, Lcom/thekirankumar/youtubeauto2/utils/CarEditText;->addTextChangedListener(Landroid/text/TextWatcher;)V

    .line 720
    new-instance v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$24;

    invoke-direct {v0, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$24;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V

    invoke-virtual {p1, v0}, Lcom/thekirankumar/youtubeauto2/utils/CarEditText;->setOnEditorActionListener(Landroid/widget/TextView$OnEditorActionListener;)V

    return-void
.end method

.method private showAndHideCornerControlsAnimation()V
    .locals 4

    .line 821
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->cornerControls:Landroid/view/View;

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->cornerControlsHideRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 822
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->showCornerControls()V

    .line 823
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->cornerControls:Landroid/view/View;

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->cornerControlsHideRunnable:Ljava/lang/Runnable;

    const-wide/16 v2, 0xbb8

    invoke-virtual {v0, v1, v2, v3}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method private showAndHideToolbarAnimation()V
    .locals 4

    .line 815
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toolbar:Landroid/view/View;

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toolbarHideRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 816
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->showToolbar()V

    .line 817
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toolbar:Landroid/view/View;

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toolbarHideRunnable:Ljava/lang/Runnable;

    const-wide/16 v2, 0xbb8

    invoke-virtual {v0, v1, v2, v3}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method private showBookmarksScreen()V
    .locals 4

    .line 1118
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->isAdded()Z

    move-result v0

    if-eqz v0, :cond_1

    .line 1119
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->setVisibility(I)V

    .line 1120
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toolbar:Landroid/view/View;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 1121
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getChildFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const-string v1, "bookmarks"

    .line 1122
    invoke-virtual {v0, v1}, Landroidx/fragment/app/FragmentManager;->findFragmentByTag(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v2

    check-cast v2, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;

    if-nez v2, :cond_0

    .line 1124
    new-instance v2, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;

    invoke-direct {v2}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;-><init>()V

    .line 1126
    :cond_0
    invoke-virtual {v0}, Landroidx/fragment/app/FragmentManager;->beginTransaction()Landroidx/fragment/app/FragmentTransaction;

    move-result-object v0

    const v3, 0x7f0800fc

    .line 1127
    invoke-virtual {v0, v3, v2, v1}, Landroidx/fragment/app/FragmentTransaction;->add(ILandroidx/fragment/app/Fragment;Ljava/lang/String;)Landroidx/fragment/app/FragmentTransaction;

    const/high16 v1, 0x10b0000

    const v2, 0x10b0001

    .line 1128
    invoke-virtual {v0, v1, v2}, Landroidx/fragment/app/FragmentTransaction;->setCustomAnimations(II)Landroidx/fragment/app/FragmentTransaction;

    .line 1129
    invoke-virtual {v0}, Landroidx/fragment/app/FragmentTransaction;->commitAllowingStateLoss()I

    :cond_1
    return-void
.end method

.method private showCornerControls()V
    .locals 4

    .line 806
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->cornerControls:Landroid/view/View;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 807
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->cornerControls:Landroid/view/View;

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->cornerControlsHideRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 808
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->cornerControls:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->clearAnimation()V

    .line 809
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->cornerControls:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getTranslationX()F

    move-result v0

    const/4 v1, 0x0

    cmpl-float v0, v0, v1

    if-lez v0, :cond_0

    .line 810
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->cornerControls:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const-wide/16 v2, 0xc8

    invoke-virtual {v0, v2, v3}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->translationX(F)Landroid/view/ViewPropertyAnimator;

    :cond_0
    return-void
.end method

.method private showNativePlayer(Ljava/lang/String;)V
    .locals 4

    .line 1201
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->isAdded()Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 v0, 0x1

    .line 1202
    iput-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->nativePlayerActive:Z

    .line 1203
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->setVisibility(I)V

    .line 1204
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->showCornerControls()V

    .line 1205
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getView()Landroid/view/View;

    move-result-object v0

    const v1, 0x7f0800b0

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1206
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getChildFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const-string v2, "player"

    .line 1207
    invoke-virtual {v0, v2}, Landroidx/fragment/app/FragmentManager;->findFragmentByTag(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v3

    check-cast v3, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;

    if-nez v3, :cond_0

    .line 1209
    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->newInstance(Ljava/lang/String;)Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;

    move-result-object v3

    .line 1211
    :cond_0
    iput-object v3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->nativePlayerFragment:Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;

    .line 1212
    invoke-virtual {v0}, Landroidx/fragment/app/FragmentManager;->beginTransaction()Landroidx/fragment/app/FragmentTransaction;

    move-result-object p1

    .line 1213
    invoke-virtual {p1, v1, v3, v2}, Landroidx/fragment/app/FragmentTransaction;->add(ILandroidx/fragment/app/Fragment;Ljava/lang/String;)Landroidx/fragment/app/FragmentTransaction;

    const/high16 v0, 0x10b0000

    const v1, 0x10b0001

    .line 1214
    invoke-virtual {p1, v0, v1}, Landroidx/fragment/app/FragmentTransaction;->setCustomAnimations(II)Landroidx/fragment/app/FragmentTransaction;

    .line 1215
    invoke-virtual {p1}, Landroidx/fragment/app/FragmentTransaction;->commitAllowingStateLoss()I

    :cond_1
    return-void
.end method

.method private showToolbar()V
    .locals 4

    .line 797
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toolbar:Landroid/view/View;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 798
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toolbar:Landroid/view/View;

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toolbarHideRunnable:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 799
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toolbar:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->clearAnimation()V

    .line 800
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toolbar:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getTranslationY()F

    move-result v0

    const/4 v1, 0x0

    cmpg-float v0, v0, v1

    if-gez v0, :cond_0

    .line 801
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toolbar:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    const-wide/16 v2, 0xc8

    invoke-virtual {v0, v2, v3}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroid/view/ViewPropertyAnimator;->translationY(F)Landroid/view/ViewPropertyAnimator;

    :cond_0
    return-void
.end method

.method private showWarningScreen()V
    .locals 4

    .line 1079
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->isAdded()Z

    move-result v0

    if-eqz v0, :cond_1

    const/4 v0, 0x1

    .line 1080
    iput-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->warningScreenOpen:Z

    .line 1081
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getChildFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    const-string v1, "safety"

    .line 1082
    invoke-virtual {v0, v1}, Landroidx/fragment/app/FragmentManager;->findFragmentByTag(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v2

    check-cast v2, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;

    if-nez v2, :cond_0

    .line 1084
    new-instance v2, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;

    invoke-direct {v2}, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;-><init>()V

    .line 1086
    :cond_0
    invoke-virtual {v0}, Landroidx/fragment/app/FragmentManager;->beginTransaction()Landroidx/fragment/app/FragmentTransaction;

    move-result-object v0

    const v3, 0x7f0800fc

    .line 1087
    invoke-virtual {v0, v3, v2, v1}, Landroidx/fragment/app/FragmentTransaction;->replace(ILandroidx/fragment/app/Fragment;Ljava/lang/String;)Landroidx/fragment/app/FragmentTransaction;

    const/high16 v1, 0x10b0000

    const v2, 0x10b0001

    .line 1088
    invoke-virtual {v0, v1, v2}, Landroidx/fragment/app/FragmentTransaction;->setCustomAnimations(II)Landroidx/fragment/app/FragmentTransaction;

    .line 1089
    invoke-virtual {v0}, Landroidx/fragment/app/FragmentTransaction;->commitNow()V

    .line 1090
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->setVisibility(I)V

    .line 1091
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toolbar:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_1
    return-void
.end method

.method private toggleAspectRatio()V
    .locals 2

    .line 733
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->currentAspectRatio:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;->ordinal()I

    move-result v0

    .line 734
    invoke-static {}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;->values()[Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    move-result-object v1

    array-length v1, v1

    add-int/lit8 v1, v1, -0x1

    if-lt v0, v1, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    add-int/lit8 v0, v0, 0x1

    .line 739
    :goto_0
    invoke-static {}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;->values()[Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    move-result-object v1

    aget-object v0, v1, v0

    invoke-virtual {p0, v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->setAspectRatio(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;)V

    return-void
.end method

.method private toggleCornerControlsAnimation()V
    .locals 2

    .line 835
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->cornerControls:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getTranslationX()F

    move-result v0

    const/4 v1, 0x0

    cmpl-float v0, v0, v1

    if-nez v0, :cond_0

    const/4 v0, 0x1

    .line 836
    invoke-direct {p0, v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->hideCornerControls(Z)V

    goto :goto_0

    .line 838
    :cond_0
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->showAndHideCornerControlsAnimation()V

    :goto_0
    return-void
.end method

.method private toggleToolbarAnimation()V
    .locals 2

    .line 827
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toolbar:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getTranslationY()F

    move-result v0

    const/4 v1, 0x0

    cmpl-float v0, v0, v1

    if-nez v0, :cond_0

    .line 828
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->hideToolbar()V

    goto :goto_0

    .line 830
    :cond_0
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->showAndHideToolbarAnimation()V

    :goto_0
    return-void
.end method


# virtual methods
.method public getAspectRatio()Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;
    .locals 1

    .line 1147
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->currentAspectRatio:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    return-object v0
.end method

.method public onAttach(Landroid/content/Context;)V
    .locals 3

    .line 279
    invoke-super {p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;->onAttach(Landroid/content/Context;)V

    .line 280
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->mCarConnectionCallback:Landroid/support/car/CarConnectionCallback;

    invoke-static {p1, v0}, Landroid/support/car/Car;->createCar(Landroid/content/Context;Landroid/support/car/CarConnectionCallback;)Landroid/support/car/Car;

    move-result-object v0

    .line 281
    invoke-virtual {v0}, Landroid/support/car/Car;->connect()V

    .line 282
    new-instance v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$5;

    invoke-direct {v0, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$5;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V

    new-instance v1, Landroid/content/IntentFilter;

    const-string v2, "com.thekirankumar.youtubeauto2.player.event"

    invoke-direct {v1, v2}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v0, v1}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    return-void
.end method

.method public onBookmarkAddCurrentPage()V
    .locals 1

    .line 1187
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils;->addBookmark(Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;)V

    return-void
.end method

.method public onBookmarkDelete(Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V
    .locals 0

    .line 1192
    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils;->deleteBookmark(Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V

    return-void
.end method

.method public onBookmarkFragmentClose()V
    .locals 0

    .line 1197
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->hideBookmarksScreen()V

    return-void
.end method

.method public onBookmarkSelected(Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V
    .locals 1

    .line 1181
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->hideNativePlayer()V

    .line 1182
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->getUrl()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 1

    .line 270
    invoke-super {p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;->onCreate(Landroid/os/Bundle;)V

    .line 271
    new-instance p1, Landroid/os/HandlerThread;

    const-string v0, "autosuggest"

    invoke-direct {p1, v0}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->handlerThread:Landroid/os/HandlerThread;

    .line 272
    invoke-virtual {p1}, Landroid/os/HandlerThread;->start()V

    .line 273
    new-instance p1, Landroid/os/Handler;

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->handlerThread:Landroid/os/HandlerThread;

    invoke-virtual {v0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {p1, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->handler:Landroid/os/Handler;

    return-void
.end method

.method public onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .locals 1

    const p3, 0x7f0b0041

    const/4 v0, 0x0

    .line 310
    invoke-virtual {p1, p3, p2, v0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    return-object p1
.end method

.method public onDestroy()V
    .locals 1

    .line 958
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    if-eqz v0, :cond_0

    .line 959
    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->destroy()V

    .line 961
    :cond_0
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->handlerThread:Landroid/os/HandlerThread;

    if-eqz v0, :cond_1

    .line 962
    invoke-virtual {v0}, Landroid/os/HandlerThread;->quit()Z

    .line 964
    :cond_1
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->mediaSessionCompat:Landroid/support/v4/media/session/MediaSessionCompat;

    if-eqz v0, :cond_2

    .line 965
    invoke-virtual {v0}, Landroid/support/v4/media/session/MediaSessionCompat;->release()V

    .line 967
    :cond_2
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->car:Landroid/support/car/Car;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Landroid/support/car/Car;->isConnected()Z

    move-result v0

    if-eqz v0, :cond_3

    .line 968
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->car:Landroid/support/car/Car;

    invoke-virtual {v0}, Landroid/support/car/Car;->disconnect()V

    .line 971
    :cond_3
    invoke-super {p0}, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;->onDestroy()V

    return-void
.end method

.method public onDestroyView()V
    .locals 1

    .line 976
    invoke-super {p0}, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;->onDestroyView()V

    .line 977
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getContext()Landroid/content/Context;

    move-result-object v0

    check-cast v0, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;

    .line 978
    invoke-virtual {v0, p0}, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->removeActivityCallback(Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity$ActivityCallbacks;)V

    return-void
.end method

.method public onDetach()V
    .locals 0

    .line 953
    invoke-super {p0}, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;->onDetach()V

    return-void
.end method

.method public onHideKeyboardFromJS()V
    .locals 2

    .line 1043
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getContext()Landroid/content/Context;

    move-result-object v0

    check-cast v0, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;

    .line 1044
    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->a()Lcom/google/android/gms/car/input/InputManager;

    move-result-object v0

    invoke-interface {v0}, Lcom/google/android/gms/car/input/InputManager;->stopInput()V

    .line 1045
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v1, -0x1

    .line 1046
    iput v1, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 1047
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v1, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public onJSVideoEvent(Ljava/lang/String;)V
    .locals 0

    return-void
.end method

.method public onNativePlayerControlsVisibilityChange(I)V
    .locals 1

    if-nez p1, :cond_0

    .line 1137
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->showToolbar()V

    .line 1138
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->showCornerControls()V

    goto :goto_0

    :cond_0
    const/16 v0, 0x8

    if-ne p1, v0, :cond_1

    .line 1140
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->hideToolbar()V

    const/4 p1, 0x1

    .line 1141
    invoke-direct {p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->hideCornerControls(Z)V

    :cond_1
    :goto_0
    return-void
.end method

.method public onPause()V
    .locals 3

    .line 934
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    if-eqz v0, :cond_0

    .line 935
    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->pauseVideoAndSetFlag()V

    .line 938
    :cond_0
    invoke-super {p0}, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;->onPause()V

    .line 939
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->loseAudioFocus()V

    .line 940
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getUrl()Ljava/lang/String;

    move-result-object v0

    .line 942
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->handler:Landroid/os/Handler;

    new-instance v2, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$26;

    invoke-direct {v2, p0, v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$26;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public onReadyToExitSafetyInstructions(Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;)V
    .locals 0

    const/4 p1, 0x1

    .line 1163
    iput-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->warningAccepted:Z

    .line 1164
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->hideWarningScreen()V

    return-void
.end method

.method public onResume()V
    .locals 0

    .line 864
    invoke-super {p0}, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;->onResume()V

    return-void
.end method

.method public onShowKeyboardFromJS(Ljava/lang/String;)V
    .locals 3

    .line 1031
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->fakeEditText:Lcom/thekirankumar/youtubeauto2/utils/CarEditText;

    invoke-virtual {v0, p1}, Lcom/thekirankumar/youtubeauto2/utils/CarEditText;->setText(Ljava/lang/CharSequence;)V

    .line 1032
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getContext()Landroid/content/Context;

    move-result-object p1

    check-cast p1, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;

    .line 1033
    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->a()Lcom/google/android/gms/car/input/InputManager;

    move-result-object p1

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->fakeEditText:Lcom/thekirankumar/youtubeauto2/utils/CarEditText;

    invoke-interface {p1, v0}, Lcom/google/android/gms/car/input/InputManager;->startInput(Lcom/google/android/gms/car/input/CarEditable;)V

    .line 1034
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->fakeEditText:Lcom/thekirankumar/youtubeauto2/utils/CarEditText;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/utils/CarEditText;->getText()Landroid/text/Editable;

    move-result-object v0

    invoke-interface {v0}, Landroid/text/Editable;->length()I

    move-result v0

    invoke-virtual {p1, v0}, Lcom/thekirankumar/youtubeauto2/utils/CarEditText;->setSelection(I)V

    .line 1035
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p1

    .line 1036
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    const/4 v1, 0x1

    const/high16 v2, 0x43160000    # 150.0f

    invoke-static {v1, v2, v0}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v0

    float-to-int v0, v0

    iput v0, p1, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 1037
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v0, p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1038
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {p1, v1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->scrollActiveElementIntoView(Z)V

    return-void
.end method

.method public onStart()V
    .locals 0

    .line 859
    invoke-super {p0}, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;->onStart()V

    return-void
.end method

.method public onStop()V
    .locals 4

    .line 870
    iget v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->playerState:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_0

    .line 871
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    .line 872
    new-instance v1, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$25;

    invoke-direct {v1, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$25;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V

    const-wide/16 v2, 0xc8

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 878
    :cond_0
    invoke-super {p0}, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;->onStop()V

    return-void
.end method

.method public onVideoCurrentTimeResult(I)V
    .locals 0

    .line 1026
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->currentVideoTime:Ljava/lang/Integer;

    return-void
.end method

.method public onVideoElementDiscovered()V
    .locals 2

    .line 1011
    iget-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->fullScreenRequested:Z

    if-eqz v0, :cond_0

    .line 1012
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->requestFullScreen()V

    .line 1014
    :cond_0
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->currentAspectRatio:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    if-eqz v0, :cond_1

    .line 1015
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;->name()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->setAspectRatio(Ljava/lang/String;)V

    .line 1017
    :cond_1
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->attachVideoListeners()V

    .line 1018
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->currentVideoTime:Ljava/lang/Integer;

    if-eqz v0, :cond_2

    .line 1019
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-virtual {v1, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->seekBySeconds(I)V

    const/4 v0, 0x0

    .line 1020
    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->currentVideoTime:Ljava/lang/Integer;

    :cond_2
    return-void
.end method

.method public onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
    .locals 9

    .line 315
    invoke-super {p0, p1, p2}, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V

    .line 316
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getContext()Landroid/content/Context;

    move-result-object p2

    invoke-static {p2}, Lcom/google/firebase/analytics/FirebaseAnalytics;->getInstance(Landroid/content/Context;)Lcom/google/firebase/analytics/FirebaseAnalytics;

    move-result-object p2

    const-string v0, "WebviewCarFragment_created"

    const/4 v1, 0x0

    invoke-virtual {p2, v0, v1}, Lcom/google/firebase/analytics/FirebaseAnalytics;->logEvent(Ljava/lang/String;Landroid/os/Bundle;)V

    const p2, 0x7f08017c

    .line 318
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    .line 319
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getContext()Landroid/content/Context;

    move-result-object p2

    check-cast p2, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;

    const/16 v0, 0x200

    .line 320
    invoke-virtual {p2, v0}, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->setIgnoreConfigChanges(I)V

    .line 321
    new-instance v0, Lcom/thekirankumar/youtubeauto2/utils/MyExceptionHandler;

    invoke-direct {v0, p2}, Lcom/thekirankumar/youtubeauto2/utils/MyExceptionHandler;-><init>(Lcom/google/android/apps/auto/sdk/CarActivity;)V

    invoke-static {v0}, Ljava/lang/Thread;->setDefaultUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    const v0, 0x7f0800a2

    .line 323
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Lcom/thekirankumar/youtubeauto2/utils/CarEditText;

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->fakeEditText:Lcom/thekirankumar/youtubeauto2/utils/CarEditText;

    .line 324
    invoke-direct {p0, v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->setupEditTextMirroring(Lcom/thekirankumar/youtubeauto2/utils/CarEditText;)V

    .line 326
    invoke-virtual {p2}, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->getCarUiController()Lcom/google/android/apps/auto/sdk/CarUiController;

    move-result-object v0

    .line 327
    invoke-virtual {v0}, Lcom/google/android/apps/auto/sdk/CarUiController;->getSearchController()Lcom/google/android/apps/auto/sdk/SearchController;

    move-result-object v1

    .line 329
    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    new-instance v3, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;

    invoke-direct {v3, p0}, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;-><init>(Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$JSCallbacks;)V

    const-string v4, "nativecallbacks"

    invoke-virtual {v2, v3, v4}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V

    .line 330
    invoke-virtual {p2}, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->getWindow()Landroid/view/Window;

    move-result-object v2

    const/4 v3, 0x3

    invoke-virtual {v2, v3}, Landroid/view/Window;->setVolumeControlStream(I)V

    const v2, 0x7f08004c

    .line 331
    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageButton;

    .line 332
    new-instance v3, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$6;

    invoke-direct {v3, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$6;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V

    invoke-virtual {v2, v3}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v2, 0x7f0800bb

    .line 338
    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageButton;

    .line 339
    new-instance v3, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$7;

    invoke-direct {v3, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$7;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V

    invoke-virtual {v2, v3}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 345
    new-instance v3, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$8;

    invoke-direct {v3, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$8;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V

    invoke-virtual {v2, v3}, Landroid/widget/ImageButton;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const v2, 0x7f0800b2

    .line 352
    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    iput-object v2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->cornerControls:Landroid/view/View;

    const v2, 0x7f080048

    .line 354
    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/Button;

    iput-object v2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->aspectButton:Landroid/widget/Button;

    .line 355
    new-instance v3, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$9;

    invoke-direct {v3, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$9;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 363
    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->aspectButton:Landroid/widget/Button;

    new-instance v3, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$10;

    invoke-direct {v3, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$10;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V

    invoke-virtual {v2, v3}, Landroid/widget/Button;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    const v2, 0x7f08010b

    .line 370
    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ProgressBar;

    iput-object v2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->progressBar:Landroid/widget/ProgressBar;

    const v2, 0x7f080112

    .line 371
    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageButton;

    .line 372
    new-instance v3, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$11;

    invoke-direct {v3, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$11;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V

    invoke-virtual {v2, v3}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v2, 0x7f08017b

    .line 378
    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageButton;

    .line 379
    new-instance v3, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;

    invoke-direct {v3, p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Landroid/view/View;)V

    invoke-virtual {v2, v3}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 446
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->handleVoiceVisibility()V

    const v2, 0x7f0800b1

    .line 447
    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageButton;

    .line 448
    new-instance v3, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$13;

    invoke-direct {v3, p0, v2}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$13;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Landroid/widget/ImageButton;)V

    invoke-virtual {v2, v3}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v3, 0x7f08012d

    .line 469
    invoke-virtual {p1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/ImageButton;

    .line 470
    new-instance v4, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$14;

    invoke-direct {v4, p0, v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$14;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Lcom/google/android/apps/auto/sdk/CarUiController;)V

    invoke-virtual {v3, v4}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v3, 0x7f080128

    .line 486
    invoke-virtual {p1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/ImageButton;

    .line 487
    new-instance v4, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$15;

    invoke-direct {v4, p0, v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$15;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Lcom/google/android/apps/auto/sdk/CarUiController;)V

    invoke-virtual {v3, v4}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v3, 0x7f080050

    .line 503
    invoke-virtual {p1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Landroid/widget/ImageButton;

    .line 504
    new-instance v4, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$16;

    invoke-direct {v4, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$16;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V

    invoke-virtual {v3, v4}, Landroid/widget/ImageButton;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const v3, 0x7f080169

    .line 511
    invoke-virtual {p1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->toolbar:Landroid/view/View;

    const v3, 0x7f08017d

    .line 512
    invoke-virtual {p1, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    const v4, 0x7f0800b0

    .line 513
    invoke-virtual {p1, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/view/ViewGroup;

    .line 514
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-static {v5}, Landroid/preference/PreferenceManager;->getDefaultSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v5

    .line 515
    iget-object v6, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    const/4 v7, 0x0

    const-string v8, "pref_enable_desktop_mode"

    invoke-interface {v5, v8, v7}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v5

    invoke-static {v6, v5}, Lcom/thekirankumar/youtubeauto2/utils/WebviewUtils;->setDesktopMode(Landroid/webkit/WebView;Z)V

    .line 516
    iget-object v5, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    new-instance v6, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$17;

    invoke-direct {v6, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$17;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V

    invoke-virtual {v5, v6}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    .line 534
    new-instance v5, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;

    new-instance v6, Landroid/widget/ProgressBar;

    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getContext()Landroid/content/Context;

    move-result-object v8

    invoke-direct {v6, v8}, Landroid/widget/ProgressBar;-><init>(Landroid/content/Context;)V

    iget-object v8, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-direct {v5, v3, v4, v6, v8}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;-><init>(Landroid/view/View;Landroid/view/ViewGroup;Landroid/view/View;Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;)V

    .line 535
    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v3, v5}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->setWebChromeClient(Landroid/webkit/WebChromeClient;)V

    .line 536
    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v3}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    const/4 v4, 0x1

    invoke-virtual {v3, v4}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    .line 537
    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v3}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    invoke-virtual {v3, v4}, Landroid/webkit/WebSettings;->setAllowFileAccess(Z)V

    .line 538
    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v3}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    invoke-virtual {v3, v4}, Landroid/webkit/WebSettings;->setDomStorageEnabled(Z)V

    .line 539
    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v3}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    invoke-virtual {v3, v4}, Landroid/webkit/WebSettings;->setDatabaseEnabled(Z)V

    .line 540
    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v3}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    invoke-virtual {v3, v4}, Landroid/webkit/WebSettings;->setSupportZoom(Z)V

    .line 541
    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v3}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    sget-object v6, Landroid/webkit/WebSettings$RenderPriority;->HIGH:Landroid/webkit/WebSettings$RenderPriority;

    invoke-virtual {v3, v6}, Landroid/webkit/WebSettings;->setRenderPriority(Landroid/webkit/WebSettings$RenderPriority;)V

    .line 542
    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v3}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    invoke-virtual {v3, v4}, Landroid/webkit/WebSettings;->setLoadWithOverviewMode(Z)V

    .line 543
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v6, 0x10

    if-lt v3, v6, :cond_0

    .line 544
    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v3}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    invoke-virtual {v3, v4}, Landroid/webkit/WebSettings;->setAllowFileAccessFromFileURLs(Z)V

    .line 546
    :cond_0
    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v3}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    invoke-virtual {v3, v4}, Landroid/webkit/WebSettings;->setAllowContentAccess(Z)V

    .line 547
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v6, 0x11

    if-lt v3, v6, :cond_1

    .line 548
    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v3}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    invoke-virtual {v3, v7}, Landroid/webkit/WebSettings;->setMediaPlaybackRequiresUserGesture(Z)V

    .line 550
    :cond_1
    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v3}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v3

    invoke-virtual {v3, v4}, Landroid/webkit/WebSettings;->setAllowFileAccess(Z)V

    .line 551
    iget-boolean v3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->isNightMode:Z

    if-eqz v3, :cond_2

    .line 552
    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    const/high16 v4, -0x1000000

    invoke-virtual {v3, v4}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->setBackgroundColor(I)V

    .line 555
    :cond_2
    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->handler:Landroid/os/Handler;

    new-instance v4, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18;

    invoke-direct {v4, p0, v2}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Landroid/widget/ImageButton;)V

    invoke-virtual {v3, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 579
    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v2}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->requestFocus()Z

    .line 580
    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    new-instance v3, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$19;

    invoke-direct {v3, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$19;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V

    invoke-virtual {v2, v3}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 603
    new-instance v2, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;

    invoke-direct {v2, p0, v0, p1, v1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Lcom/google/android/apps/auto/sdk/CarUiController;Landroid/view/View;Lcom/google/android/apps/auto/sdk/SearchController;)V

    invoke-virtual {v1, v2}, Lcom/google/android/apps/auto/sdk/SearchController;->setSearchCallback(Lcom/google/android/apps/auto/sdk/SearchCallback;)V

    .line 673
    invoke-virtual {v0}, Lcom/google/android/apps/auto/sdk/CarUiController;->getStatusBarController()Lcom/google/android/apps/auto/sdk/StatusBarController;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/android/apps/auto/sdk/StatusBarController;->hideAppHeader()V

    .line 674
    new-instance p1, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$21;

    invoke-direct {p1, p0, v1, v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$21;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Lcom/google/android/apps/auto/sdk/SearchController;Lcom/google/android/apps/auto/sdk/CarUiController;)V

    invoke-virtual {v5, p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->setOnToggledFullscreen(Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient$ToggledFullscreenCallback;)V

    .line 689
    new-instance p1, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$22;

    invoke-direct {p1, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$22;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V

    invoke-virtual {v5, p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->setVideoTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 699
    invoke-virtual {p2, p0}, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->addActivityCallback(Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity$ActivityCallbacks;)V

    return-void
.end method

.method public onWindowFocusChanged(Z)V
    .locals 0

    if-eqz p1, :cond_0

    .line 985
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->onHideKeyboardFromJS()V

    :cond_0
    return-void
.end method

.method public resumePlayback()V
    .locals 1

    .line 882
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->car:Landroid/support/car/Car;

    if-eqz v0, :cond_0

    iget-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->nativePlayerActive:Z

    if-nez v0, :cond_0

    .line 883
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->gainAudioFocus()V

    .line 885
    :cond_0
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    if-eqz v0, :cond_1

    .line 886
    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->requestFocus()Z

    .line 888
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->playVideo()V

    .line 890
    :cond_1
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->handleVoiceVisibility()V

    return-void
.end method

.method public setAspectRatio(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;)V
    .locals 2

    .line 1151
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->currentAspectRatio:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    .line 1152
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->aspectButton:Landroid/widget/Button;

    invoke-direct {p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getHumanText(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    .line 1153
    iget-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->nativePlayerActive:Z

    if-eqz v0, :cond_0

    .line 1154
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->nativePlayerFragment:Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;

    invoke-virtual {v0, p1}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->setAspectRatio(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;)V

    goto :goto_0

    .line 1156
    :cond_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->currentAspectRatio:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;->name()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->setAspectRatio(Ljava/lang/String;)V

    .line 1158
    :goto_0
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getSharedPrefs()Landroid/content/SharedPreferences;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->currentAspectRatio:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;->ordinal()I

    move-result v0

    const-string v1, "aspect_ratio"

    invoke-interface {p1, v1, v0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public setParkingBrake(Z)V
    .locals 0

    .line 1051
    iput-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->isParkingEngaged:Z

    .line 1052
    iget-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->warningAccepted:Z

    if-nez p1, :cond_0

    .line 1053
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->showWarningScreen()V

    goto :goto_0

    .line 1055
    :cond_0
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->hideWarningScreen()V

    :goto_0
    return-void
.end method
