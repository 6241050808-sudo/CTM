.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12$1;
.super Ljava/lang/Object;
.source "WebViewCarFragment.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->onClick(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;

.field final synthetic val$recognitionProgressView:Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;)V
    .locals 0

    .line 389
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12$1;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12$1;->val$recognitionProgressView:Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1

    .line 392
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12$1;->val$recognitionProgressView:Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;

    invoke-virtual {p1}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->stop()V

    .line 393
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12$1;->val$recognitionProgressView:Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;

    const/16 v0, 0x8

    invoke-virtual {p1, v0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->setVisibility(I)V

    return-void
.end method
