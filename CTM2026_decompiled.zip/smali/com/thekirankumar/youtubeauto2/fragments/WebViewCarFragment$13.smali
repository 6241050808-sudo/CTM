.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$13;
.super Ljava/lang/Object;
.source "WebViewCarFragment.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

.field final synthetic val$fullScreenButton:Landroid/widget/ImageButton;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Landroid/widget/ImageButton;)V
    .locals 0

    .line 448
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$13;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$13;->val$fullScreenButton:Landroid/widget/ImageButton;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 5

    .line 451
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$13;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1800(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Z

    move-result p1

    const-string v0, "fullscreen"

    const/4 v1, 0x4

    const-string v2, "car"

    if-eqz p1, :cond_0

    .line 452
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$13;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    const/4 v3, 0x0

    invoke-static {p1, v3}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1802(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Z)Z

    .line 453
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$13;->val$fullScreenButton:Landroid/widget/ImageButton;

    invoke-virtual {p1, v3}, Landroid/widget/ImageButton;->setActivated(Z)V

    .line 454
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$13;->val$fullScreenButton:Landroid/widget/ImageButton;

    const v4, 0x7f0700c2

    invoke-virtual {p1, v4}, Landroid/widget/ImageButton;->setImageResource(I)V

    .line 455
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$13;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$900(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    move-result-object p1

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->exitFullScreen()V

    .line 456
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$13;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p1, v2, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p1

    .line 457
    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1, v0, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    goto :goto_0

    .line 459
    :cond_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$13;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    const/4 v3, 0x1

    invoke-static {p1, v3}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1802(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Z)Z

    .line 460
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$13;->val$fullScreenButton:Landroid/widget/ImageButton;

    invoke-virtual {p1, v3}, Landroid/widget/ImageButton;->setActivated(Z)V

    .line 461
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$13;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$900(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    move-result-object p1

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->requestFullScreen()V

    .line 462
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$13;->val$fullScreenButton:Landroid/widget/ImageButton;

    const v4, 0x7f0700c1

    invoke-virtual {p1, v4}, Landroid/widget/ImageButton;->setImageResource(I)V

    .line 463
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$13;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-virtual {p1, v2, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p1

    .line 464
    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1, v0, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    :goto_0
    return-void
.end method
