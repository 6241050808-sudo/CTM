.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$26;
.super Ljava/lang/Object;
.source "WebViewCarFragment.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->onPause()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

.field final synthetic val$url:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Ljava/lang/String;)V
    .locals 0

    .line 942
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$26;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$26;->val$url:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 945
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$26;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$2300(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/content/SharedPreferences;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$26;->val$url:Ljava/lang/String;

    const-string v2, "home_url"

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method
