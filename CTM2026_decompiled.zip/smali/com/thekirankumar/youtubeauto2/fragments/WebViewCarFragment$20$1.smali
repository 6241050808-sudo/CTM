.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20$1;
.super Ljava/lang/Object;
.source "WebViewCarFragment.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;->onSearchTextChanged(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;

.field final synthetic val$s:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;Ljava/lang/String;)V
    .locals 0

    .line 622
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20$1;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20$1;->val$s:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const/4 v0, 0x0

    .line 627
    :try_start_0
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20$1;->val$s:Ljava/lang/String;

    const-string v2, "utf-8"

    invoke-static {v1, v2}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v1

    .line 629
    invoke-virtual {v1}, Ljava/io/UnsupportedEncodingException;->printStackTrace()V

    move-object v1, v0

    .line 631
    :goto_0
    new-instance v2, Lokhttp3/OkHttpClient;

    invoke-direct {v2}, Lokhttp3/OkHttpClient;-><init>()V

    .line 634
    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20$1;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;

    iget-object v3, v3, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v3}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$2000(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    move-result-object v3

    sget-object v4, Lcom/thekirankumar/youtubeauto2/utils/SearchMode;->YOUTUBE:Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    if-ne v3, v4, :cond_0

    const-string v0, "http://suggestqueries.google.com/complete/search?client=firefox&ds=yt&q="

    goto :goto_1

    .line 636
    :cond_0
    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20$1;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;

    iget-object v3, v3, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v3}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$2000(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    move-result-object v3

    sget-object v4, Lcom/thekirankumar/youtubeauto2/utils/SearchMode;->GOOGLE:Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    if-ne v3, v4, :cond_1

    const-string v0, "http://suggestqueries.google.com/complete/search?client=chrome&q="

    .line 639
    :cond_1
    :goto_1
    new-instance v3, Lokhttp3/Request$Builder;

    invoke-direct {v3}, Lokhttp3/Request$Builder;-><init>()V

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 640
    invoke-virtual {v3, v0}, Lokhttp3/Request$Builder;->url(Ljava/lang/String;)Lokhttp3/Request$Builder;

    move-result-object v0

    .line 641
    invoke-virtual {v0}, Lokhttp3/Request$Builder;->build()Lokhttp3/Request;

    move-result-object v0

    .line 642
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 644
    :try_start_1
    invoke-virtual {v2, v0}, Lokhttp3/OkHttpClient;->newCall(Lokhttp3/Request;)Lokhttp3/Call;

    move-result-object v0

    invoke-interface {v0}, Lokhttp3/Call;->execute()Lokhttp3/Response;

    move-result-object v0

    .line 645
    invoke-virtual {v0}, Lokhttp3/Response;->isSuccessful()Z

    move-result v2

    if-eqz v2, :cond_2

    .line 646
    new-instance v2, Lorg/json/JSONArray;

    invoke-virtual {v0}, Lokhttp3/Response;->body()Lokhttp3/ResponseBody;

    move-result-object v0

    invoke-virtual {v0}, Lokhttp3/ResponseBody;->string()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    const/4 v0, 0x1

    .line 647
    invoke-virtual {v2, v0}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_2

    .line 648
    instance-of v2, v0, Lorg/json/JSONArray;

    if-eqz v2, :cond_2

    const/4 v2, 0x0

    .line 649
    :goto_2
    move-object v3, v0

    check-cast v3, Lorg/json/JSONArray;

    invoke-virtual {v3}, Lorg/json/JSONArray;->length()I

    move-result v3

    if-ge v2, v3, :cond_2

    .line 650
    move-object v3, v0

    check-cast v3, Lorg/json/JSONArray;

    invoke-virtual {v3, v2}, Lorg/json/JSONArray;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    .line 651
    new-instance v4, Lcom/google/android/apps/auto/sdk/SearchItem$Builder;

    invoke-direct {v4}, Lcom/google/android/apps/auto/sdk/SearchItem$Builder;-><init>()V

    .line 652
    invoke-virtual {v4, v3}, Lcom/google/android/apps/auto/sdk/SearchItem$Builder;->setTitle(Ljava/lang/CharSequence;)Lcom/google/android/apps/auto/sdk/SearchItem$Builder;

    .line 653
    invoke-virtual {v4}, Lcom/google/android/apps/auto/sdk/SearchItem$Builder;->build()Lcom/google/android/apps/auto/sdk/SearchItem;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_2
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_1

    add-int/lit8 v2, v2, 0x1

    goto :goto_2

    :catch_1
    move-exception v0

    .line 660
    invoke-virtual {v0}, Lorg/json/JSONException;->printStackTrace()V

    goto :goto_3

    :catch_2
    move-exception v0

    .line 658
    invoke-virtual {v0}, Ljava/io/IOException;->printStackTrace()V

    .line 662
    :cond_2
    :goto_3
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20$1;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;

    iget-object v0, v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;->val$view:Landroid/view/View;

    new-instance v2, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20$1$1;

    invoke-direct {v2, p0, v1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20$1$1;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20$1;Ljava/util/ArrayList;)V

    invoke-virtual {v0, v2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void
.end method
