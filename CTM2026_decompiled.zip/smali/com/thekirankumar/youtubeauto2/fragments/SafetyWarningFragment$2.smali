.class Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$2;
.super Ljava/lang/Object;
.source "SafetyWarningFragment.java"

# interfaces
.implements Landroid/view/View$OnFocusChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;)V
    .locals 0

    .line 46
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$2;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onFocusChange(Landroid/view/View;Z)V
    .locals 0

    if-nez p2, :cond_0

    .line 50
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$2;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;->access$100(Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;)Landroid/view/View;

    move-result-object p1

    invoke-virtual {p1}, Landroid/view/View;->requestFocus()Z

    :cond_0
    return-void
.end method
