.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$14;
.super Ljava/lang/Object;
.source "WebViewCarFragment.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

.field final synthetic val$carUiController:Lcom/google/android/apps/auto/sdk/CarUiController;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Lcom/google/android/apps/auto/sdk/CarUiController;)V
    .locals 0

    .line 470
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$14;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$14;->val$carUiController:Lcom/google/android/apps/auto/sdk/CarUiController;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1

    .line 473
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$14;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1900(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Z

    move-result p1

    if-nez p1, :cond_0

    .line 474
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$14;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    const/4 v0, 0x1

    invoke-static {p1, v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1902(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Z)Z

    .line 475
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$14;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    sget-object v0, Lcom/thekirankumar/youtubeauto2/utils/SearchMode;->YOUTUBE:Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    invoke-static {p1, v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$2002(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Lcom/thekirankumar/youtubeauto2/utils/SearchMode;)Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    .line 476
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$14;->val$carUiController:Lcom/google/android/apps/auto/sdk/CarUiController;

    invoke-virtual {p1}, Lcom/google/android/apps/auto/sdk/CarUiController;->getSearchController()Lcom/google/android/apps/auto/sdk/SearchController;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/android/apps/auto/sdk/SearchController;->showSearchBox()V

    .line 477
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$14;->val$carUiController:Lcom/google/android/apps/auto/sdk/CarUiController;

    invoke-virtual {p1}, Lcom/google/android/apps/auto/sdk/CarUiController;->getSearchController()Lcom/google/android/apps/auto/sdk/SearchController;

    move-result-object p1

    const-string v0, "YouTube Search"

    invoke-virtual {p1, v0}, Lcom/google/android/apps/auto/sdk/SearchController;->setSearchHint(Ljava/lang/CharSequence;)V

    goto :goto_0

    .line 479
    :cond_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$14;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1902(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Z)Z

    .line 480
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$14;->val$carUiController:Lcom/google/android/apps/auto/sdk/CarUiController;

    invoke-virtual {p1}, Lcom/google/android/apps/auto/sdk/CarUiController;->getSearchController()Lcom/google/android/apps/auto/sdk/SearchController;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/android/apps/auto/sdk/SearchController;->hideSearchBox()V

    .line 481
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$14;->val$carUiController:Lcom/google/android/apps/auto/sdk/CarUiController;

    invoke-virtual {p1}, Lcom/google/android/apps/auto/sdk/CarUiController;->getStatusBarController()Lcom/google/android/apps/auto/sdk/StatusBarController;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/android/apps/auto/sdk/StatusBarController;->hideAppHeader()V

    :goto_0
    return-void
.end method
