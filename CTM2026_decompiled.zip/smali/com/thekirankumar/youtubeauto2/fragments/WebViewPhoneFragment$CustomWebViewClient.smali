.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;
.super Landroid/webkit/WebViewClient;
.source "WebViewPhoneFragment.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "CustomWebViewClient"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;


# direct methods
.method private constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)V
    .locals 0

    .line 518
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;

    invoke-direct {p0}, Landroid/webkit/WebViewClient;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$1;)V
    .locals 0

    .line 518
    invoke-direct {p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)V

    return-void
.end method


# virtual methods
.method public onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V
    .locals 2

    .line 589
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->access$200(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0, p2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 590
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->access$700(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)Landroid/widget/ProgressBar;

    move-result-object v0

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/widget/ProgressBar;->setVisibility(I)V

    .line 591
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "page finished "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "WebViewCarFragment"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 592
    invoke-super {p0, p1, p2}, Landroid/webkit/WebViewClient;->onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V

    .line 593
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->access$300(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    move-result-object p1

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/utils/WebviewUtils;->injectNightModeCss(Landroid/webkit/WebView;)V

    .line 594
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->access$300(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    move-result-object p1

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/utils/WebviewUtils;->injectCustomSelectDropDown(Landroid/webkit/WebView;)V

    .line 595
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->access$300(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    move-result-object p1

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/utils/WebviewUtils;->injectQualityControl(Landroid/webkit/WebView;)V

    .line 596
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->access$300(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    move-result-object p1

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/utils/WebviewUtils;->injectFileListingHack(Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;)V

    .line 597
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->access$800(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)Landroid/content/SharedPreferences;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const-string v0, "home_url"

    invoke-interface {p1, v0, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    return-void
.end method

.method public onPageStarted(Landroid/webkit/WebView;Ljava/lang/String;Landroid/graphics/Bitmap;)V
    .locals 0

    .line 582
    invoke-super {p0, p1, p2, p3}, Landroid/webkit/WebViewClient;->onPageStarted(Landroid/webkit/WebView;Ljava/lang/String;Landroid/graphics/Bitmap;)V

    .line 583
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->access$700(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)Landroid/widget/ProgressBar;

    move-result-object p1

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Landroid/widget/ProgressBar;->setVisibility(I)V

    return-void
.end method

.method public shouldInterceptRequest(Landroid/webkit/WebView;Landroid/webkit/WebResourceRequest;)Landroid/webkit/WebResourceResponse;
    .locals 0

    .line 522
    invoke-super {p0, p1, p2}, Landroid/webkit/WebViewClient;->shouldInterceptRequest(Landroid/webkit/WebView;Landroid/webkit/WebResourceRequest;)Landroid/webkit/WebResourceResponse;

    move-result-object p1

    return-object p1
.end method

.method public shouldOverrideUrlLoading(Landroid/webkit/WebView;Landroid/webkit/WebResourceRequest;)Z
    .locals 2

    .line 528
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x15

    if-lt v0, v1, :cond_0

    .line 529
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->access$200(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)Landroid/widget/EditText;

    move-result-object v0

    invoke-interface {p2}, Landroid/webkit/WebResourceRequest;->getUrl()Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    .line 532
    :cond_0
    invoke-super {p0, p1, p2}, Landroid/webkit/WebViewClient;->shouldOverrideUrlLoading(Landroid/webkit/WebView;Landroid/webkit/WebResourceRequest;)Z

    move-result p1

    return p1
.end method

.method public shouldOverrideUrlLoading(Landroid/webkit/WebView;Ljava/lang/String;)Z
    .locals 4

    .line 538
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->access$200(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)Landroid/widget/EditText;

    move-result-object v0

    invoke-virtual {v0, p2}, Landroid/widget/EditText;->setText(Ljava/lang/CharSequence;)V

    const-string v0, "file:///"

    .line 539
    invoke-virtual {p2, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const-string v0, "/"

    invoke-virtual {p2, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_0

    .line 540
    new-instance v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient$1;

    invoke-direct {v0, p0, p2}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient$1;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Landroid/webkit/WebView;->post(Ljava/lang/Runnable;)Z

    return v1

    :cond_0
    const-string v0, "intent://"

    .line 551
    invoke-virtual {p2, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_2

    .line 553
    :try_start_0
    invoke-virtual {p1}, Landroid/webkit/WebView;->getContext()Landroid/content/Context;

    move-result-object v0

    .line 554
    new-instance v2, Landroid/content/Intent;

    invoke-direct {v2}, Landroid/content/Intent;-><init>()V

    invoke-static {p2, v1}, Landroid/content/Intent;->parseUri(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object p2

    if-eqz p2, :cond_2

    .line 557
    invoke-virtual {p1}, Landroid/webkit/WebView;->stopLoading()V

    .line 559
    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    const/high16 v3, 0x10000

    .line 560
    invoke-virtual {v2, p2, v3}, Landroid/content/pm/PackageManager;->resolveActivity(Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;

    move-result-object v2

    if-eqz v2, :cond_1

    .line 562
    invoke-virtual {v0, p2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto :goto_0

    :cond_1
    const-string v0, "browser_fallback_url"

    .line 564
    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    .line 565
    invoke-virtual {p1, p2}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/net/URISyntaxException; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    return v1

    :catch_0
    move-exception p1

    const-string p2, "WebViewCarFragment"

    const-string v0, "Can\'t resolve intent://"

    .line 572
    invoke-static {p2, v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_2
    const/4 p1, 0x0

    return p1
.end method
