.class public Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;
.super Landroidx/fragment/app/Fragment;
.source "CarFragment.java"


# instance fields
.field private mTitle:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 10
    invoke-direct {p0}, Landroidx/fragment/app/Fragment;-><init>()V

    return-void
.end method


# virtual methods
.method public getTitle()Ljava/lang/String;
    .locals 1

    .line 14
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;->mTitle:Ljava/lang/String;

    return-object v0
.end method

.method public setTitle(I)V
    .locals 1

    .line 22
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;->mTitle:Ljava/lang/String;

    return-void
.end method

.method public setTitle(Ljava/lang/String;)V
    .locals 0

    .line 18
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;->mTitle:Ljava/lang/String;

    return-void
.end method
