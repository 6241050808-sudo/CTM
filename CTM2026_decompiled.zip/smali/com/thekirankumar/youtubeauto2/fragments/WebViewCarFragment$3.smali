.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$3;
.super Ljava/lang/Object;
.source "WebViewCarFragment.java"

# interfaces
.implements Landroid/support/car/hardware/CarSensorManager$OnSensorChangedListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V
    .locals 0

    .line 163
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$3;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onSensorChanged(Landroid/support/car/hardware/CarSensorManager;Landroid/support/car/hardware/CarSensorEvent;)V
    .locals 1

    .line 167
    :try_start_0
    iget p1, p2, Landroid/support/car/hardware/CarSensorEvent;->sensorType:I

    const/4 v0, 0x6

    if-ne p1, v0, :cond_0

    .line 168
    invoke-virtual {p2}, Landroid/support/car/hardware/CarSensorEvent;->getParkingBrakeData()Landroid/support/car/hardware/CarSensorEvent$ParkingBrakeData;

    move-result-object p1

    if-eqz p1, :cond_1

    .line 170
    iget-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$3;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    iget-boolean p1, p1, Landroid/support/car/hardware/CarSensorEvent$ParkingBrakeData;->isEngaged:Z

    invoke-virtual {p2, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->setParkingBrake(Z)V

    goto :goto_0

    .line 172
    :cond_0
    iget p1, p2, Landroid/support/car/hardware/CarSensorEvent;->sensorType:I

    const/4 v0, 0x2

    if-ne p1, v0, :cond_1

    .line 173
    invoke-virtual {p2}, Landroid/support/car/hardware/CarSensorEvent;->getCarSpeedData()Landroid/support/car/hardware/CarSensorEvent$CarSpeedData;

    move-result-object p1

    if-eqz p1, :cond_1

    .line 175
    iget p1, p1, Landroid/support/car/hardware/CarSensorEvent$CarSpeedData;->carSpeed:F

    .line 176
    iget-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$3;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p2}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$200(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/widget/TextView;

    move-result-object p2

    if-eqz p2, :cond_1

    .line 177
    iget-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$3;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p2}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$200(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/widget/TextView;

    move-result-object p2

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setText(I)V
    :try_end_0
    .catch Ljava/lang/Error; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception p1

    .line 185
    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    goto :goto_0

    :catch_1
    move-exception p1

    .line 183
    invoke-virtual {p1}, Ljava/lang/Error;->printStackTrace()V

    :cond_1
    :goto_0
    return-void
.end method
