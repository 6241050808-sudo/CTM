.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$CustomWebViewClient$1;
.super Ljava/lang/Object;
.source "WebViewCarFragment.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$CustomWebViewClient;->onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$CustomWebViewClient;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$CustomWebViewClient;)V
    .locals 0

    .line 1295
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$CustomWebViewClient$1;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$CustomWebViewClient;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .line 1298
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$CustomWebViewClient$1;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$CustomWebViewClient;

    iget-object v0, v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$CustomWebViewClient;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$900(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->findAndClickFirstVideo()V

    return-void
.end method
