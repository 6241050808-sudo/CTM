.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;
.super Ljava/lang/Object;
.source "WebViewCarFragment.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

.field final synthetic val$view:Landroid/view/View;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Landroid/view/View;)V
    .locals 0

    .line 379
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->val$view:Landroid/view/View;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 5

    .line 382
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1600(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/speech/SpeechRecognizer;

    move-result-object p1

    if-eqz p1, :cond_0

    .line 383
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1600(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/speech/SpeechRecognizer;

    move-result-object p1

    invoke-virtual {p1}, Landroid/speech/SpeechRecognizer;->stopListening()V

    .line 384
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1600(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/speech/SpeechRecognizer;

    move-result-object p1

    invoke-virtual {p1}, Landroid/speech/SpeechRecognizer;->destroy()V

    .line 385
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1602(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Landroid/speech/SpeechRecognizer;)Landroid/speech/SpeechRecognizer;

    goto/16 :goto_0

    .line 387
    :cond_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$900(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    move-result-object p1

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->pauseVideoAndSetFlag()V

    .line 388
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->val$view:Landroid/view/View;

    const v0, 0x7f08013d

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;

    .line 389
    new-instance v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12$1;

    invoke-direct {v0, p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12$1;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;)V

    invoke-virtual {p1, v0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 396
    new-instance v0, Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener;

    new-instance v1, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12$2;

    invoke-direct {v1, p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12$2;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;)V

    invoke-direct {v0, v1}, Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener;-><init>(Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener$OnCompleteListener;)V

    .line 422
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-virtual {v1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getContext()Landroid/content/Context;

    move-result-object v1

    .line 423
    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v1}, Landroid/speech/SpeechRecognizer;->createSpeechRecognizer(Landroid/content/Context;)Landroid/speech/SpeechRecognizer;

    move-result-object v3

    invoke-static {v2, v3}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1602(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Landroid/speech/SpeechRecognizer;)Landroid/speech/SpeechRecognizer;

    .line 424
    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    new-instance v3, Landroid/content/Intent;

    const-string v4, "android.speech.action.RECOGNIZE_SPEECH"

    invoke-direct {v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-static {v2, v3}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1702(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Landroid/content/Intent;)Landroid/content/Intent;

    .line 426
    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v2}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1700(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/content/Intent;

    move-result-object v2

    const-string v3, "android.speech.extra.LANGUAGE_MODEL"

    const-string v4, "free_form"

    invoke-virtual {v2, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 428
    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v2}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1600(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/speech/SpeechRecognizer;

    move-result-object v2

    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v3}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1700(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/content/Intent;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/speech/SpeechRecognizer;->startListening(Landroid/content/Intent;)V

    const/4 v2, 0x0

    .line 430
    invoke-virtual {p1, v2}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->setVisibility(I)V

    .line 431
    invoke-virtual {p1}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->play()V

    .line 432
    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$12;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v3}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1600(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/speech/SpeechRecognizer;

    move-result-object v3

    invoke-virtual {p1, v3}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->setSpeechRecognizer(Landroid/speech/SpeechRecognizer;)V

    .line 433
    invoke-virtual {p1, v0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->setRecognitionListener(Landroid/speech/RecognitionListener;)V

    const/4 v0, 0x5

    new-array v0, v0, [I

    const v3, 0x7f0500ac

    .line 435
    invoke-static {v1, v3}, Landroidx/core/content/ContextCompat;->getColor(Landroid/content/Context;I)I

    move-result v3

    aput v3, v0, v2

    const/4 v2, 0x1

    const v3, 0x7f0500ad

    .line 436
    invoke-static {v1, v3}, Landroidx/core/content/ContextCompat;->getColor(Landroid/content/Context;I)I

    move-result v3

    aput v3, v0, v2

    const/4 v2, 0x2

    const v3, 0x7f0500ae

    .line 437
    invoke-static {v1, v3}, Landroidx/core/content/ContextCompat;->getColor(Landroid/content/Context;I)I

    move-result v3

    aput v3, v0, v2

    const/4 v2, 0x3

    const v3, 0x7f0500af

    .line 438
    invoke-static {v1, v3}, Landroidx/core/content/ContextCompat;->getColor(Landroid/content/Context;I)I

    move-result v3

    aput v3, v0, v2

    const/4 v2, 0x4

    const v3, 0x7f0500b0

    .line 439
    invoke-static {v1, v3}, Landroidx/core/content/ContextCompat;->getColor(Landroid/content/Context;I)I

    move-result v1

    aput v1, v0, v2

    .line 441
    invoke-virtual {p1, v0}, Lcom/github/zagum/speechrecognitionview/RecognitionProgressView;->setColors([I)V

    :goto_0
    return-void
.end method
