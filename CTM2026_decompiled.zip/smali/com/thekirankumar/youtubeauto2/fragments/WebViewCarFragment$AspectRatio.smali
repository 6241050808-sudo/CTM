.class public final enum Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;
.super Ljava/lang/Enum;
.source "WebViewCarFragment.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "AspectRatio"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

.field public static final enum CONTAIN:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

.field public static final enum COVER:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

.field public static final enum FILL:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .line 1239
    new-instance v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    const/4 v1, 0x0

    const-string v2, "CONTAIN"

    invoke-direct {v0, v2, v1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;->CONTAIN:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    new-instance v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    const/4 v2, 0x1

    const-string v3, "FILL"

    invoke-direct {v0, v3, v2}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;->FILL:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    new-instance v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    const/4 v3, 0x2

    const-string v4, "COVER"

    invoke-direct {v0, v4, v3}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;->COVER:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    const/4 v4, 0x3

    new-array v4, v4, [Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    .line 1238
    sget-object v5, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;->CONTAIN:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    aput-object v5, v4, v1

    sget-object v1, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;->FILL:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    aput-object v1, v4, v2

    aput-object v0, v4, v3

    sput-object v4, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;->$VALUES:[Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 1238
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;
    .locals 1

    .line 1238
    const-class v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    return-object p0
.end method

.method public static values()[Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;
    .locals 1

    .line 1238
    sget-object v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;->$VALUES:[Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    invoke-virtual {v0}, [Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    return-object v0
.end method
