.class Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$3;
.super Ljava/lang/Object;
.source "SafetyWarningFragment.java"

# interfaces
.implements Landroid/view/View$OnKeyListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;)V
    .locals 0

    .line 54
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$3;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .locals 0

    const/4 p1, 0x1

    const/4 p3, 0x4

    if-ne p2, p3, :cond_0

    .line 58
    iget-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$3;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;

    invoke-static {p2}, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;->access$000(Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;)Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$FragmentInteractionListener;

    move-result-object p2

    iget-object p3, p0, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$3;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;

    invoke-interface {p2, p3}, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$FragmentInteractionListener;->onReadyToExitSafetyInstructions(Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;)V

    return p1

    :cond_0
    const/16 p3, 0x14

    if-eq p2, p3, :cond_2

    const/16 p3, 0x13

    if-eq p2, p3, :cond_2

    const/16 p3, 0x15

    if-eq p2, p3, :cond_2

    const/16 p3, 0x16

    if-ne p2, p3, :cond_1

    goto :goto_0

    :cond_1
    const/4 p1, 0x0

    :cond_2
    :goto_0
    return p1
.end method
