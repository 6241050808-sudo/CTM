.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$6;
.super Ljava/lang/Object;
.source "WebViewCarFragment.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V
    .locals 0

    .line 332
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$6;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    .line 335
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$6;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1200(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Z

    return-void
.end method
