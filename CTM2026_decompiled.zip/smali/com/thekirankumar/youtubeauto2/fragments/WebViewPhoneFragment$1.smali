.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$1;
.super Landroid/support/v4/media/MediaBrowserCompat$ConnectionCallback;
.source "WebViewPhoneFragment.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)V
    .locals 0

    .line 234
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$1;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;

    invoke-direct {p0}, Landroid/support/v4/media/MediaBrowserCompat$ConnectionCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public onConnected()V
    .locals 3

    :try_start_0
    const-string v0, "MainActivity"

    const-string v1, "connected"

    .line 238
    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 240
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$1;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;

    .line 241
    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->access$000(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)Landroid/support/v4/media/MediaBrowserCompat;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v4/media/MediaBrowserCompat;->getSessionToken()Landroid/support/v4/media/session/MediaSessionCompat$Token;

    move-result-object v0

    .line 243
    new-instance v1, Landroid/support/v4/media/session/MediaControllerCompat;

    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$1;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;

    .line 244
    invoke-virtual {v2}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v2

    invoke-direct {v1, v2, v0}, Landroid/support/v4/media/session/MediaControllerCompat;-><init>(Landroid/content/Context;Landroid/support/v4/media/session/MediaSessionCompat$Token;)V

    .line 247
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$1;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;

    .line 248
    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object v0

    .line 247
    invoke-static {v0, v1}, Landroid/support/v4/media/session/MediaControllerCompat;->setMediaController(Landroid/app/Activity;Landroid/support/v4/media/session/MediaControllerCompat;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    return-void
.end method

.method public onConnectionFailed()V
    .locals 0

    .line 262
    invoke-super {p0}, Landroid/support/v4/media/MediaBrowserCompat$ConnectionCallback;->onConnectionFailed()V

    return-void
.end method

.method public onConnectionSuspended()V
    .locals 0

    .line 257
    invoke-super {p0}, Landroid/support/v4/media/MediaBrowserCompat$ConnectionCallback;->onConnectionSuspended()V

    return-void
.end method
