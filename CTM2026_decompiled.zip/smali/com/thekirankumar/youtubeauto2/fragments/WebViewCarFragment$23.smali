.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$23;
.super Ljava/lang/Object;
.source "WebViewCarFragment.java"

# interfaces
.implements Landroid/text/TextWatcher;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->setupEditTextMirroring(Lcom/thekirankumar/youtubeauto2/utils/CarEditText;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

.field final synthetic val$fakeEditText:Lcom/thekirankumar/youtubeauto2/utils/CarEditText;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Lcom/thekirankumar/youtubeauto2/utils/CarEditText;)V
    .locals 0

    .line 703
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$23;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$23;->val$fakeEditText:Lcom/thekirankumar/youtubeauto2/utils/CarEditText;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public afterTextChanged(Landroid/text/Editable;)V
    .locals 0

    return-void
.end method

.method public beforeTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    return-void
.end method

.method public onTextChanged(Ljava/lang/CharSequence;III)V
    .locals 0

    .line 711
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$23;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$900(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    move-result-object p1

    iget-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$23;->val$fakeEditText:Lcom/thekirankumar/youtubeauto2/utils/CarEditText;

    invoke-virtual {p2}, Lcom/thekirankumar/youtubeauto2/utils/CarEditText;->getText()Landroid/text/Editable;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->enterEditText(Ljava/lang/String;)V

    return-void
.end method
