.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$4;
.super Ljava/lang/Object;
.source "WebViewPhoneFragment.java"

# interfaces
.implements Landroid/widget/TextView$OnEditorActionListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)V
    .locals 0

    .line 328
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onEditorAction(Landroid/widget/TextView;ILandroid/view/KeyEvent;)Z
    .locals 0

    const/4 p1, 0x6

    if-eq p2, p1, :cond_1

    const/4 p1, 0x2

    if-eq p2, p1, :cond_1

    .line 334
    invoke-virtual {p3}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result p1

    const/16 p2, 0x42

    if-ne p1, p2, :cond_0

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    return p1

    .line 336
    :cond_1
    :goto_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->access$200(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)Landroid/widget/EditText;

    move-result-object p2

    iget-object p3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;

    invoke-static {p3}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->access$300(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    move-result-object p3

    invoke-static {p1, p2, p3}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->access$400(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;Landroid/widget/EditText;Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;)V

    .line 337
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->access$200(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)Landroid/widget/EditText;

    move-result-object p2

    invoke-static {p1, p2}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->access$500(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;Landroid/widget/EditText;)V

    const/4 p1, 0x1

    return p1
.end method
