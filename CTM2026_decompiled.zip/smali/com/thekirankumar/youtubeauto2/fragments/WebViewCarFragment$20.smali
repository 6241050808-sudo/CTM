.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;
.super Lcom/google/android/apps/auto/sdk/SearchCallback;
.source "WebViewCarFragment.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

.field final synthetic val$carUiController:Lcom/google/android/apps/auto/sdk/CarUiController;

.field final synthetic val$searchController:Lcom/google/android/apps/auto/sdk/SearchController;

.field final synthetic val$view:Landroid/view/View;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Lcom/google/android/apps/auto/sdk/CarUiController;Landroid/view/View;Lcom/google/android/apps/auto/sdk/SearchController;)V
    .locals 0

    .line 603
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;->val$carUiController:Lcom/google/android/apps/auto/sdk/CarUiController;

    iput-object p3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;->val$view:Landroid/view/View;

    iput-object p4, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;->val$searchController:Lcom/google/android/apps/auto/sdk/SearchController;

    invoke-direct {p0}, Lcom/google/android/apps/auto/sdk/SearchCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public onSearchItemSelected(Lcom/google/android/apps/auto/sdk/SearchItem;)V
    .locals 1

    .line 606
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-virtual {p1}, Lcom/google/android/apps/auto/sdk/SearchItem;->getTitle()Ljava/lang/CharSequence;

    move-result-object p1

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1100(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Ljava/lang/String;)V

    .line 607
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1902(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Z)Z

    .line 608
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;->val$carUiController:Lcom/google/android/apps/auto/sdk/CarUiController;

    invoke-virtual {p1}, Lcom/google/android/apps/auto/sdk/CarUiController;->getSearchController()Lcom/google/android/apps/auto/sdk/SearchController;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/android/apps/auto/sdk/SearchController;->hideSearchBox()V

    return-void
.end method

.method public onSearchSubmitted(Ljava/lang/String;)Z
    .locals 1

    .line 613
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1100(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Ljava/lang/String;)V

    .line 614
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1902(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Z)Z

    .line 615
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;->val$carUiController:Lcom/google/android/apps/auto/sdk/CarUiController;

    invoke-virtual {p1}, Lcom/google/android/apps/auto/sdk/CarUiController;->getSearchController()Lcom/google/android/apps/auto/sdk/SearchController;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/android/apps/auto/sdk/SearchController;->hideSearchBox()V

    const/4 p1, 0x1

    return p1
.end method

.method public onSearchTextChanged(Ljava/lang/String;)V
    .locals 3

    .line 621
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$2500(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/os/Handler;

    move-result-object v0

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$2400(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Ljava/lang/Runnable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 622
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    new-instance v1, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20$1;

    invoke-direct {v1, p0, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20$1;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;Ljava/lang/String;)V

    invoke-static {v0, v1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$2402(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Ljava/lang/Runnable;)Ljava/lang/Runnable;

    .line 670
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$2500(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/os/Handler;

    move-result-object p1

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$2400(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Ljava/lang/Runnable;

    move-result-object v0

    const-wide/16 v1, 0x1f4

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method
