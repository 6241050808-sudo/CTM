.class public Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;
.super Landroidx/fragment/app/Fragment;
.source "SafetyWarningFragment.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$FragmentInteractionListener;
    }
.end annotation


# instance fields
.field private appInfo:Landroid/widget/TextView;

.field private continueButton:Landroid/view/View;

.field private listener:Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$FragmentInteractionListener;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 21
    invoke-direct {p0}, Landroidx/fragment/app/Fragment;-><init>()V

    return-void
.end method

.method static synthetic access$000(Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;)Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$FragmentInteractionListener;
    .locals 0

    .line 21
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;->listener:Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$FragmentInteractionListener;

    return-object p0
.end method

.method static synthetic access$100(Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;)Landroid/view/View;
    .locals 0

    .line 21
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;->continueButton:Landroid/view/View;

    return-object p0
.end method


# virtual methods
.method public onAttach(Landroid/content/Context;)V
    .locals 1

    .line 78
    invoke-super {p0, p1}, Landroidx/fragment/app/Fragment;->onAttach(Landroid/content/Context;)V

    .line 79
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;->getParentFragment()Landroidx/fragment/app/Fragment;

    move-result-object p1

    .line 80
    instance-of v0, p1, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$FragmentInteractionListener;

    if-eqz v0, :cond_0

    .line 81
    check-cast p1, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$FragmentInteractionListener;

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;->listener:Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$FragmentInteractionListener;

    :cond_0
    return-void
.end method

.method public onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .locals 1

    const p3, 0x7f0b006e

    const/4 v0, 0x0

    .line 29
    invoke-virtual {p1, p3, p2, v0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    return-object p1
.end method

.method public onResume()V
    .locals 1

    .line 72
    invoke-super {p0}, Landroidx/fragment/app/Fragment;->onResume()V

    .line 73
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;->continueButton:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->requestFocus()Z

    return-void
.end method

.method public onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
    .locals 2

    .line 34
    invoke-super {p0, p1, p2}, Landroidx/fragment/app/Fragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V

    const p2, 0x7f080047

    .line 35
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/TextView;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;->appInfo:Landroid/widget/TextView;

    .line 36
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const v1, 0x7f10001d

    invoke-virtual {p0, v1}, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " v"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "2.0.5"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const p2, 0x7f08006a

    .line 37
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;->continueButton:Landroid/view/View;

    .line 38
    new-instance p2, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$1;

    invoke-direct {p2, p0}, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$1;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;)V

    invoke-virtual {p1, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 44
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;->continueButton:Landroid/view/View;

    const/4 p2, 0x1

    invoke-virtual {p1, p2}, Landroid/view/View;->setFocusable(Z)V

    .line 45
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;->continueButton:Landroid/view/View;

    invoke-virtual {p1, p2}, Landroid/view/View;->setFocusableInTouchMode(Z)V

    .line 46
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;->continueButton:Landroid/view/View;

    new-instance p2, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$2;

    invoke-direct {p2, p0}, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$2;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;)V

    invoke-virtual {p1, p2}, Landroid/view/View;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    .line 54
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;->continueButton:Landroid/view/View;

    new-instance p2, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$3;

    invoke-direct {p2, p0}, Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment$3;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/SafetyWarningFragment;)V

    invoke-virtual {p1, p2}, Landroid/view/View;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    return-void
.end method
