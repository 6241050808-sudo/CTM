.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$7;
.super Ljava/lang/Object;
.source "WebViewCarFragment.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V
    .locals 0

    .line 339
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$7;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1

    .line 342
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$7;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$900(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    move-result-object p1

    const-string v0, "https://www.youtube.com"

    invoke-virtual {p1, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method
