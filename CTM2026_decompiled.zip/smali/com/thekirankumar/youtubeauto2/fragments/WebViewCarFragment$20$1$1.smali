.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20$1$1;
.super Ljava/lang/Object;
.source "WebViewCarFragment.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20$1;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$2:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20$1;

.field final synthetic val$results:Ljava/util/ArrayList;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20$1;Ljava/util/ArrayList;)V
    .locals 0

    .line 662
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20$1$1;->this$2:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20$1;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20$1$1;->val$results:Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 665
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20$1$1;->this$2:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20$1;

    iget-object v0, v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20$1;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;

    iget-object v0, v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20;->val$searchController:Lcom/google/android/apps/auto/sdk/SearchController;

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$20$1$1;->val$results:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Lcom/google/android/apps/auto/sdk/SearchController;->setSearchItems(Ljava/util/List;)V

    return-void
.end method
