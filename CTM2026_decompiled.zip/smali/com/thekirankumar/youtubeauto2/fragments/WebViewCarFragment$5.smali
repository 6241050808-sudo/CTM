.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$5;
.super Landroid/content/BroadcastReceiver;
.source "WebViewCarFragment.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->onAttach(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V
    .locals 0

    .line 282
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$5;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 4

    if-eqz p2, :cond_5

    .line 285
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$5;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$900(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    move-result-object p1

    if-eqz p1, :cond_5

    const-wide/16 v0, 0x0

    const-string p1, "action_type"

    .line 286
    invoke-virtual {p2, p1, v0, v1}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v0

    const-wide/16 v2, 0x4

    cmp-long p1, v0, v2

    if-nez p1, :cond_0

    .line 288
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$5;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$900(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    move-result-object p1

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->playVideo()V

    goto :goto_1

    :cond_0
    const-wide/16 v2, 0x2

    cmp-long p1, v0, v2

    if-eqz p1, :cond_4

    const-wide/16 v2, 0x1

    cmp-long p1, v0, v2

    if-nez p1, :cond_1

    goto :goto_0

    :cond_1
    const-wide/16 v2, 0x20

    cmp-long p1, v0, v2

    if-nez p1, :cond_2

    .line 293
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$5;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$900(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    move-result-object p1

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->playNextTrack()V

    goto :goto_1

    :cond_2
    const-wide/16 v2, 0x10

    cmp-long p1, v0, v2

    if-nez p1, :cond_3

    .line 295
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$5;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$900(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    move-result-object p1

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->goBack()V

    goto :goto_1

    :cond_3
    const-wide/16 v2, 0x800

    cmp-long p1, v0, v2

    if-nez p1, :cond_5

    .line 297
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$5;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    const/4 v0, 0x1

    invoke-static {p1, v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1002(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Z)Z

    .line 298
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$5;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    const-string v0, "query"

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-static {p1, p2}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1100(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Ljava/lang/String;)V

    goto :goto_1

    .line 290
    :cond_4
    :goto_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$5;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$900(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    move-result-object p1

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->pauseVideo()V

    :cond_5
    :goto_1
    return-void
.end method
