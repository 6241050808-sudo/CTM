.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18$1;
.super Ljava/lang/Object;
.source "WebViewCarFragment.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18;

.field final synthetic val$aspectRatio:I

.field final synthetic val$fullScreen:Z

.field final synthetic val$url:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18;Ljava/lang/String;ZI)V
    .locals 0

    .line 561
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18$1;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18$1;->val$url:Ljava/lang/String;

    iput-boolean p3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18$1;->val$fullScreen:Z

    iput p4, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18$1;->val$aspectRatio:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 564
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18$1;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18;

    iget-object v0, v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$900(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    move-result-object v0

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18$1;->val$url:Ljava/lang/String;

    invoke-virtual {v0, v1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->loadUrl(Ljava/lang/String;)V

    .line 565
    iget-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18$1;->val$fullScreen:Z

    if-eqz v0, :cond_0

    .line 566
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18$1;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18;

    iget-object v0, v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    const/4 v1, 0x1

    invoke-static {v0, v1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$1802(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Z)Z

    .line 567
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18$1;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18;

    iget-object v0, v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18;->val$fullScreenButton:Landroid/widget/ImageButton;

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setActivated(Z)V

    .line 568
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18$1;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18;

    iget-object v0, v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18;->val$fullScreenButton:Landroid/widget/ImageButton;

    const v1, 0x7f0700c1

    invoke-virtual {v0, v1}, Landroid/widget/ImageButton;->setImageResource(I)V

    .line 570
    :cond_0
    invoke-static {}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;->values()[Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    move-result-object v0

    array-length v0, v0

    iget v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18$1;->val$aspectRatio:I

    if-le v0, v1, :cond_1

    .line 571
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18$1;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18;

    iget-object v0, v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;->values()[Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    move-result-object v1

    iget v2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18$1;->val$aspectRatio:I

    aget-object v1, v1, v2

    invoke-virtual {v0, v1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->setAspectRatio(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;)V

    :cond_1
    return-void
.end method
