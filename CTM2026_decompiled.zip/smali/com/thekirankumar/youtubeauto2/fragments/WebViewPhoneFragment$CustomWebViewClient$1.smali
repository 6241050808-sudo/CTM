.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient$1;
.super Ljava/lang/Object;
.source "WebViewPhoneFragment.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;->shouldOverrideUrlLoading(Landroid/webkit/WebView;Ljava/lang/String;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;

.field final synthetic val$url:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;Ljava/lang/String;)V
    .locals 0

    .line 540
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient$1;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient$1;->val$url:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 544
    :try_start_0
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient$1;->this$1:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;

    iget-object v0, v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$CustomWebViewClient$1;->val$url:Ljava/lang/String;

    const-string v2, "UTF-8"

    invoke-static {v1, v2}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->access$600(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .line 546
    invoke-virtual {v0}, Ljava/io/UnsupportedEncodingException;->printStackTrace()V

    :goto_0
    return-void
.end method
