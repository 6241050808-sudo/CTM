.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$21;
.super Ljava/lang/Object;
.source "WebViewCarFragment.java"

# interfaces
.implements Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient$ToggledFullscreenCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

.field final synthetic val$carUiController:Lcom/google/android/apps/auto/sdk/CarUiController;

.field final synthetic val$searchController:Lcom/google/android/apps/auto/sdk/SearchController;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Lcom/google/android/apps/auto/sdk/SearchController;Lcom/google/android/apps/auto/sdk/CarUiController;)V
    .locals 0

    .line 674
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$21;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$21;->val$searchController:Lcom/google/android/apps/auto/sdk/SearchController;

    iput-object p3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$21;->val$carUiController:Lcom/google/android/apps/auto/sdk/CarUiController;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public toggledFullscreen(Z)V
    .locals 1

    const/4 v0, 0x0

    if-eqz p1, :cond_0

    .line 678
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$21;->val$searchController:Lcom/google/android/apps/auto/sdk/SearchController;

    invoke-virtual {p1}, Lcom/google/android/apps/auto/sdk/SearchController;->hideSearchBox()V

    .line 679
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$21;->val$carUiController:Lcom/google/android/apps/auto/sdk/CarUiController;

    invoke-virtual {p1}, Lcom/google/android/apps/auto/sdk/CarUiController;->getStatusBarController()Lcom/google/android/apps/auto/sdk/StatusBarController;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/android/apps/auto/sdk/StatusBarController;->hideAppHeader()V

    .line 680
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$21;->val$carUiController:Lcom/google/android/apps/auto/sdk/CarUiController;

    invoke-virtual {p1}, Lcom/google/android/apps/auto/sdk/CarUiController;->getStatusBarController()Lcom/google/android/apps/auto/sdk/StatusBarController;

    move-result-object p1

    invoke-virtual {p1}, Lcom/google/android/apps/auto/sdk/StatusBarController;->hideConnectivityLevel()V

    .line 681
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$21;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$000(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V

    .line 682
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$21;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1, v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$100(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Z)V

    goto :goto_0

    .line 684
    :cond_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$21;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$2600(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V

    .line 685
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$21;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1, v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$100(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Z)V

    :goto_0
    return-void
.end method
