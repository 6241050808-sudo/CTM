.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18;
.super Ljava/lang/Object;
.source "WebViewCarFragment.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

.field final synthetic val$fullScreenButton:Landroid/widget/ImageButton;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Landroid/widget/ImageButton;)V
    .locals 0

    .line 555
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18;->val$fullScreenButton:Landroid/widget/ImageButton;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    .line 558
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$2300(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/content/SharedPreferences;

    move-result-object v0

    const-string v1, "home_url"

    const-string v2, "https://www.youtube.com"

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    .line 559
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$2300(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/content/SharedPreferences;

    move-result-object v1

    const/4 v2, 0x0

    const-string v3, "fullscreen"

    invoke-interface {v1, v3, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    .line 560
    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v3}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$2300(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/content/SharedPreferences;

    move-result-object v3

    const-string v4, "aspect_ratio"

    invoke-interface {v3, v4, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    .line 561
    new-instance v3, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v4

    invoke-direct {v3, v4}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v4, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18$1;

    invoke-direct {v4, p0, v0, v1, v2}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18$1;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$18;Ljava/lang/String;ZI)V

    invoke-virtual {v3, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method
