.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$5;
.super Ljava/lang/Object;
.source "WebViewPhoneFragment.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->askForRecordAudioPermission()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;)V
    .locals 0

    .line 403
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$5;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 3

    .line 406
    invoke-interface {p1}, Landroid/content/DialogInterface;->cancel()V

    .line 407
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment$5;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewPhoneFragment;->getActivity()Landroidx/fragment/app/FragmentActivity;

    move-result-object p1

    const/4 p2, 0x1

    new-array v0, p2, [Ljava/lang/String;

    const/4 v1, 0x0

    const-string v2, "android.permission.RECORD_AUDIO"

    aput-object v2, v0, v1

    invoke-static {p1, v0, p2}, Landroidx/core/app/ActivityCompat;->requestPermissions(Landroid/app/Activity;[Ljava/lang/String;I)V

    return-void
.end method
