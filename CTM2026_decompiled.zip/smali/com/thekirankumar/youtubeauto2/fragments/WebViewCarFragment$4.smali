.class Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;
.super Landroid/support/car/CarConnectionCallback;
.source "WebViewCarFragment.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V
    .locals 0

    .line 189
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-direct {p0}, Landroid/support/car/CarConnectionCallback;-><init>()V

    return-void
.end method


# virtual methods
.method public onConnected(Landroid/support/car/Car;)V
    .locals 6

    const-string v0, "sensor"

    const/4 v1, 0x0

    .line 193
    :try_start_0
    invoke-virtual {p1, v0}, Landroid/support/car/Car;->getCarManager(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/car/hardware/CarSensorManager;

    .line 194
    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v3, v2}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$302(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Landroid/support/car/hardware/CarSensorManager;)Landroid/support/car/hardware/CarSensorManager;

    .line 195
    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v2, p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$402(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Landroid/support/car/Car;)Landroid/support/car/Car;

    .line 196
    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v2}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$500(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)V

    .line 198
    invoke-virtual {p1, v0}, Landroid/support/car/Car;->getCarManager(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/support/car/hardware/CarSensorManager;

    .line 199
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$600(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/support/car/hardware/CarSensorManager$OnSensorChangedListener;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p1, v0, v3, v2}, Landroid/support/car/hardware/CarSensorManager;->addListener(Landroid/support/car/hardware/CarSensorManager$OnSensorChangedListener;II)Z

    if-eqz p1, :cond_1

    .line 202
    invoke-virtual {p1, v3}, Landroid/support/car/hardware/CarSensorManager;->isSensorSupported(I)Z

    move-result v0

    if-eqz v0, :cond_1

    .line 203
    invoke-virtual {p1, v3}, Landroid/support/car/hardware/CarSensorManager;->getLatestSensorEvent(I)Landroid/support/car/hardware/CarSensorEvent;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 205
    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {v2}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$600(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/support/car/hardware/CarSensorManager$OnSensorChangedListener;

    move-result-object v2

    invoke-interface {v2, p1, v0}, Landroid/support/car/hardware/CarSensorManager$OnSensorChangedListener;->onSensorChanged(Landroid/support/car/hardware/CarSensorManager;Landroid/support/car/hardware/CarSensorEvent;)V

    goto :goto_0

    .line 207
    :cond_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-virtual {p1, v1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->setParkingBrake(Z)V

    goto :goto_0

    .line 210
    :cond_1
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-virtual {p1, v1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->setParkingBrake(Z)V

    .line 213
    :goto_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    new-instance v0, Landroid/support/v4/media/MediaBrowserCompat;

    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-virtual {v2}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getContext()Landroid/content/Context;

    move-result-object v2

    new-instance v3, Landroid/content/ComponentName;

    iget-object v4, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-virtual {v4}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->getContext()Landroid/content/Context;

    move-result-object v4

    const-class v5, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;

    invoke-direct {v3, v4, v5}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    new-instance v4, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4$1;

    invoke-direct {v4, p0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4$1;-><init>(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;)V

    const/4 v5, 0x0

    invoke-direct {v0, v2, v3, v4, v5}, Landroid/support/v4/media/MediaBrowserCompat;-><init>(Landroid/content/Context;Landroid/content/ComponentName;Landroid/support/v4/media/MediaBrowserCompat$ConnectionCallback;Landroid/os/Bundle;)V

    invoke-static {p1, v0}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$702(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;Landroid/support/v4/media/MediaBrowserCompat;)Landroid/support/v4/media/MediaBrowserCompat;

    .line 246
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->access$700(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;)Landroid/support/v4/media/MediaBrowserCompat;

    move-result-object p1

    invoke-virtual {p1}, Landroid/support/v4/media/MediaBrowserCompat;->connect()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_1

    :catch_0
    move-exception p1

    .line 249
    invoke-virtual {p1}, Ljava/lang/Exception;->printStackTrace()V

    .line 250
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-virtual {p1, v1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;->setParkingBrake(Z)V

    :goto_1
    return-void
.end method

.method public onDisconnected(Landroid/support/car/Car;)V
    .locals 1

    const-string p1, "WebViewCarFragment"

    const-string v0, "Disconnected from car"

    .line 256
    invoke-static {p1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method
