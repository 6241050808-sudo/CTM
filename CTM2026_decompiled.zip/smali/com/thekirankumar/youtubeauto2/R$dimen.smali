.class public final Lcom/thekirankumar/youtubeauto2/R$dimen;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thekirankumar/youtubeauto2/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "dimen"
.end annotation


# static fields
.field public static final abc_action_bar_content_inset_material:I = 0x7f060000

.field public static final abc_action_bar_content_inset_with_nav:I = 0x7f060001

.field public static final abc_action_bar_default_height_material:I = 0x7f060002

.field public static final abc_action_bar_default_padding_end_material:I = 0x7f060003

.field public static final abc_action_bar_default_padding_start_material:I = 0x7f060004

.field public static final abc_action_bar_elevation_material:I = 0x7f060005

.field public static final abc_action_bar_icon_vertical_padding_material:I = 0x7f060006

.field public static final abc_action_bar_overflow_padding_end_material:I = 0x7f060007

.field public static final abc_action_bar_overflow_padding_start_material:I = 0x7f060008

.field public static final abc_action_bar_stacked_max_height:I = 0x7f060009

.field public static final abc_action_bar_stacked_tab_max_width:I = 0x7f06000a

.field public static final abc_action_bar_subtitle_bottom_margin_material:I = 0x7f06000b

.field public static final abc_action_bar_subtitle_top_margin_material:I = 0x7f06000c

.field public static final abc_action_button_min_height_material:I = 0x7f06000d

.field public static final abc_action_button_min_width_material:I = 0x7f06000e

.field public static final abc_action_button_min_width_overflow_material:I = 0x7f06000f

.field public static final abc_alert_dialog_button_bar_height:I = 0x7f060010

.field public static final abc_alert_dialog_button_dimen:I = 0x7f060011

.field public static final abc_button_inset_horizontal_material:I = 0x7f060012

.field public static final abc_button_inset_vertical_material:I = 0x7f060013

.field public static final abc_button_padding_horizontal_material:I = 0x7f060014

.field public static final abc_button_padding_vertical_material:I = 0x7f060015

.field public static final abc_cascading_menus_min_smallest_width:I = 0x7f060016

.field public static final abc_config_prefDialogWidth:I = 0x7f060017

.field public static final abc_control_corner_material:I = 0x7f060018

.field public static final abc_control_inset_material:I = 0x7f060019

.field public static final abc_control_padding_material:I = 0x7f06001a

.field public static final abc_dialog_corner_radius_material:I = 0x7f06001b

.field public static final abc_dialog_fixed_height_major:I = 0x7f06001c

.field public static final abc_dialog_fixed_height_minor:I = 0x7f06001d

.field public static final abc_dialog_fixed_width_major:I = 0x7f06001e

.field public static final abc_dialog_fixed_width_minor:I = 0x7f06001f

.field public static final abc_dialog_list_padding_bottom_no_buttons:I = 0x7f060020

.field public static final abc_dialog_list_padding_top_no_title:I = 0x7f060021

.field public static final abc_dialog_min_width_major:I = 0x7f060022

.field public static final abc_dialog_min_width_minor:I = 0x7f060023

.field public static final abc_dialog_padding_material:I = 0x7f060024

.field public static final abc_dialog_padding_top_material:I = 0x7f060025

.field public static final abc_dialog_title_divider_material:I = 0x7f060026

.field public static final abc_disabled_alpha_material_dark:I = 0x7f060027

.field public static final abc_disabled_alpha_material_light:I = 0x7f060028

.field public static final abc_dropdownitem_icon_width:I = 0x7f060029

.field public static final abc_dropdownitem_text_padding_left:I = 0x7f06002a

.field public static final abc_dropdownitem_text_padding_right:I = 0x7f06002b

.field public static final abc_edit_text_inset_bottom_material:I = 0x7f06002c

.field public static final abc_edit_text_inset_horizontal_material:I = 0x7f06002d

.field public static final abc_edit_text_inset_top_material:I = 0x7f06002e

.field public static final abc_floating_window_z:I = 0x7f06002f

.field public static final abc_list_item_height_large_material:I = 0x7f060030

.field public static final abc_list_item_height_material:I = 0x7f060031

.field public static final abc_list_item_height_small_material:I = 0x7f060032

.field public static final abc_list_item_padding_horizontal_material:I = 0x7f060033

.field public static final abc_panel_menu_list_width:I = 0x7f060034

.field public static final abc_progress_bar_height_material:I = 0x7f060035

.field public static final abc_search_view_preferred_height:I = 0x7f060036

.field public static final abc_search_view_preferred_width:I = 0x7f060037

.field public static final abc_seekbar_track_background_height_material:I = 0x7f060038

.field public static final abc_seekbar_track_progress_height_material:I = 0x7f060039

.field public static final abc_select_dialog_padding_start_material:I = 0x7f06003a

.field public static final abc_switch_padding:I = 0x7f06003b

.field public static final abc_text_size_body_1_material:I = 0x7f06003c

.field public static final abc_text_size_body_2_material:I = 0x7f06003d

.field public static final abc_text_size_button_material:I = 0x7f06003e

.field public static final abc_text_size_caption_material:I = 0x7f06003f

.field public static final abc_text_size_display_1_material:I = 0x7f060040

.field public static final abc_text_size_display_2_material:I = 0x7f060041

.field public static final abc_text_size_display_3_material:I = 0x7f060042

.field public static final abc_text_size_display_4_material:I = 0x7f060043

.field public static final abc_text_size_headline_material:I = 0x7f060044

.field public static final abc_text_size_large_material:I = 0x7f060045

.field public static final abc_text_size_medium_material:I = 0x7f060046

.field public static final abc_text_size_menu_header_material:I = 0x7f060047

.field public static final abc_text_size_menu_material:I = 0x7f060048

.field public static final abc_text_size_small_material:I = 0x7f060049

.field public static final abc_text_size_subhead_material:I = 0x7f06004a

.field public static final abc_text_size_subtitle_material_toolbar:I = 0x7f06004b

.field public static final abc_text_size_title_material:I = 0x7f06004c

.field public static final abc_text_size_title_material_toolbar:I = 0x7f06004d

.field public static final action_bar_size:I = 0x7f06004e

.field public static final appcompat_dialog_background_inset:I = 0x7f06004f

.field public static final car_abc_keyboard_filter_delete_btn_size:I = 0x7f060050

.field public static final car_abc_keyboard_filter_text_width:I = 0x7f060051

.field public static final car_action_bar_icon_padding:I = 0x7f060052

.field public static final car_action_bar_margin:I = 0x7f060053

.field public static final car_app_layout_icon_width:I = 0x7f060054

.field public static final car_app_layout_search_box_small_margin:I = 0x7f060055

.field public static final car_app_layout_search_box_small_width:I = 0x7f060056

.field public static final car_body_1_size:I = 0x7f060057

.field public static final car_body_2_size:I = 0x7f060058

.field public static final car_caption_size:I = 0x7f060059

.field public static final car_card_bottom_margin:I = 0x7f06005a

.field public static final car_card_margin:I = 0x7f06005b

.field public static final car_card_max_width:I = 0x7f06005c

.field public static final car_card_view_corner_radius:I = 0x7f06005d

.field public static final car_card_view_elevation:I = 0x7f06005e

.field public static final car_divider_height:I = 0x7f06005f

.field public static final car_drawer_header_cardview_overlay_width:I = 0x7f060060

.field public static final car_drawer_header_height:I = 0x7f060061

.field public static final car_drawer_header_menu_button_size:I = 0x7f060062

.field public static final car_drawer_item_max_width:I = 0x7f060063

.field public static final car_drawer_margin_right:I = 0x7f060064

.field public static final car_drawer_max_width:I = 0x7f060065

.field public static final car_drawer_standard_width:I = 0x7f060066

.field public static final car_fab_focused_growth:I = 0x7f060067

.field public static final car_fab_focused_stroke_width:I = 0x7f060068

.field public static final car_filter_icon_height:I = 0x7f060069

.field public static final car_filter_icon_margin_end:I = 0x7f06006a

.field public static final car_filter_icon_size:I = 0x7f06006b

.field public static final car_filter_icon_width:I = 0x7f06006c

.field public static final car_filter_number_margin_start:I = 0x7f06006d

.field public static final car_headline_1_size:I = 0x7f06006e

.field public static final car_headline_2_size:I = 0x7f06006f

.field public static final car_icon:I = 0x7f060070

.field public static final car_last_card_peek_amount:I = 0x7f060071

.field public static final car_list_item_height:I = 0x7f060072

.field public static final car_list_item_height_small:I = 0x7f060073

.field public static final car_list_item_icon_right_margin:I = 0x7f060074

.field public static final car_list_item_icon_size:I = 0x7f060075

.field public static final car_list_item_icon_size_extra_small:I = 0x7f060076

.field public static final car_list_item_icon_size_small:I = 0x7f060077

.field public static final car_list_item_right_icon_margin:I = 0x7f060078

.field public static final car_max_drawer_width:I = 0x7f060079

.field public static final car_micro_size:I = 0x7f06007a

.field public static final car_min_card_size:I = 0x7f06007b

.field public static final car_min_up_down_button_height:I = 0x7f06007c

.field public static final car_paged_list_view_button_background_inset:I = 0x7f06007d

.field public static final car_paged_list_view_pagination_width:I = 0x7f06007e

.field public static final car_paged_list_view_scrollbar_thumb_margin:I = 0x7f06007f

.field public static final car_sample_row_height:I = 0x7f060080

.field public static final car_standard_elevation:I = 0x7f060081

.field public static final car_standard_margin:I = 0x7f060082

.field public static final car_standard_medium_size:I = 0x7f060083

.field public static final car_standard_small_size:I = 0x7f060084

.field public static final car_standard_width:I = 0x7f060085

.field public static final car_text_vertical_margin:I = 0x7f060086

.field public static final car_title_size:I = 0x7f060087

.field public static final car_toast_horizontal_padding:I = 0x7f060088

.field public static final car_toast_padding:I = 0x7f060089

.field public static final car_touch_feedback_radius:I = 0x7f06008a

.field public static final cardview_compat_inset_shadow:I = 0x7f06008b

.field public static final cardview_default_elevation:I = 0x7f06008c

.field public static final cardview_default_radius:I = 0x7f06008d

.field public static final compat_button_inset_horizontal_material:I = 0x7f06008e

.field public static final compat_button_inset_vertical_material:I = 0x7f06008f

.field public static final compat_button_padding_horizontal_material:I = 0x7f060090

.field public static final compat_button_padding_vertical_material:I = 0x7f060091

.field public static final compat_control_corner_material:I = 0x7f060092

.field public static final compat_notification_large_icon_max_height:I = 0x7f060093

.field public static final compat_notification_large_icon_max_width:I = 0x7f060094

.field public static final default_dimension:I = 0x7f060095

.field public static final design_appbar_elevation:I = 0x7f060096

.field public static final design_bottom_navigation_active_item_max_width:I = 0x7f060097

.field public static final design_bottom_navigation_active_item_min_width:I = 0x7f060098

.field public static final design_bottom_navigation_active_text_size:I = 0x7f060099

.field public static final design_bottom_navigation_elevation:I = 0x7f06009a

.field public static final design_bottom_navigation_height:I = 0x7f06009b

.field public static final design_bottom_navigation_icon_size:I = 0x7f06009c

.field public static final design_bottom_navigation_item_max_width:I = 0x7f06009d

.field public static final design_bottom_navigation_item_min_width:I = 0x7f06009e

.field public static final design_bottom_navigation_margin:I = 0x7f06009f

.field public static final design_bottom_navigation_shadow_height:I = 0x7f0600a0

.field public static final design_bottom_navigation_text_size:I = 0x7f0600a1

.field public static final design_bottom_sheet_elevation:I = 0x7f0600a2

.field public static final design_bottom_sheet_modal_elevation:I = 0x7f0600a3

.field public static final design_bottom_sheet_peek_height_min:I = 0x7f0600a4

.field public static final design_fab_border_width:I = 0x7f0600a5

.field public static final design_fab_elevation:I = 0x7f0600a6

.field public static final design_fab_image_size:I = 0x7f0600a7

.field public static final design_fab_size_mini:I = 0x7f0600a8

.field public static final design_fab_size_normal:I = 0x7f0600a9

.field public static final design_fab_translation_z_hovered_focused:I = 0x7f0600aa

.field public static final design_fab_translation_z_pressed:I = 0x7f0600ab

.field public static final design_navigation_elevation:I = 0x7f0600ac

.field public static final design_navigation_icon_padding:I = 0x7f0600ad

.field public static final design_navigation_icon_size:I = 0x7f0600ae

.field public static final design_navigation_item_horizontal_padding:I = 0x7f0600af

.field public static final design_navigation_item_icon_padding:I = 0x7f0600b0

.field public static final design_navigation_max_width:I = 0x7f0600b1

.field public static final design_navigation_padding_bottom:I = 0x7f0600b2

.field public static final design_navigation_separator_vertical_padding:I = 0x7f0600b3

.field public static final design_snackbar_action_inline_max_width:I = 0x7f0600b4

.field public static final design_snackbar_action_text_color_alpha:I = 0x7f0600b5

.field public static final design_snackbar_background_corner_radius:I = 0x7f0600b6

.field public static final design_snackbar_elevation:I = 0x7f0600b7

.field public static final design_snackbar_extra_spacing_horizontal:I = 0x7f0600b8

.field public static final design_snackbar_max_width:I = 0x7f0600b9

.field public static final design_snackbar_min_width:I = 0x7f0600ba

.field public static final design_snackbar_padding_horizontal:I = 0x7f0600bb

.field public static final design_snackbar_padding_vertical:I = 0x7f0600bc

.field public static final design_snackbar_padding_vertical_2lines:I = 0x7f0600bd

.field public static final design_snackbar_text_size:I = 0x7f0600be

.field public static final design_tab_max_width:I = 0x7f0600bf

.field public static final design_tab_scrollable_min_width:I = 0x7f0600c0

.field public static final design_tab_text_size:I = 0x7f0600c1

.field public static final design_tab_text_size_2line:I = 0x7f0600c2

.field public static final design_textinput_caption_translate_y:I = 0x7f0600c3

.field public static final disabled_alpha_material_dark:I = 0x7f0600c4

.field public static final disabled_alpha_material_light:I = 0x7f0600c5

.field public static final exo_media_button_height:I = 0x7f0600c6

.field public static final exo_media_button_width:I = 0x7f0600c7

.field public static final fastscroll_default_thickness:I = 0x7f0600c8

.field public static final fastscroll_margin:I = 0x7f0600c9

.field public static final fastscroll_minimum_range:I = 0x7f0600ca

.field public static final highlight_alpha_material_colored:I = 0x7f0600cb

.field public static final highlight_alpha_material_dark:I = 0x7f0600cc

.field public static final highlight_alpha_material_light:I = 0x7f0600cd

.field public static final hint_alpha_material_dark:I = 0x7f0600ce

.field public static final hint_alpha_material_light:I = 0x7f0600cf

.field public static final hint_pressed_alpha_material_dark:I = 0x7f0600d0

.field public static final hint_pressed_alpha_material_light:I = 0x7f0600d1

.field public static final item_touch_helper_max_drag_scroll_per_frame:I = 0x7f0600d2

.field public static final item_touch_helper_swipe_escape_max_velocity:I = 0x7f0600d3

.field public static final item_touch_helper_swipe_escape_velocity:I = 0x7f0600d4

.field public static final material_emphasis_disabled:I = 0x7f0600d5

.field public static final material_emphasis_high_type:I = 0x7f0600d6

.field public static final material_emphasis_medium:I = 0x7f0600d7

.field public static final material_text_view_test_line_height:I = 0x7f0600d8

.field public static final material_text_view_test_line_height_override:I = 0x7f0600d9

.field public static final max_thumb_height:I = 0x7f0600da

.field public static final min_thumb_height:I = 0x7f0600db

.field public static final mtrl_alert_dialog_background_inset_bottom:I = 0x7f0600dc

.field public static final mtrl_alert_dialog_background_inset_end:I = 0x7f0600dd

.field public static final mtrl_alert_dialog_background_inset_start:I = 0x7f0600de

.field public static final mtrl_alert_dialog_background_inset_top:I = 0x7f0600df

.field public static final mtrl_alert_dialog_picker_background_inset:I = 0x7f0600e0

.field public static final mtrl_badge_horizontal_edge_offset:I = 0x7f0600e1

.field public static final mtrl_badge_long_text_horizontal_padding:I = 0x7f0600e2

.field public static final mtrl_badge_radius:I = 0x7f0600e3

.field public static final mtrl_badge_text_horizontal_edge_offset:I = 0x7f0600e4

.field public static final mtrl_badge_text_size:I = 0x7f0600e5

.field public static final mtrl_badge_with_text_radius:I = 0x7f0600e6

.field public static final mtrl_bottomappbar_fabOffsetEndMode:I = 0x7f0600e7

.field public static final mtrl_bottomappbar_fab_bottom_margin:I = 0x7f0600e8

.field public static final mtrl_bottomappbar_fab_cradle_margin:I = 0x7f0600e9

.field public static final mtrl_bottomappbar_fab_cradle_rounded_corner_radius:I = 0x7f0600ea

.field public static final mtrl_bottomappbar_fab_cradle_vertical_offset:I = 0x7f0600eb

.field public static final mtrl_bottomappbar_height:I = 0x7f0600ec

.field public static final mtrl_btn_corner_radius:I = 0x7f0600ed

.field public static final mtrl_btn_dialog_btn_min_width:I = 0x7f0600ee

.field public static final mtrl_btn_disabled_elevation:I = 0x7f0600ef

.field public static final mtrl_btn_disabled_z:I = 0x7f0600f0

.field public static final mtrl_btn_elevation:I = 0x7f0600f1

.field public static final mtrl_btn_focused_z:I = 0x7f0600f2

.field public static final mtrl_btn_hovered_z:I = 0x7f0600f3

.field public static final mtrl_btn_icon_btn_padding_left:I = 0x7f0600f4

.field public static final mtrl_btn_icon_padding:I = 0x7f0600f5

.field public static final mtrl_btn_inset:I = 0x7f0600f6

.field public static final mtrl_btn_letter_spacing:I = 0x7f0600f7

.field public static final mtrl_btn_padding_bottom:I = 0x7f0600f8

.field public static final mtrl_btn_padding_left:I = 0x7f0600f9

.field public static final mtrl_btn_padding_right:I = 0x7f0600fa

.field public static final mtrl_btn_padding_top:I = 0x7f0600fb

.field public static final mtrl_btn_pressed_z:I = 0x7f0600fc

.field public static final mtrl_btn_stroke_size:I = 0x7f0600fd

.field public static final mtrl_btn_text_btn_icon_padding:I = 0x7f0600fe

.field public static final mtrl_btn_text_btn_padding_left:I = 0x7f0600ff

.field public static final mtrl_btn_text_btn_padding_right:I = 0x7f060100

.field public static final mtrl_btn_text_size:I = 0x7f060101

.field public static final mtrl_btn_z:I = 0x7f060102

.field public static final mtrl_calendar_action_height:I = 0x7f060103

.field public static final mtrl_calendar_action_padding:I = 0x7f060104

.field public static final mtrl_calendar_bottom_padding:I = 0x7f060105

.field public static final mtrl_calendar_content_padding:I = 0x7f060106

.field public static final mtrl_calendar_day_corner:I = 0x7f060107

.field public static final mtrl_calendar_day_height:I = 0x7f060108

.field public static final mtrl_calendar_day_horizontal_padding:I = 0x7f060109

.field public static final mtrl_calendar_day_today_stroke:I = 0x7f06010a

.field public static final mtrl_calendar_day_vertical_padding:I = 0x7f06010b

.field public static final mtrl_calendar_day_width:I = 0x7f06010c

.field public static final mtrl_calendar_days_of_week_height:I = 0x7f06010d

.field public static final mtrl_calendar_dialog_background_inset:I = 0x7f06010e

.field public static final mtrl_calendar_header_content_padding:I = 0x7f06010f

.field public static final mtrl_calendar_header_content_padding_fullscreen:I = 0x7f060110

.field public static final mtrl_calendar_header_divider_thickness:I = 0x7f060111

.field public static final mtrl_calendar_header_height:I = 0x7f060112

.field public static final mtrl_calendar_header_height_fullscreen:I = 0x7f060113

.field public static final mtrl_calendar_header_selection_line_height:I = 0x7f060114

.field public static final mtrl_calendar_header_text_padding:I = 0x7f060115

.field public static final mtrl_calendar_header_toggle_margin_bottom:I = 0x7f060116

.field public static final mtrl_calendar_header_toggle_margin_top:I = 0x7f060117

.field public static final mtrl_calendar_landscape_header_width:I = 0x7f060118

.field public static final mtrl_calendar_maximum_default_fullscreen_minor_axis:I = 0x7f060119

.field public static final mtrl_calendar_month_horizontal_padding:I = 0x7f06011a

.field public static final mtrl_calendar_month_vertical_padding:I = 0x7f06011b

.field public static final mtrl_calendar_navigation_bottom_padding:I = 0x7f06011c

.field public static final mtrl_calendar_navigation_height:I = 0x7f06011d

.field public static final mtrl_calendar_navigation_top_padding:I = 0x7f06011e

.field public static final mtrl_calendar_pre_l_text_clip_padding:I = 0x7f06011f

.field public static final mtrl_calendar_selection_baseline_to_top_fullscreen:I = 0x7f060120

.field public static final mtrl_calendar_selection_text_baseline_to_bottom:I = 0x7f060121

.field public static final mtrl_calendar_selection_text_baseline_to_bottom_fullscreen:I = 0x7f060122

.field public static final mtrl_calendar_selection_text_baseline_to_top:I = 0x7f060123

.field public static final mtrl_calendar_text_input_padding_top:I = 0x7f060124

.field public static final mtrl_calendar_title_baseline_to_top:I = 0x7f060125

.field public static final mtrl_calendar_title_baseline_to_top_fullscreen:I = 0x7f060126

.field public static final mtrl_calendar_year_corner:I = 0x7f060127

.field public static final mtrl_calendar_year_height:I = 0x7f060128

.field public static final mtrl_calendar_year_horizontal_padding:I = 0x7f060129

.field public static final mtrl_calendar_year_vertical_padding:I = 0x7f06012a

.field public static final mtrl_calendar_year_width:I = 0x7f06012b

.field public static final mtrl_card_checked_icon_margin:I = 0x7f06012c

.field public static final mtrl_card_checked_icon_size:I = 0x7f06012d

.field public static final mtrl_card_corner_radius:I = 0x7f06012e

.field public static final mtrl_card_dragged_z:I = 0x7f06012f

.field public static final mtrl_card_elevation:I = 0x7f060130

.field public static final mtrl_card_spacing:I = 0x7f060131

.field public static final mtrl_chip_pressed_translation_z:I = 0x7f060132

.field public static final mtrl_chip_text_size:I = 0x7f060133

.field public static final mtrl_exposed_dropdown_menu_popup_elevation:I = 0x7f060134

.field public static final mtrl_exposed_dropdown_menu_popup_vertical_offset:I = 0x7f060135

.field public static final mtrl_exposed_dropdown_menu_popup_vertical_padding:I = 0x7f060136

.field public static final mtrl_extended_fab_bottom_padding:I = 0x7f060137

.field public static final mtrl_extended_fab_corner_radius:I = 0x7f060138

.field public static final mtrl_extended_fab_disabled_elevation:I = 0x7f060139

.field public static final mtrl_extended_fab_disabled_translation_z:I = 0x7f06013a

.field public static final mtrl_extended_fab_elevation:I = 0x7f06013b

.field public static final mtrl_extended_fab_end_padding:I = 0x7f06013c

.field public static final mtrl_extended_fab_end_padding_icon:I = 0x7f06013d

.field public static final mtrl_extended_fab_icon_size:I = 0x7f06013e

.field public static final mtrl_extended_fab_icon_text_spacing:I = 0x7f06013f

.field public static final mtrl_extended_fab_min_height:I = 0x7f060140

.field public static final mtrl_extended_fab_min_width:I = 0x7f060141

.field public static final mtrl_extended_fab_start_padding:I = 0x7f060142

.field public static final mtrl_extended_fab_start_padding_icon:I = 0x7f060143

.field public static final mtrl_extended_fab_top_padding:I = 0x7f060144

.field public static final mtrl_extended_fab_translation_z_base:I = 0x7f060145

.field public static final mtrl_extended_fab_translation_z_hovered_focused:I = 0x7f060146

.field public static final mtrl_extended_fab_translation_z_pressed:I = 0x7f060147

.field public static final mtrl_fab_elevation:I = 0x7f060148

.field public static final mtrl_fab_min_touch_target:I = 0x7f060149

.field public static final mtrl_fab_translation_z_hovered_focused:I = 0x7f06014a

.field public static final mtrl_fab_translation_z_pressed:I = 0x7f06014b

.field public static final mtrl_high_ripple_default_alpha:I = 0x7f06014c

.field public static final mtrl_high_ripple_focused_alpha:I = 0x7f06014d

.field public static final mtrl_high_ripple_hovered_alpha:I = 0x7f06014e

.field public static final mtrl_high_ripple_pressed_alpha:I = 0x7f06014f

.field public static final mtrl_large_touch_target:I = 0x7f060150

.field public static final mtrl_low_ripple_default_alpha:I = 0x7f060151

.field public static final mtrl_low_ripple_focused_alpha:I = 0x7f060152

.field public static final mtrl_low_ripple_hovered_alpha:I = 0x7f060153

.field public static final mtrl_low_ripple_pressed_alpha:I = 0x7f060154

.field public static final mtrl_min_touch_target_size:I = 0x7f060155

.field public static final mtrl_navigation_elevation:I = 0x7f060156

.field public static final mtrl_navigation_item_horizontal_padding:I = 0x7f060157

.field public static final mtrl_navigation_item_icon_padding:I = 0x7f060158

.field public static final mtrl_navigation_item_icon_size:I = 0x7f060159

.field public static final mtrl_navigation_item_shape_horizontal_margin:I = 0x7f06015a

.field public static final mtrl_navigation_item_shape_vertical_margin:I = 0x7f06015b

.field public static final mtrl_shape_corner_size_large_component:I = 0x7f06015c

.field public static final mtrl_shape_corner_size_medium_component:I = 0x7f06015d

.field public static final mtrl_shape_corner_size_small_component:I = 0x7f06015e

.field public static final mtrl_snackbar_action_text_color_alpha:I = 0x7f06015f

.field public static final mtrl_snackbar_background_corner_radius:I = 0x7f060160

.field public static final mtrl_snackbar_background_overlay_color_alpha:I = 0x7f060161

.field public static final mtrl_snackbar_margin:I = 0x7f060162

.field public static final mtrl_switch_thumb_elevation:I = 0x7f060163

.field public static final mtrl_textinput_box_corner_radius_medium:I = 0x7f060164

.field public static final mtrl_textinput_box_corner_radius_small:I = 0x7f060165

.field public static final mtrl_textinput_box_label_cutout_padding:I = 0x7f060166

.field public static final mtrl_textinput_box_stroke_width_default:I = 0x7f060167

.field public static final mtrl_textinput_box_stroke_width_focused:I = 0x7f060168

.field public static final mtrl_textinput_end_icon_margin_start:I = 0x7f060169

.field public static final mtrl_textinput_outline_box_expanded_padding:I = 0x7f06016a

.field public static final mtrl_textinput_start_icon_margin_end:I = 0x7f06016b

.field public static final mtrl_toolbar_default_height:I = 0x7f06016c

.field public static final notification_action_icon_size:I = 0x7f06016d

.field public static final notification_action_text_size:I = 0x7f06016e

.field public static final notification_big_circle_margin:I = 0x7f06016f

.field public static final notification_content_margin_start:I = 0x7f060170

.field public static final notification_large_icon_height:I = 0x7f060171

.field public static final notification_large_icon_width:I = 0x7f060172

.field public static final notification_main_column_padding_top:I = 0x7f060173

.field public static final notification_media_narrow_margin:I = 0x7f060174

.field public static final notification_right_icon_size:I = 0x7f060175

.field public static final notification_right_side_padding_top:I = 0x7f060176

.field public static final notification_small_icon_background_padding:I = 0x7f060177

.field public static final notification_small_icon_size_as_large:I = 0x7f060178

.field public static final notification_subtext_size:I = 0x7f060179

.field public static final notification_top_pad:I = 0x7f06017a

.field public static final notification_top_pad_large_text:I = 0x7f06017b

.field public static final rail_height:I = 0x7f06017c

.field public static final subtitle_corner_radius:I = 0x7f06017d

.field public static final subtitle_outline_width:I = 0x7f06017e

.field public static final subtitle_shadow_offset:I = 0x7f06017f

.field public static final subtitle_shadow_radius:I = 0x7f060180

.field public static final test_mtrl_calendar_day_cornerSize:I = 0x7f060181

.field public static final tooltip_corner_radius:I = 0x7f060182

.field public static final tooltip_horizontal_padding:I = 0x7f060183

.field public static final tooltip_margin:I = 0x7f060184

.field public static final tooltip_precise_anchor_extra_offset:I = 0x7f060185

.field public static final tooltip_precise_anchor_threshold:I = 0x7f060186

.field public static final tooltip_vertical_padding:I = 0x7f060187

.field public static final tooltip_y_offset_non_touch:I = 0x7f060188

.field public static final tooltip_y_offset_touch:I = 0x7f060189


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
