.class public Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService$MediaCallBack;
.super Landroid/support/v4/media/session/MediaSessionCompat$Callback;
.source "MyMediaBrowserService.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "MediaCallBack"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;


# direct methods
.method public constructor <init>(Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;)V
    .locals 0

    .line 120
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService$MediaCallBack;->this$0:Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;

    invoke-direct {p0}, Landroid/support/v4/media/session/MediaSessionCompat$Callback;-><init>()V

    return-void
.end method


# virtual methods
.method public onPause()V
    .locals 1

    .line 142
    invoke-super {p0}, Landroid/support/v4/media/session/MediaSessionCompat$Callback;->onPause()V

    .line 143
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService$MediaCallBack;->this$0:Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/utils/BroadcastFromPlayer;->broadcastPauseClicked(Landroid/content/Context;)V

    return-void
.end method

.method public onPlay()V
    .locals 1

    .line 136
    invoke-super {p0}, Landroid/support/v4/media/session/MediaSessionCompat$Callback;->onPlay()V

    .line 137
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService$MediaCallBack;->this$0:Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/utils/BroadcastFromPlayer;->broadcastPlayClicked(Landroid/content/Context;)V

    return-void
.end method

.method public onPlayFromSearch(Ljava/lang/String;Landroid/os/Bundle;)V
    .locals 0

    .line 154
    invoke-super {p0, p1, p2}, Landroid/support/v4/media/session/MediaSessionCompat$Callback;->onPlayFromSearch(Ljava/lang/String;Landroid/os/Bundle;)V

    if-eqz p1, :cond_0

    .line 156
    iget-object p2, p0, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService$MediaCallBack;->this$0:Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;

    invoke-static {p2, p1}, Lcom/thekirankumar/youtubeauto2/utils/BroadcastFromPlayer;->broadcastVoiceSearch(Landroid/content/Context;Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method public onPrepare()V
    .locals 0

    .line 148
    invoke-super {p0}, Landroid/support/v4/media/session/MediaSessionCompat$Callback;->onPrepare()V

    return-void
.end method

.method public onSkipToNext()V
    .locals 1

    .line 130
    invoke-super {p0}, Landroid/support/v4/media/session/MediaSessionCompat$Callback;->onSkipToNext()V

    .line 131
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService$MediaCallBack;->this$0:Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/utils/BroadcastFromPlayer;->broadcastNextClicked(Landroid/content/Context;)V

    return-void
.end method

.method public onSkipToPrevious()V
    .locals 1

    .line 123
    invoke-super {p0}, Landroid/support/v4/media/session/MediaSessionCompat$Callback;->onSkipToPrevious()V

    .line 124
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService$MediaCallBack;->this$0:Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/utils/BroadcastFromPlayer;->broadcastPreviousClicked(Landroid/content/Context;)V

    return-void
.end method

.method public onStop()V
    .locals 1

    .line 162
    invoke-super {p0}, Landroid/support/v4/media/session/MediaSessionCompat$Callback;->onStop()V

    .line 163
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService$MediaCallBack;->this$0:Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/utils/BroadcastFromPlayer;->broadcastPauseClicked(Landroid/content/Context;)V

    return-void
.end method
