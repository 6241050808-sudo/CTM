.class Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService$1;
.super Landroid/content/BroadcastReceiver;
.source "MyMediaBrowserService.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;->setup()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;)V
    .locals 0

    .line 66
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService$1;->this$0:Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 4

    .line 69
    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/utils/SettingsUtils;->isDisabledNotifications(Landroid/content/Context;)Z

    move-result p1

    if-nez p1, :cond_0

    const-string p1, "title"

    .line 70
    invoke-virtual {p2, p1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_0

    .line 72
    new-instance v0, Landroid/support/v4/media/MediaMetadataCompat$Builder;

    invoke-direct {v0}, Landroid/support/v4/media/MediaMetadataCompat$Builder;-><init>()V

    const-string v1, "android.media.metadata.TITLE"

    .line 73
    invoke-virtual {v0, v1, p1}, Landroid/support/v4/media/MediaMetadataCompat$Builder;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/support/v4/media/MediaMetadataCompat$Builder;

    .line 74
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService$1;->this$0:Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;->access$000(Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;)Landroid/support/v4/media/session/MediaSessionCompat;

    move-result-object p1

    invoke-virtual {v0}, Landroid/support/v4/media/MediaMetadataCompat$Builder;->build()Landroid/support/v4/media/MediaMetadataCompat;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/support/v4/media/session/MediaSessionCompat;->setMetadata(Landroid/support/v4/media/MediaMetadataCompat;)V

    .line 77
    :cond_0
    new-instance p1, Landroid/support/v4/media/session/PlaybackStateCompat$Builder;

    invoke-direct {p1}, Landroid/support/v4/media/session/PlaybackStateCompat$Builder;-><init>()V

    const/4 v0, 0x0

    const-string v1, "state"

    .line 78
    invoke-virtual {p2, v1, v0}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p2

    const-wide/16 v1, 0x0

    const/high16 v3, 0x3f800000    # 1.0f

    .line 79
    invoke-virtual {p1, p2, v1, v2, v3}, Landroid/support/v4/media/session/PlaybackStateCompat$Builder;->setState(IJF)Landroid/support/v4/media/session/PlaybackStateCompat$Builder;

    .line 80
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService$1;->this$0:Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;

    invoke-static {v1}, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;->access$100(Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;)J

    move-result-wide v1

    invoke-virtual {p1, v1, v2}, Landroid/support/v4/media/session/PlaybackStateCompat$Builder;->setActions(J)Landroid/support/v4/media/session/PlaybackStateCompat$Builder;

    .line 81
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService$1;->this$0:Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;

    invoke-static {v1}, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;->access$000(Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;)Landroid/support/v4/media/session/MediaSessionCompat;

    move-result-object v1

    invoke-virtual {p1}, Landroid/support/v4/media/session/PlaybackStateCompat$Builder;->build()Landroid/support/v4/media/session/PlaybackStateCompat;

    move-result-object p1

    invoke-virtual {v1, p1}, Landroid/support/v4/media/session/MediaSessionCompat;->setPlaybackState(Landroid/support/v4/media/session/PlaybackStateCompat;)V

    const/4 p1, 0x3

    const/4 v1, 0x1

    if-ne p2, p1, :cond_1

    .line 83
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService$1;->this$0:Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;->access$000(Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;)Landroid/support/v4/media/session/MediaSessionCompat;

    move-result-object p1

    invoke-virtual {p1, v1}, Landroid/support/v4/media/session/MediaSessionCompat;->setActive(Z)V

    goto :goto_0

    :cond_1
    if-ne p2, v1, :cond_2

    .line 85
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService$1;->this$0:Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;->access$000(Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;)Landroid/support/v4/media/session/MediaSessionCompat;

    move-result-object p1

    invoke-virtual {p1, v0}, Landroid/support/v4/media/session/MediaSessionCompat;->setActive(Z)V

    :cond_2
    :goto_0
    return-void
.end method
