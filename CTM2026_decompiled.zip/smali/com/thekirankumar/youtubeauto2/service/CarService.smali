.class public Lcom/thekirankumar/youtubeauto2/service/CarService;
.super Lcom/google/android/apps/auto/sdk/CarActivityService;
.source "CarService.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 7
    invoke-direct {p0}, Lcom/google/android/apps/auto/sdk/CarActivityService;-><init>()V

    return-void
.end method


# virtual methods
.method public getCarActivity()Ljava/lang/Class;
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/lang/Class<",
            "+",
            "Lcom/google/android/apps/auto/sdk/CarActivity;",
            ">;"
        }
    .end annotation

    .line 9
    const-class v0, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;

    return-object v0
.end method
