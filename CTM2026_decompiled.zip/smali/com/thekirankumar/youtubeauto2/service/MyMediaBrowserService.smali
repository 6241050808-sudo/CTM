.class public Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;
.super Landroidx/media/MediaBrowserServiceCompat;
.source "MyMediaBrowserService.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService$MediaCallBack;
    }
.end annotation


# static fields
.field public static final ACTION_TYPE:Ljava/lang/String; = "action_type"

.field public static final MEDIA_TITLE:Ljava/lang/String; = "title"

.field public static final PLAYBACK_STATE:Ljava/lang/String; = "state"

.field public static final PLAYER_EVENT:Ljava/lang/String; = "com.thekirankumar.youtubeauto2.player.event"

.field public static final QUERY:Ljava/lang/String; = "query"

.field private static final TAG:Ljava/lang/String;

.field public static final WEBVIEW_EVENT:Ljava/lang/String; = "com.thekirankumar.youtubeauto2.webview.event"


# instance fields
.field private mediaSessionCompat:Landroid/support/v4/media/session/MediaSessionCompat;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 39
    const-class v0, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;->TAG:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 31
    invoke-direct {p0}, Landroidx/media/MediaBrowserServiceCompat;-><init>()V

    return-void
.end method

.method static synthetic access$000(Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;)Landroid/support/v4/media/session/MediaSessionCompat;
    .locals 0

    .line 31
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;->mediaSessionCompat:Landroid/support/v4/media/session/MediaSessionCompat;

    return-object p0
.end method

.method static synthetic access$100(Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;)J
    .locals 2

    .line 31
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;->getAvailableActions()J

    move-result-wide v0

    return-wide v0
.end method

.method private getAvailableActions()J
    .locals 2

    const-wide/16 v0, 0xe30

    return-wide v0
.end method

.method private setup()V
    .locals 5

    .line 57
    new-instance v0, Landroid/support/v4/media/session/PlaybackStateCompat$Builder;

    invoke-direct {v0}, Landroid/support/v4/media/session/PlaybackStateCompat$Builder;-><init>()V

    .line 58
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;->getAvailableActions()J

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Landroid/support/v4/media/session/PlaybackStateCompat$Builder;->setActions(J)Landroid/support/v4/media/session/PlaybackStateCompat$Builder;

    const/4 v1, 0x1

    const-wide/16 v2, 0x0

    const/high16 v4, 0x3f800000    # 1.0f

    .line 59
    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/support/v4/media/session/PlaybackStateCompat$Builder;->setState(IJF)Landroid/support/v4/media/session/PlaybackStateCompat$Builder;

    .line 60
    invoke-static {p0}, Lcom/thekirankumar/youtubeauto2/utils/SettingsUtils;->isDisabledNotifications(Landroid/content/Context;)Z

    move-result v1

    if-nez v1, :cond_0

    .line 61
    new-instance v1, Landroid/support/v4/media/MediaMetadataCompat$Builder;

    invoke-direct {v1}, Landroid/support/v4/media/MediaMetadataCompat$Builder;-><init>()V

    const-string v2, "android.media.metadata.TITLE"

    const-string v3, "Click last icon in bottom bar & start playing from Youtube Auto app"

    .line 62
    invoke-virtual {v1, v2, v3}, Landroid/support/v4/media/MediaMetadataCompat$Builder;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/support/v4/media/MediaMetadataCompat$Builder;

    .line 63
    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;->mediaSessionCompat:Landroid/support/v4/media/session/MediaSessionCompat;

    invoke-virtual {v1}, Landroid/support/v4/media/MediaMetadataCompat$Builder;->build()Landroid/support/v4/media/MediaMetadataCompat;

    move-result-object v1

    invoke-virtual {v2, v1}, Landroid/support/v4/media/session/MediaSessionCompat;->setMetadata(Landroid/support/v4/media/MediaMetadataCompat;)V

    .line 65
    :cond_0
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;->mediaSessionCompat:Landroid/support/v4/media/session/MediaSessionCompat;

    invoke-virtual {v0}, Landroid/support/v4/media/session/PlaybackStateCompat$Builder;->build()Landroid/support/v4/media/session/PlaybackStateCompat;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/support/v4/media/session/MediaSessionCompat;->setPlaybackState(Landroid/support/v4/media/session/PlaybackStateCompat;)V

    .line 66
    new-instance v0, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService$1;

    invoke-direct {v0, p0}, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService$1;-><init>(Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;)V

    new-instance v1, Landroid/content/IntentFilter;

    const-string v2, "com.thekirankumar.youtubeauto2.webview.event"

    invoke-direct {v1, v2}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0, v1}, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    return-void
.end method


# virtual methods
.method public onCreate()V
    .locals 2

    .line 44
    invoke-super {p0}, Landroidx/media/MediaBrowserServiceCompat;->onCreate()V

    .line 45
    new-instance v0, Landroid/support/v4/media/session/MediaSessionCompat;

    const-string v1, "youtube"

    invoke-direct {v0, p0, v1}, Landroid/support/v4/media/session/MediaSessionCompat;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;->mediaSessionCompat:Landroid/support/v4/media/session/MediaSessionCompat;

    .line 46
    new-instance v1, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService$MediaCallBack;

    invoke-direct {v1, p0}, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService$MediaCallBack;-><init>(Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;)V

    invoke-virtual {v0, v1}, Landroid/support/v4/media/session/MediaSessionCompat;->setCallback(Landroid/support/v4/media/session/MediaSessionCompat$Callback;)V

    .line 47
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;->mediaSessionCompat:Landroid/support/v4/media/session/MediaSessionCompat;

    const/4 v1, 0x3

    invoke-virtual {v0, v1}, Landroid/support/v4/media/session/MediaSessionCompat;->setFlags(I)V

    .line 50
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;->mediaSessionCompat:Landroid/support/v4/media/session/MediaSessionCompat;

    invoke-virtual {v0}, Landroid/support/v4/media/session/MediaSessionCompat;->getSessionToken()Landroid/support/v4/media/session/MediaSessionCompat$Token;

    move-result-object v0

    invoke-virtual {p0, v0}, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;->setSessionToken(Landroid/support/v4/media/session/MediaSessionCompat$Token;)V

    .line 51
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;->setup()V

    return-void
.end method

.method public onGetRoot(Ljava/lang/String;ILandroid/os/Bundle;)Landroidx/media/MediaBrowserServiceCompat$BrowserRoot;
    .locals 0

    .line 111
    new-instance p1, Landroidx/media/MediaBrowserServiceCompat$BrowserRoot;

    const-string p2, "youtube"

    const/4 p3, 0x0

    invoke-direct {p1, p2, p3}, Landroidx/media/MediaBrowserServiceCompat$BrowserRoot;-><init>(Ljava/lang/String;Landroid/os/Bundle;)V

    return-object p1
.end method

.method public onLoadChildren(Ljava/lang/String;Landroidx/media/MediaBrowserServiceCompat$Result;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Landroidx/media/MediaBrowserServiceCompat$Result<",
            "Ljava/util/List<",
            "Landroid/support/v4/media/MediaBrowserCompat$MediaItem;",
            ">;>;)V"
        }
    .end annotation

    .line 116
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object p1

    invoke-virtual {p2, p1}, Landroidx/media/MediaBrowserServiceCompat$Result;->sendResult(Ljava/lang/Object;)V

    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 1

    .line 104
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/service/MyMediaBrowserService;->mediaSessionCompat:Landroid/support/v4/media/session/MediaSessionCompat;

    invoke-static {v0, p1}, Landroidx/media/session/MediaButtonReceiver;->handleIntent(Landroid/support/v4/media/session/MediaSessionCompat;Landroid/content/Intent;)Landroid/view/KeyEvent;

    .line 105
    invoke-super {p0, p1, p2, p3}, Landroidx/media/MediaBrowserServiceCompat;->onStartCommand(Landroid/content/Intent;II)I

    move-result p1

    return p1
.end method
