.class Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$4;
.super Ljava/lang/Object;
.source "BookmarksFragment.java"

# interfaces
.implements Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;)V
    .locals 0

    .line 110
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onGlobalLayout()V
    .locals 2

    .line 115
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->access$200(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;)Landroidx/recyclerview/widget/RecyclerView;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/view/ViewTreeObserver;->removeOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 116
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->access$200(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;)Landroidx/recyclerview/widget/RecyclerView;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->smoothScrollToPosition(I)V

    .line 117
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->access$200(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;)Landroidx/recyclerview/widget/RecyclerView;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->getChildCount()I

    move-result v0

    if-lez v0, :cond_0

    .line 118
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$4;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->access$200(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;)Landroidx/recyclerview/widget/RecyclerView;

    move-result-object v0

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->requestFocus()Z

    :cond_0
    return-void
.end method
