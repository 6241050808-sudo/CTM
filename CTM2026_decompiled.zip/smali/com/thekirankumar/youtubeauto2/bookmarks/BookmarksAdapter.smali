.class public Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;
.super Landroidx/recyclerview/widget/RecyclerView$Adapter;
.source "BookmarksAdapter.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/recyclerview/widget/RecyclerView$Adapter<",
        "Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;",
        ">;"
    }
.end annotation


# instance fields
.field private addCurrentBookmark:Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;

.field private bookmarks:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;",
            ">;"
        }
    .end annotation
.end field

.field private bookmarksClickCallback:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

.field private deleteMode:Z


# direct methods
.method public constructor <init>(Ljava/util/ArrayList;)V
    .locals 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;",
            ">;)V"
        }
    .end annotation

    .line 29
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$Adapter;-><init>()V

    .line 25
    new-instance v0, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;

    invoke-direct {v0}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;-><init>()V

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->addCurrentBookmark:Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;

    .line 30
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->bookmarks:Ljava/util/ArrayList;

    const/4 p1, 0x1

    .line 31
    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->setHasStableIds(Z)V

    return-void
.end method

.method static synthetic access$000(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;)Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;
    .locals 0

    .line 23
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->bookmarksClickCallback:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

    return-object p0
.end method

.method static synthetic access$100(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;)Z
    .locals 0

    .line 23
    iget-boolean p0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->deleteMode:Z

    return p0
.end method

.method static synthetic access$102(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;Z)Z
    .locals 0

    .line 23
    iput-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->deleteMode:Z

    return p1
.end method


# virtual methods
.method public getItemCount()I
    .locals 1

    .line 132
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->bookmarks:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v0, v0, 0x1

    return v0
.end method

.method public getItemId(I)J
    .locals 2

    .line 40
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->bookmarks:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_0

    .line 41
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->bookmarks:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;

    .line 42
    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->isValid()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 43
    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->getCreatedAt()J

    move-result-wide v0

    return-wide v0

    :cond_0
    const-wide/16 v0, 0x0

    return-wide v0
.end method

.method public bridge synthetic onBindViewHolder(Landroidx/recyclerview/widget/RecyclerView$ViewHolder;I)V
    .locals 0

    .line 23
    check-cast p1, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;

    invoke-virtual {p0, p1, p2}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->onBindViewHolder(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;I)V

    return-void
.end method

.method public onBindViewHolder(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;I)V
    .locals 3

    .line 57
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->bookmarks:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    if-ge p2, v0, :cond_1

    .line 58
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->bookmarks:Ljava/util/ArrayList;

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;

    .line 59
    invoke-virtual {p1, p2}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;->setBookmark(Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V

    .line 60
    iget-object v0, p1, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;->itemView:Landroid/view/View;

    new-instance v2, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$1;

    invoke-direct {v2, p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$1;-><init>(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 74
    iget-object v0, p1, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;->itemView:Landroid/view/View;

    new-instance v2, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$2;

    invoke-direct {v2, p0, p2}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$2;-><init>(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 86
    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;->access$200(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;)Landroid/widget/ImageView;

    move-result-object v0

    new-instance v2, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$3;

    invoke-direct {v2, p0, p2}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$3;-><init>(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V

    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 92
    iget-object v0, p1, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;->itemView:Landroid/view/View;

    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Landroid/view/View;->setLongClickable(Z)V

    .line 93
    iget-object v0, p1, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;->itemView:Landroid/view/View;

    new-instance v2, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$4;

    invoke-direct {v2, p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$4;-><init>(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;)V

    invoke-virtual {v0, v2}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    .line 105
    invoke-virtual {p2}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->isPreventDelete()Z

    move-result p2

    if-eqz p2, :cond_0

    .line 106
    invoke-virtual {p1, v1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;->setDeleteMode(Z)V

    goto :goto_0

    .line 108
    :cond_0
    iget-boolean p2, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->deleteMode:Z

    invoke-virtual {p1, p2}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;->setDeleteMode(Z)V

    goto :goto_0

    .line 111
    :cond_1
    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;->access$300(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;)Landroid/widget/TextView;

    move-result-object p2

    const v0, 0x7f10001c

    invoke-virtual {p2, v0}, Landroid/widget/TextView;->setText(I)V

    .line 112
    iget-object p2, p1, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;->itemView:Landroid/view/View;

    new-instance v0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$5;

    invoke-direct {v0, p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$5;-><init>(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;)V

    invoke-virtual {p2, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 124
    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;->access$400(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;)Landroid/widget/ImageView;

    move-result-object p2

    const v0, 0x7f07005c

    invoke-virtual {p2, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 125
    invoke-virtual {p1, v1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;->setDeleteMode(Z)V

    :goto_0
    return-void
.end method

.method public bridge synthetic onCreateViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/RecyclerView$ViewHolder;
    .locals 0

    .line 23
    invoke-virtual {p0, p1, p2}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->onCreateViewHolder(Landroid/view/ViewGroup;I)Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;

    move-result-object p1

    return-object p1
.end method

.method public onCreateViewHolder(Landroid/view/ViewGroup;I)Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;
    .locals 1

    .line 51
    new-instance p2, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-direct {p2, p0, v0, p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;-><init>(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;Landroid/content/Context;Landroid/view/ViewGroup;)V

    return-object p2
.end method

.method public setBookmarks(Ljava/util/ArrayList;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;",
            ">;)V"
        }
    .end annotation

    .line 136
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->bookmarks:Ljava/util/ArrayList;

    return-void
.end method

.method public setBookmarksClickCallback(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;)V
    .locals 0

    .line 35
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->bookmarksClickCallback:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

    return-void
.end method
