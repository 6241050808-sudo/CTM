.class Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$3;
.super Ljava/lang/Object;
.source "BookmarksAdapter.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->onBindViewHolder(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

.field final synthetic val$bookmark:Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V
    .locals 0

    .line 86
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$3;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$3;->val$bookmark:Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1

    .line 89
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$3;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->access$000(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;)Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

    move-result-object p1

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$3;->val$bookmark:Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;

    invoke-interface {p1, v0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;->onBookmarkDelete(Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V

    return-void
.end method
