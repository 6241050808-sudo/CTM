.class Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$3;
.super Ljava/lang/Object;
.source "BookmarksFragment.java"

# interfaces
.implements Lio/realm/OrderedRealmCollectionChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lio/realm/OrderedRealmCollectionChangeListener<",
        "Lio/realm/RealmResults<",
        "Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;",
        ">;>;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;

.field final synthetic val$bookmarksAdapter:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;)V
    .locals 0

    .line 97
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$3;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$3;->val$bookmarksAdapter:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onChange(Lio/realm/RealmResults;Lio/realm/OrderedCollectionChangeSet;)V
    .locals 1
    .param p2    # Lio/realm/OrderedCollectionChangeSet;
        .annotation runtime Ljavax/annotation/Nullable;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/realm/RealmResults<",
            "Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;",
            ">;",
            "Lio/realm/OrderedCollectionChangeSet;",
            ")V"
        }
    .end annotation

    .line 100
    iget-object p2, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$3;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;

    invoke-virtual {p2}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->isAdded()Z

    move-result p2

    if-eqz p2, :cond_0

    iget-object p2, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$3;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;

    invoke-virtual {p2}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->getContext()Landroid/content/Context;

    move-result-object p2

    if-eqz p2, :cond_0

    .line 101
    new-instance p2, Ljava/util/ArrayList;

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$3;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->access$100(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;)Ljava/util/ArrayList;

    move-result-object v0

    invoke-direct {p2, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 102
    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 103
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$3;->val$bookmarksAdapter:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    invoke-virtual {p1, p2}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->setBookmarks(Ljava/util/ArrayList;)V

    .line 104
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$3;->val$bookmarksAdapter:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->notifyDataSetChanged()V

    :cond_0
    return-void
.end method

.method public bridge synthetic onChange(Ljava/lang/Object;Lio/realm/OrderedCollectionChangeSet;)V
    .locals 0
    .param p2    # Lio/realm/OrderedCollectionChangeSet;
        .annotation runtime Ljavax/annotation/Nullable;
        .end annotation
    .end param

    .line 97
    check-cast p1, Lio/realm/RealmResults;

    invoke-virtual {p0, p1, p2}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$3;->onChange(Lio/realm/RealmResults;Lio/realm/OrderedCollectionChangeSet;)V

    return-void
.end method
