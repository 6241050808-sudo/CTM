.class Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$1;
.super Ljava/lang/Object;
.source "BookmarksAdapter.java"

# interfaces
.implements Landroid/view/View$OnKeyListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->onBindViewHolder(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;)V
    .locals 0

    .line 60
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$1;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .locals 1

    .line 63
    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result p1

    const/4 p3, 0x0

    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    const/4 p1, 0x4

    if-eq p2, p1, :cond_0

    return p3

    .line 66
    :cond_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$1;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->access$000(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;)Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

    move-result-object p1

    invoke-interface {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;->onBookmarkFragmentClose()V

    return v0

    :cond_1
    return p3
.end method
