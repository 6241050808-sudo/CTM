.class Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$5;
.super Ljava/lang/Object;
.source "BookmarksAdapter.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->onBindViewHolder(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;)V
    .locals 0

    .line 112
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$5;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1

    .line 115
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$5;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->access$100(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;)Z

    move-result p1

    if-eqz p1, :cond_0

    .line 116
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$5;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->access$102(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;Z)Z

    .line 118
    :cond_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$5;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->notifyDataSetChanged()V

    .line 119
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$5;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->access$000(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;)Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

    move-result-object p1

    if-eqz p1, :cond_1

    .line 120
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$5;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->access$000(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;)Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

    move-result-object p1

    invoke-interface {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;->onBookmarkAddCurrentPage()V

    :cond_1
    return-void
.end method
