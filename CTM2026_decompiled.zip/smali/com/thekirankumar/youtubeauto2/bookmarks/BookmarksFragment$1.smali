.class Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$1;
.super Ljava/lang/Object;
.source "BookmarksFragment.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;)V
    .locals 0

    .line 61
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$1;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 0

    .line 64
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$1;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->access$000(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;)Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

    move-result-object p1

    invoke-interface {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;->onBookmarkFragmentClose()V

    return-void
.end method
