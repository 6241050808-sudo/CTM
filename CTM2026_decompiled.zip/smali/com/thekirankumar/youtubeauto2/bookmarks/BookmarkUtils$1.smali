.class final Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1;
.super Ljava/lang/Object;
.source "BookmarkUtils.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils;->addBookmark(Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation


# instance fields
.field final synthetic val$webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;)V
    .locals 0

    .line 21
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1;->val$webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    .line 24
    new-instance v0, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;

    invoke-direct {v0}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;-><init>()V

    .line 25
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1;->val$webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getTitle()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->setTitle(Ljava/lang/String;)V

    .line 26
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1;->val$webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getUrl()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->setUrl(Ljava/lang/String;)V

    .line 27
    invoke-static {}, Lio/realm/Realm;->getDefaultInstance()Lio/realm/Realm;

    move-result-object v1

    .line 29
    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1;->val$webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v2}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getMeasuredWidth()I

    move-result v2

    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1;->val$webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v3}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getMeasuredHeight()I

    move-result v3

    sget-object v4, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {v2, v3, v4}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 30
    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1;->val$webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v3}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getMeasuredWidth()I

    move-result v3

    int-to-float v3, v3

    iget-object v4, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1;->val$webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v4}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getMeasuredHeight()I

    move-result v4

    int-to-float v4, v4

    div-float/2addr v3, v4

    .line 31
    new-instance v4, Landroid/graphics/Canvas;

    invoke-direct {v4, v2}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    .line 32
    iget-object v5, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1;->val$webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v5, v4}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->draw(Landroid/graphics/Canvas;)V

    .line 34
    iget-object v4, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1;->val$webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v4}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    .line 35
    invoke-virtual {v4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v4

    const/4 v5, 0x1

    const/high16 v6, 0x43340000    # 180.0f

    invoke-static {v5, v6, v4}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result v4

    const/high16 v5, 0x40400000    # 3.0f

    mul-float v4, v4, v5

    float-to-int v5, v4

    div-float/2addr v4, v3

    float-to-int v3, v4

    const/4 v4, 0x0

    .line 37
    invoke-static {v2, v5, v3, v4}, Landroid/graphics/Bitmap;->createScaledBitmap(Landroid/graphics/Bitmap;IIZ)Landroid/graphics/Bitmap;

    move-result-object v2

    .line 38
    new-instance v3, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v3}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 39
    sget-object v4, Landroid/graphics/Bitmap$CompressFormat;->JPEG:Landroid/graphics/Bitmap$CompressFormat;

    const/16 v5, 0x64

    invoke-virtual {v2, v4, v5, v3}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    .line 40
    invoke-virtual {v3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v2

    .line 41
    invoke-virtual {v0, v2}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->setThumbnail([B)V

    .line 43
    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1;->val$webView:Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;

    invoke-virtual {v2}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->getFavicon()Landroid/graphics/Bitmap;

    move-result-object v2

    if-eqz v2, :cond_0

    .line 45
    new-instance v3, Ljava/io/ByteArrayOutputStream;

    invoke-direct {v3}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 46
    sget-object v4, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;

    const/16 v5, 0x50

    invoke-virtual {v2, v4, v5, v3}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    .line 47
    invoke-virtual {v3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v2

    .line 48
    invoke-virtual {v0, v2}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->setFavicon([B)V

    .line 51
    :cond_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    invoke-virtual {v0, v2, v3}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->setCreatedAt(J)V

    .line 52
    new-instance v2, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1$1;

    invoke-direct {v2, p0, v0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1$1;-><init>(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1;Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V

    invoke-virtual {v1, v2}, Lio/realm/Realm;->executeTransaction(Lio/realm/Realm$Transaction;)V

    return-void
.end method
