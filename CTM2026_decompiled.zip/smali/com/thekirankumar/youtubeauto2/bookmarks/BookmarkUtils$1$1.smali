.class Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1$1;
.super Ljava/lang/Object;
.source "BookmarkUtils.java"

# interfaces
.implements Lio/realm/Realm$Transaction;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1;

.field final synthetic val$bookmark:Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1;Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V
    .locals 0

    .line 52
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1$1;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1$1;->val$bookmark:Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public execute(Lio/realm/Realm;)V
    .locals 1

    .line 55
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1$1;->val$bookmark:Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;

    invoke-virtual {p1, v0}, Lio/realm/Realm;->insert(Lio/realm/RealmModel;)V

    return-void
.end method
