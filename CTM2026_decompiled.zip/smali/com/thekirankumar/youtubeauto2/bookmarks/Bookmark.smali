.class public Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;
.super Lio/realm/RealmObject;
.source "Bookmark.java"

# interfaces
.implements Lio/realm/BookmarkRealmProxyInterface;


# instance fields
.field private createdAt:J

.field private favicon:[B

.field private faviconPath:Ljava/lang/String;

.field private faviconResource:I

.field private preventDelete:Z

.field private thumbnail:[B

.field private thumbnailResource:I

.field private title:Ljava/lang/String;

.field private url:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 24
    invoke-direct {p0}, Lio/realm/RealmObject;-><init>()V

    instance-of v0, p0, Lio/realm/internal/RealmObjectProxy;

    if-eqz v0, :cond_0

    move-object v0, p0

    check-cast v0, Lio/realm/internal/RealmObjectProxy;

    invoke-interface {v0}, Lio/realm/internal/RealmObjectProxy;->realm$injectObjectContext()V

    :cond_0
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILjava/lang/String;I)V
    .locals 1

    .line 34
    invoke-direct {p0}, Lio/realm/RealmObject;-><init>()V

    instance-of v0, p0, Lio/realm/internal/RealmObjectProxy;

    if-eqz v0, :cond_0

    move-object v0, p0

    check-cast v0, Lio/realm/internal/RealmObjectProxy;

    invoke-interface {v0}, Lio/realm/internal/RealmObjectProxy;->realm$injectObjectContext()V

    .line 35
    :cond_0
    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmSet$title(Ljava/lang/String;)V

    .line 36
    invoke-virtual {p0, p2}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmSet$faviconResource(I)V

    .line 37
    invoke-virtual {p0, p3}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmSet$url(Ljava/lang/String;)V

    .line 38
    invoke-virtual {p0, p4}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmSet$thumbnailResource(I)V

    const/4 p1, 0x1

    .line 39
    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmSet$preventDelete(Z)V

    .line 40
    invoke-virtual {p3}, Ljava/lang/String;->hashCode()I

    move-result p1

    int-to-long p1, p1

    invoke-virtual {p0, p1, p2}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmSet$createdAt(J)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 27
    invoke-direct {p0}, Lio/realm/RealmObject;-><init>()V

    instance-of v0, p0, Lio/realm/internal/RealmObjectProxy;

    if-eqz v0, :cond_0

    move-object v0, p0

    check-cast v0, Lio/realm/internal/RealmObjectProxy;

    invoke-interface {v0}, Lio/realm/internal/RealmObjectProxy;->realm$injectObjectContext()V

    .line 28
    :cond_0
    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmSet$title(Ljava/lang/String;)V

    .line 29
    invoke-virtual {p0, p2}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmSet$faviconPath(Ljava/lang/String;)V

    .line 30
    invoke-virtual {p0, p3}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmSet$url(Ljava/lang/String;)V

    .line 31
    invoke-virtual {p3}, Ljava/lang/String;->hashCode()I

    move-result p1

    int-to-long p1, p1

    invoke-virtual {p0, p1, p2}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmSet$createdAt(J)V

    return-void
.end method


# virtual methods
.method public getCreatedAt()J
    .locals 2

    .line 68
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmGet$createdAt()J

    move-result-wide v0

    return-wide v0
.end method

.method public getFavicon()[B
    .locals 1

    .line 76
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmGet$favicon()[B

    move-result-object v0

    return-object v0
.end method

.method public getFaviconPath()Ljava/lang/String;
    .locals 1

    .line 100
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmGet$faviconPath()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getFaviconResource()I
    .locals 1

    .line 52
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmGet$faviconResource()I

    move-result v0

    return v0
.end method

.method public getThumbnail()[B
    .locals 1

    .line 84
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmGet$thumbnail()[B

    move-result-object v0

    return-object v0
.end method

.method public getThumbnailResource()I
    .locals 1

    .line 60
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmGet$thumbnailResource()I

    move-result v0

    return v0
.end method

.method public getTitle()Ljava/lang/String;
    .locals 1

    .line 92
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmGet$title()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public getUrl()Ljava/lang/String;
    .locals 1

    .line 108
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmGet$url()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public isPreventDelete()Z
    .locals 1

    .line 44
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmGet$preventDelete()Z

    move-result v0

    return v0
.end method

.method public realmGet$createdAt()J
    .locals 2

    iget-wide v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->createdAt:J

    return-wide v0
.end method

.method public realmGet$favicon()[B
    .locals 1

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->favicon:[B

    return-object v0
.end method

.method public realmGet$faviconPath()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->faviconPath:Ljava/lang/String;

    return-object v0
.end method

.method public realmGet$faviconResource()I
    .locals 1

    iget v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->faviconResource:I

    return v0
.end method

.method public realmGet$preventDelete()Z
    .locals 1

    iget-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->preventDelete:Z

    return v0
.end method

.method public realmGet$thumbnail()[B
    .locals 1

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->thumbnail:[B

    return-object v0
.end method

.method public realmGet$thumbnailResource()I
    .locals 1

    iget v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->thumbnailResource:I

    return v0
.end method

.method public realmGet$title()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->title:Ljava/lang/String;

    return-object v0
.end method

.method public realmGet$url()Ljava/lang/String;
    .locals 1

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->url:Ljava/lang/String;

    return-object v0
.end method

.method public realmSet$createdAt(J)V
    .locals 0

    iput-wide p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->createdAt:J

    return-void
.end method

.method public realmSet$favicon([B)V
    .locals 0

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->favicon:[B

    return-void
.end method

.method public realmSet$faviconPath(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->faviconPath:Ljava/lang/String;

    return-void
.end method

.method public realmSet$faviconResource(I)V
    .locals 0

    iput p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->faviconResource:I

    return-void
.end method

.method public realmSet$preventDelete(Z)V
    .locals 0

    iput-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->preventDelete:Z

    return-void
.end method

.method public realmSet$thumbnail([B)V
    .locals 0

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->thumbnail:[B

    return-void
.end method

.method public realmSet$thumbnailResource(I)V
    .locals 0

    iput p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->thumbnailResource:I

    return-void
.end method

.method public realmSet$title(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->title:Ljava/lang/String;

    return-void
.end method

.method public realmSet$url(Ljava/lang/String;)V
    .locals 0

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->url:Ljava/lang/String;

    return-void
.end method

.method public setCreatedAt(J)V
    .locals 0

    .line 72
    invoke-virtual {p0, p1, p2}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmSet$createdAt(J)V

    return-void
.end method

.method public setFavicon([B)V
    .locals 0

    .line 80
    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmSet$favicon([B)V

    return-void
.end method

.method public setFaviconPath(Ljava/lang/String;)V
    .locals 0

    .line 104
    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmSet$faviconPath(Ljava/lang/String;)V

    return-void
.end method

.method public setFaviconResource(I)V
    .locals 0

    .line 56
    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmSet$faviconResource(I)V

    return-void
.end method

.method public setPreventDelete(Z)V
    .locals 0

    .line 48
    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmSet$preventDelete(Z)V

    return-void
.end method

.method public setThumbnail([B)V
    .locals 0

    .line 88
    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmSet$thumbnail([B)V

    return-void
.end method

.method public setThumbnailResource(I)V
    .locals 0

    .line 64
    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmSet$thumbnailResource(I)V

    return-void
.end method

.method public setTitle(Ljava/lang/String;)V
    .locals 0

    .line 96
    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmSet$title(Ljava/lang/String;)V

    return-void
.end method

.method public setUrl(Ljava/lang/String;)V
    .locals 0

    .line 112
    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->realmSet$url(Ljava/lang/String;)V

    return-void
.end method
