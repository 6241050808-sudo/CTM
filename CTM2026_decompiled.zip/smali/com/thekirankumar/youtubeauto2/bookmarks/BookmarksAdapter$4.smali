.class Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$4;
.super Ljava/lang/Object;
.source "BookmarksAdapter.java"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->onBindViewHolder(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;)V
    .locals 0

    .line 93
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$4;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onLongClick(Landroid/view/View;)Z
    .locals 2

    .line 96
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$4;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->access$100(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;)Z

    move-result p1

    const/4 v0, 0x1

    if-eqz p1, :cond_0

    .line 97
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$4;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    const/4 v1, 0x0

    invoke-static {p1, v1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->access$102(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;Z)Z

    goto :goto_0

    .line 99
    :cond_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$4;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    invoke-static {p1, v0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->access$102(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;Z)Z

    .line 101
    :goto_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$4;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->notifyDataSetChanged()V

    return v0
.end method
