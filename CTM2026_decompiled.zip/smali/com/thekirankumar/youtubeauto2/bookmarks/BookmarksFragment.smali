.class public Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;
.super Landroidx/fragment/app/Fragment;
.source "BookmarksFragment.java"

# interfaces
.implements Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;


# static fields
.field public static final BOOKMARK_VIEW_SIZE_IN_DP:F = 180.0f


# instance fields
.field private bookmarks:Lio/realm/RealmResults;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/realm/RealmResults<",
            "Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;",
            ">;"
        }
    .end annotation
.end field

.field private listener:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

.field private recyclerView:Landroidx/recyclerview/widget/RecyclerView;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 37
    invoke-direct {p0}, Landroidx/fragment/app/Fragment;-><init>()V

    return-void
.end method

.method static synthetic access$000(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;)Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;
    .locals 0

    .line 37
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->listener:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

    return-object p0
.end method

.method static synthetic access$100(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;)Ljava/util/ArrayList;
    .locals 0

    .line 37
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->getPreburntBookmarks()Ljava/util/ArrayList;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$200(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;)Landroidx/recyclerview/widget/RecyclerView;
    .locals 0

    .line 37
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->recyclerView:Landroidx/recyclerview/widget/RecyclerView;

    return-object p0
.end method

.method private findParentListener(Landroid/content/Context;)V
    .locals 2

    .line 162
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->getParentFragment()Landroidx/fragment/app/Fragment;

    move-result-object v0

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->getParentFragment()Landroidx/fragment/app/Fragment;

    move-result-object v0

    instance-of v0, v0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

    if-eqz v0, :cond_0

    .line 163
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->getParentFragment()Landroidx/fragment/app/Fragment;

    move-result-object p1

    check-cast p1, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->listener:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

    goto :goto_0

    .line 164
    :cond_0
    instance-of v0, p1, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

    if-eqz v0, :cond_1

    .line 165
    check-cast p1, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->listener:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

    :goto_0
    return-void

    .line 167
    :cond_1
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, " should implement "

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-class p1, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

    invoke-virtual {p1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method private getPreburntBookmarks()Ljava/util/ArrayList;
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;",
            ">;"
        }
    .end annotation

    .line 130
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 131
    new-instance v1, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;

    const v2, 0x7f0700ff

    const v3, 0x7f070100

    const-string v4, "YouTube"

    const-string v5, "https://youtube.com"

    invoke-direct {v1, v4, v3, v5, v2}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;-><init>(Ljava/lang/String;ILjava/lang/String;I)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 132
    new-instance v1, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;

    const-string v4, "YouTube TV"

    const-string v5, "https://youtube.com/tv"

    invoke-direct {v1, v4, v3, v5, v2}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;-><init>(Ljava/lang/String;ILjava/lang/String;I)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 133
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-static {v1}, Lcom/thekirankumar/youtubeauto2/utils/MemoryStorage;->getStorageDirectories(Landroid/content/Context;)[Ljava/lang/String;

    move-result-object v1

    .line 134
    invoke-static {}, Lcom/thekirankumar/youtubeauto2/utils/MemoryStorage;->getSdCardPath()Ljava/lang/String;

    move-result-object v2

    .line 135
    array-length v3, v1

    const/4 v4, 0x0

    const/4 v5, 0x0

    :goto_0
    if-ge v5, v3, :cond_1

    aget-object v6, v1, v5

    .line 137
    invoke-virtual {v2, v6}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v7

    const v8, 0x7f0700b2

    const-string v9, "file://"

    if-eqz v7, :cond_0

    const v7, 0x7f100077

    .line 138
    invoke-virtual {p0, v7}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->getString(I)Ljava/lang/String;

    move-result-object v7

    .line 139
    new-instance v10, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v10, v7, v4, v6, v8}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;-><init>(Ljava/lang/String;ILjava/lang/String;I)V

    invoke-virtual {v0, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1

    :cond_0
    const v7, 0x7f100069

    .line 141
    invoke-virtual {p0, v7}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->getString(I)Ljava/lang/String;

    move-result-object v7

    .line 142
    new-instance v10, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v10, v7, v4, v6, v8}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;-><init>(Ljava/lang/String;ILjava/lang/String;I)V

    invoke-virtual {v0, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_1
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    .line 145
    :cond_1
    new-instance v1, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;

    const v2, 0x7f0700ee

    const-string v3, "Plex.tv"

    const-string v5, "http://app.plex.tv"

    invoke-direct {v1, v3, v4, v5, v2}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;-><init>(Ljava/lang/String;ILjava/lang/String;I)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-object v0
.end method


# virtual methods
.method public onAttach(Landroid/app/Activity;)V
    .locals 0

    .line 157
    invoke-super {p0, p1}, Landroidx/fragment/app/Fragment;->onAttach(Landroid/app/Activity;)V

    .line 158
    invoke-direct {p0, p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->findParentListener(Landroid/content/Context;)V

    return-void
.end method

.method public onAttach(Landroid/content/Context;)V
    .locals 0

    .line 151
    invoke-super {p0, p1}, Landroidx/fragment/app/Fragment;->onAttach(Landroid/content/Context;)V

    .line 152
    invoke-direct {p0, p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->findParentListener(Landroid/content/Context;)V

    return-void
.end method

.method public onBookmarkAddCurrentPage()V
    .locals 1

    .line 179
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->listener:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

    invoke-interface {v0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;->onBookmarkAddCurrentPage()V

    return-void
.end method

.method public onBookmarkDelete(Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V
    .locals 1

    .line 184
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->listener:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

    invoke-interface {v0, p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;->onBookmarkDelete(Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V

    return-void
.end method

.method public onBookmarkFragmentClose()V
    .locals 1

    .line 189
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->listener:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

    invoke-interface {v0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;->onBookmarkFragmentClose()V

    return-void
.end method

.method public onBookmarkSelected(Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V
    .locals 1

    .line 173
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->listener:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

    invoke-interface {v0, p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;->onBookmarkSelected(Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V

    .line 174
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->listener:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

    invoke-interface {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;->onBookmarkFragmentClose()V

    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 0

    .line 45
    invoke-super {p0, p1}, Landroidx/fragment/app/Fragment;->onCreate(Landroid/os/Bundle;)V

    return-void
.end method

.method public onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .locals 1

    const p3, 0x7f0b0020

    const/4 v0, 0x0

    .line 51
    invoke-virtual {p1, p3, p2, v0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    return-object p1
.end method

.method public onResume()V
    .locals 0

    .line 126
    invoke-super {p0}, Landroidx/fragment/app/Fragment;->onResume()V

    return-void
.end method

.method public onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
    .locals 1

    .line 57
    invoke-super {p0, p1, p2}, Landroidx/fragment/app/Fragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V

    const p2, 0x7f080169

    .line 59
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroidx/appcompat/widget/Toolbar;

    const v0, 0x7f0700b8

    .line 60
    invoke-virtual {p2, v0}, Landroidx/appcompat/widget/Toolbar;->setNavigationIcon(I)V

    .line 61
    new-instance v0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$1;

    invoke-direct {v0, p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$1;-><init>(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;)V

    invoke-virtual {p2, v0}, Landroidx/appcompat/widget/Toolbar;->setNavigationOnClickListener(Landroid/view/View$OnClickListener;)V

    const v0, 0x7f100023

    .line 67
    invoke-virtual {p2, v0}, Landroidx/appcompat/widget/Toolbar;->setTitle(I)V

    const p2, 0x7f080110

    .line 69
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroidx/recyclerview/widget/RecyclerView;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->recyclerView:Landroidx/recyclerview/widget/RecyclerView;

    .line 70
    new-instance v0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$2;

    invoke-direct {v0, p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$2;-><init>(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;)V

    invoke-virtual {p2, v0}, Landroidx/recyclerview/widget/RecyclerView;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    .line 84
    invoke-virtual {p1}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    .line 85
    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p1

    const/4 p2, 0x1

    const/high16 v0, 0x43340000    # 180.0f

    invoke-static {p2, v0, p1}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result p1

    .line 86
    new-instance p2, Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;

    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->getContext()Landroid/content/Context;

    move-result-object v0

    float-to-int p1, p1

    invoke-direct {p2, v0, p1}, Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;-><init>(Landroid/content/Context;I)V

    .line 87
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->recyclerView:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p1, p2}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/RecyclerView$LayoutManager;)V

    .line 88
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->recyclerView:Landroidx/recyclerview/widget/RecyclerView;

    new-instance p2, Landroidx/recyclerview/widget/DefaultItemAnimator;

    invoke-direct {p2}, Landroidx/recyclerview/widget/DefaultItemAnimator;-><init>()V

    invoke-virtual {p1, p2}, Landroidx/recyclerview/widget/RecyclerView;->setItemAnimator(Landroidx/recyclerview/widget/RecyclerView$ItemAnimator;)V

    .line 89
    invoke-static {}, Lio/realm/Realm;->getDefaultInstance()Lio/realm/Realm;

    move-result-object p1

    .line 91
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->getPreburntBookmarks()Ljava/util/ArrayList;

    move-result-object p2

    .line 92
    const-class v0, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;

    invoke-virtual {p1, v0}, Lio/realm/Realm;->where(Ljava/lang/Class;)Lio/realm/RealmQuery;

    move-result-object p1

    const-string v0, "createdAt"

    invoke-virtual {p1, v0}, Lio/realm/RealmQuery;->sort(Ljava/lang/String;)Lio/realm/RealmQuery;

    move-result-object p1

    invoke-virtual {p1}, Lio/realm/RealmQuery;->findAll()Lio/realm/RealmResults;

    move-result-object p1

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->bookmarks:Lio/realm/RealmResults;

    .line 93
    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 94
    new-instance p1, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    invoke-direct {p1, p2}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;-><init>(Ljava/util/ArrayList;)V

    .line 95
    invoke-virtual {p1, p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->setBookmarksClickCallback(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;)V

    .line 96
    iget-object p2, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->recyclerView:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p2, p1}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/RecyclerView$Adapter;)V

    .line 97
    iget-object p2, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->bookmarks:Lio/realm/RealmResults;

    new-instance v0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$3;

    invoke-direct {v0, p0, p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$3;-><init>(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;)V

    invoke-virtual {p2, v0}, Lio/realm/RealmResults;->addChangeListener(Lio/realm/OrderedRealmCollectionChangeListener;)V

    .line 108
    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->notifyDataSetChanged()V

    .line 110
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->recyclerView:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p1

    new-instance p2, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$4;

    invoke-direct {p2, p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$4;-><init>(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;)V

    invoke-virtual {p1, p2}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    return-void
.end method
