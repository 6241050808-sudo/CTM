.class public interface abstract Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;
.super Ljava/lang/Object;
.source "BookmarksClickCallback.java"


# virtual methods
.method public abstract onBookmarkAddCurrentPage()V
.end method

.method public abstract onBookmarkDelete(Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V
.end method

.method public abstract onBookmarkFragmentClose()V
.end method

.method public abstract onBookmarkSelected(Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V
.end method
