.class public Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils;
.super Ljava/lang/Object;
.source "BookmarkUtils.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 18
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static addBookmark(Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;)V
    .locals 1

    const/4 v0, 0x0

    .line 20
    invoke-virtual {p0, v0, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->scrollTo(II)V

    .line 21
    new-instance v0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1;

    invoke-direct {v0, p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$1;-><init>(Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;)V

    invoke-virtual {p0, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public static deleteBookmark(Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V
    .locals 2

    .line 63
    invoke-static {}, Lio/realm/Realm;->getDefaultInstance()Lio/realm/Realm;

    move-result-object v0

    .line 64
    new-instance v1, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$2;

    invoke-direct {v1, p0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$2;-><init>(Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V

    invoke-virtual {v0, v1}, Lio/realm/Realm;->executeTransaction(Lio/realm/Realm$Transaction;)V

    return-void
.end method
