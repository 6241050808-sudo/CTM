.class Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$2;
.super Ljava/lang/Object;
.source "BookmarksAdapter.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->onBindViewHolder(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$BookmarkViewHolder;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

.field final synthetic val$bookmark:Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V
    .locals 0

    .line 74
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$2;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$2;->val$bookmark:Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1

    .line 77
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$2;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->access$100(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;)Z

    move-result p1

    if-nez p1, :cond_0

    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$2;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->access$000(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;)Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

    move-result-object p1

    if-eqz p1, :cond_0

    .line 78
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$2;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->access$000(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;)Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

    move-result-object p1

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$2;->val$bookmark:Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;

    invoke-interface {p1, v0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;->onBookmarkSelected(Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V

    .line 80
    :cond_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$2;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->access$100(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;)Z

    move-result p1

    if-eqz p1, :cond_1

    .line 81
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$2;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->access$102(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;Z)Z

    .line 83
    :cond_1
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter$2;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksAdapter;->notifyDataSetChanged()V

    return-void
.end method
