.class Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$2;
.super Ljava/lang/Object;
.source "BookmarksFragment.java"

# interfaces
.implements Landroid/view/View$OnKeyListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;)V
    .locals 0

    .line 70
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$2;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .locals 1

    .line 73
    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result p1

    const/4 p3, 0x0

    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    const/4 p1, 0x4

    if-eq p2, p1, :cond_0

    return p3

    .line 76
    :cond_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment$2;->this$0:Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;->access$000(Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksFragment;)Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;

    move-result-object p1

    invoke-interface {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarksClickCallback;->onBookmarkFragmentClose()V

    return v0

    :cond_1
    return p3
.end method
