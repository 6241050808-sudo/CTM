.class final Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$2;
.super Ljava/lang/Object;
.source "BookmarkUtils.java"

# interfaces
.implements Lio/realm/Realm$Transaction;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils;->deleteBookmark(Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation


# instance fields
.field final synthetic val$bookmark:Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;)V
    .locals 0

    .line 64
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$2;->val$bookmark:Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public execute(Lio/realm/Realm;)V
    .locals 0

    .line 67
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/bookmarks/BookmarkUtils$2;->val$bookmark:Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/bookmarks/Bookmark;->deleteFromRealm()V

    return-void
.end method
