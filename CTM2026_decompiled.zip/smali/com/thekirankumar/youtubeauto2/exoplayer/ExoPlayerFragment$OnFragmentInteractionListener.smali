.class public interface abstract Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$OnFragmentInteractionListener;
.super Ljava/lang/Object;
.source "ExoPlayerFragment.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnFragmentInteractionListener"
.end annotation


# virtual methods
.method public abstract getAspectRatio()Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;
.end method

.method public abstract onNativePlayerControlsVisibilityChange(I)V
.end method
