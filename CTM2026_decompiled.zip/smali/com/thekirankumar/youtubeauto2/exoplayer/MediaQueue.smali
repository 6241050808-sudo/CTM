.class interface abstract Lcom/thekirankumar/youtubeauto2/exoplayer/MediaQueue;
.super Ljava/lang/Object;
.source "MediaQueue.java"


# virtual methods
.method public abstract hasNext()Z
.end method

.method public abstract hasPrevious()Z
.end method

.method public abstract next()V
.end method

.method public abstract previous()V
.end method

.method public abstract resetPosition(I)V
.end method
