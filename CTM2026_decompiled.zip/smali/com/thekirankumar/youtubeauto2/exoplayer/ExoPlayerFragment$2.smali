.class Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$2;
.super Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerFocusHelper;
.source "ExoPlayerFragment.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;Landroid/content/Context;)V
    .locals 0

    .line 143
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$2;->this$0:Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;

    invoke-direct {p0, p2}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerFocusHelper;-><init>(Landroid/content/Context;)V

    return-void
.end method


# virtual methods
.method public isPlaying()Z
    .locals 1

    .line 158
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$2;->this$0:Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->access$300(Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;)Lcom/google/android/exoplayer2/SimpleExoPlayer;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/exoplayer2/SimpleExoPlayer;->getPlayWhenReady()Z

    move-result v0

    return v0
.end method

.method protected onPause()V
    .locals 2

    .line 152
    invoke-super {p0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerFocusHelper;->onPause()V

    .line 153
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$2;->this$0:Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->access$300(Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;)Lcom/google/android/exoplayer2/SimpleExoPlayer;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/google/android/exoplayer2/SimpleExoPlayer;->setPlayWhenReady(Z)V

    return-void
.end method

.method protected onPlay()V
    .locals 2

    .line 163
    invoke-super {p0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerFocusHelper;->onPlay()V

    .line 164
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$2;->this$0:Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->access$300(Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;)Lcom/google/android/exoplayer2/SimpleExoPlayer;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/google/android/exoplayer2/SimpleExoPlayer;->setPlayWhenReady(Z)V

    return-void
.end method

.method protected onStop()V
    .locals 2

    .line 146
    invoke-super {p0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerFocusHelper;->onStop()V

    .line 147
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$2;->this$0:Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->access$300(Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;)Lcom/google/android/exoplayer2/SimpleExoPlayer;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/google/android/exoplayer2/SimpleExoPlayer;->setPlayWhenReady(Z)V

    return-void
.end method
