.class Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$1;
.super Ljava/lang/Object;
.source "ExoPlayerFragment.java"

# interfaces
.implements Lcom/google/android/exoplayer2/ui/PlayerControlView$VisibilityListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;)V
    .locals 0

    .line 125
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$1;->this$0:Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onVisibilityChange(I)V
    .locals 1

    .line 128
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$1;->this$0:Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->access$000(Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 129
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$1;->this$0:Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->access$100(Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;)Landroid/widget/TextView;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setVisibility(I)V

    .line 130
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$1;->this$0:Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->access$200(Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;)Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$OnFragmentInteractionListener;

    move-result-object v0

    invoke-interface {v0, p1}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$OnFragmentInteractionListener;->onNativePlayerControlsVisibilityChange(I)V

    return-void
.end method
