.class public Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;
.super Ljava/lang/Object;
.source "PlayerQueue.java"

# interfaces
.implements Lcom/thekirankumar/youtubeauto2/exoplayer/MediaQueue;


# static fields
.field public static final FILE_PREFIX:Ljava/lang/String; = "file://"


# instance fields
.field private currentIndex:I

.field private currentQueue:[Ljava/io/File;

.field private final startingItemPath:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 1

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 15
    iput v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->currentIndex:I

    const-string v0, "file://"

    .line 18
    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x7

    .line 19
    invoke-virtual {p1, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    .line 21
    :cond_0
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->startingItemPath:Ljava/lang/String;

    .line 22
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->buildQueue()V

    return-void
.end method

.method private buildQueue()V
    .locals 4

    .line 34
    new-instance v0, Ljava/io/File;

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->startingItemPath:Ljava/lang/String;

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 35
    new-instance v1, Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->getParent()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 36
    new-instance v2, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue$1;

    invoke-direct {v2, p0}, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue$1;-><init>(Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;)V

    invoke-virtual {v1, v2}, Ljava/io/File;->listFiles(Ljava/io/FileFilter;)[Ljava/io/File;

    move-result-object v1

    .line 43
    invoke-static {v1}, Ljava/util/Arrays;->sort([Ljava/lang/Object;)V

    const/4 v2, 0x0

    .line 44
    :goto_0
    array-length v3, v1

    if-ge v2, v3, :cond_1

    .line 45
    aget-object v3, v1, v2

    .line 46
    invoke-virtual {v3, v0}, Ljava/io/File;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_0

    .line 47
    iput v2, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->currentIndex:I

    :cond_0
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 50
    :cond_1
    iput-object v1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->currentQueue:[Ljava/io/File;

    return-void
.end method


# virtual methods
.method public current()Ljava/lang/String;
    .locals 2

    .line 54
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->currentQueue:[Ljava/io/File;

    iget v1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->currentIndex:I

    aget-object v0, v0, v1

    invoke-virtual {v0}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public currentIndex()I
    .locals 1

    .line 26
    iget v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->currentIndex:I

    return v0
.end method

.method public getCurrentQueue()[Ljava/io/File;
    .locals 1

    .line 30
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->currentQueue:[Ljava/io/File;

    return-object v0
.end method

.method public hasNext()Z
    .locals 3

    .line 69
    iget v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->currentIndex:I

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->currentQueue:[Ljava/io/File;

    array-length v1, v1

    const/4 v2, 0x1

    sub-int/2addr v1, v2

    if-ge v0, v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    :goto_0
    return v2
.end method

.method public hasPrevious()Z
    .locals 1

    .line 74
    iget v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->currentIndex:I

    if-lez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public next()V
    .locals 1

    .line 59
    iget v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->currentIndex:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->currentIndex:I

    return-void
.end method

.method public previous()V
    .locals 1

    .line 64
    iget v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->currentIndex:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->currentIndex:I

    return-void
.end method

.method public resetPosition(I)V
    .locals 0

    .line 79
    iput p1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->currentIndex:I

    return-void
.end method
