.class public Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;
.super Landroidx/fragment/app/Fragment;
.source "ExoPlayerFragment.java"

# interfaces
.implements Lcom/google/android/exoplayer2/Player$EventListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$OnFragmentInteractionListener;
    }
.end annotation


# static fields
.field private static final FILE_PATH:Ljava/lang/String; = "file_path"


# instance fields
.field private albumView:Landroid/widget/TextView;

.field private filePath:Ljava/lang/String;

.field private fileUri:Landroid/net/Uri;

.field private mListener:Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$OnFragmentInteractionListener;

.field private player:Lcom/google/android/exoplayer2/SimpleExoPlayer;

.field private playerFocusHelper:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerFocusHelper;

.field private playerQueue:Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;

.field private playerView:Lcom/google/android/exoplayer2/ui/SimpleExoPlayerView;

.field private titleView:Landroid/widget/TextView;

.field private wasPlayingInBackground:Z


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 67
    invoke-direct {p0}, Landroidx/fragment/app/Fragment;-><init>()V

    return-void
.end method

.method static synthetic access$000(Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;)Landroid/widget/TextView;
    .locals 0

    .line 53
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->titleView:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$100(Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;)Landroid/widget/TextView;
    .locals 0

    .line 53
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->albumView:Landroid/widget/TextView;

    return-object p0
.end method

.method static synthetic access$200(Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;)Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$OnFragmentInteractionListener;
    .locals 0

    .line 53
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->mListener:Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$OnFragmentInteractionListener;

    return-object p0
.end method

.method static synthetic access$300(Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;)Lcom/google/android/exoplayer2/SimpleExoPlayer;
    .locals 0

    .line 53
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->player:Lcom/google/android/exoplayer2/SimpleExoPlayer;

    return-object p0
.end method

.method private buildMediaSource(Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;)Lcom/google/android/exoplayer2/source/MediaSource;
    .locals 10

    .line 173
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 174
    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->getCurrentQueue()[Ljava/io/File;

    move-result-object p1

    .line 175
    array-length v1, p1

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_2

    aget-object v3, p1, v2

    .line 176
    invoke-static {v3}, Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;

    move-result-object v5

    .line 177
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->getContext()Landroid/content/Context;

    move-result-object v4

    const-string v6, "CarStream"

    invoke-static {v4, v6}, Lcom/google/android/exoplayer2/util/Util;->getUserAgent(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    if-eqz v3, :cond_1

    .line 178
    invoke-virtual {v3}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v6

    const-string v7, ".m3u"

    invoke-virtual {v6, v7}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_0

    invoke-virtual {v3}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v3

    const-string v6, ".m3u8"

    invoke-virtual {v3, v6}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_1

    .line 179
    :cond_0
    new-instance v3, Landroid/os/Handler;

    invoke-direct {v3}, Landroid/os/Handler;-><init>()V

    .line 180
    new-instance v3, Lcom/google/android/exoplayer2/upstream/DefaultDataSourceFactory;

    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->getContext()Landroid/content/Context;

    move-result-object v6

    invoke-direct {v3, v6, v4}, Lcom/google/android/exoplayer2/upstream/DefaultDataSourceFactory;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 181
    new-instance v4, Lcom/google/android/exoplayer2/source/hls/HlsMediaSource$Factory;

    invoke-direct {v4, v3}, Lcom/google/android/exoplayer2/source/hls/HlsMediaSource$Factory;-><init>(Lcom/google/android/exoplayer2/upstream/DataSource$Factory;)V

    .line 182
    invoke-virtual {v4, v5}, Lcom/google/android/exoplayer2/source/hls/HlsMediaSource$Factory;->createMediaSource(Landroid/net/Uri;)Lcom/google/android/exoplayer2/source/hls/HlsMediaSource;

    move-result-object v3

    .line 183
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1

    .line 185
    :cond_1
    new-instance v3, Lcom/google/android/exoplayer2/source/ExtractorMediaSource;

    new-instance v6, Lcom/google/android/exoplayer2/upstream/DefaultDataSourceFactory;

    .line 186
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->getContext()Landroid/content/Context;

    move-result-object v7

    invoke-direct {v6, v7, v4}, Lcom/google/android/exoplayer2/upstream/DefaultDataSourceFactory;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    new-instance v7, Lcom/google/android/exoplayer2/extractor/DefaultExtractorsFactory;

    invoke-direct {v7}, Lcom/google/android/exoplayer2/extractor/DefaultExtractorsFactory;-><init>()V

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object v4, v3

    invoke-direct/range {v4 .. v9}, Lcom/google/android/exoplayer2/source/ExtractorMediaSource;-><init>(Landroid/net/Uri;Lcom/google/android/exoplayer2/upstream/DataSource$Factory;Lcom/google/android/exoplayer2/extractor/ExtractorsFactory;Landroid/os/Handler;Lcom/google/android/exoplayer2/source/ExtractorMediaSource$EventListener;)V

    .line 188
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    .line 191
    :cond_2
    new-instance p1, Lcom/google/android/exoplayer2/source/ConcatenatingMediaSource;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    new-array v1, v1, [Lcom/google/android/exoplayer2/source/MediaSource;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/google/android/exoplayer2/source/MediaSource;

    invoke-direct {p1, v0}, Lcom/google/android/exoplayer2/source/ConcatenatingMediaSource;-><init>([Lcom/google/android/exoplayer2/source/MediaSource;)V

    return-object p1
.end method

.method public static newInstance(Ljava/lang/String;)Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;
    .locals 2

    .line 72
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const-string v1, "file_path"

    .line 73
    invoke-virtual {v0, v1, p0}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 74
    new-instance p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;

    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;-><init>()V

    .line 75
    invoke-virtual {p0, v0}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->setArguments(Landroid/os/Bundle;)V

    return-object p0
.end method


# virtual methods
.method public onAttach(Landroid/content/Context;)V
    .locals 2

    .line 197
    invoke-super {p0, p1}, Landroidx/fragment/app/Fragment;->onAttach(Landroid/content/Context;)V

    .line 198
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->getParentFragment()Landroidx/fragment/app/Fragment;

    move-result-object p1

    if-nez p1, :cond_0

    .line 200
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->getContext()Landroid/content/Context;

    move-result-object p1

    .line 202
    :cond_0
    instance-of v0, p1, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$OnFragmentInteractionListener;

    if-eqz v0, :cond_1

    .line 203
    check-cast p1, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$OnFragmentInteractionListener;

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->mListener:Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$OnFragmentInteractionListener;

    return-void

    .line 205
    :cond_1
    new-instance v0, Ljava/lang/RuntimeException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, " must implement OnFragmentInteractionListener"

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 1

    .line 81
    invoke-super {p0, p1}, Landroidx/fragment/app/Fragment;->onCreate(Landroid/os/Bundle;)V

    .line 82
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->getArguments()Landroid/os/Bundle;

    move-result-object p1

    const-string v0, "file_path"

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    .line 83
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->filePath:Ljava/lang/String;

    .line 84
    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->fileUri:Landroid/net/Uri;

    return-void
.end method

.method public onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .locals 1

    const p3, 0x7f0b0040

    const/4 v0, 0x0

    .line 101
    invoke-virtual {p1, p3, p2, v0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    return-object p1
.end method

.method public onDestroyView()V
    .locals 1

    .line 244
    invoke-super {p0}, Landroidx/fragment/app/Fragment;->onDestroyView()V

    .line 245
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->player:Lcom/google/android/exoplayer2/SimpleExoPlayer;

    invoke-virtual {v0}, Lcom/google/android/exoplayer2/SimpleExoPlayer;->stop()V

    return-void
.end method

.method public onDetach()V
    .locals 0

    .line 239
    invoke-super {p0}, Landroidx/fragment/app/Fragment;->onDetach()V

    return-void
.end method

.method public synthetic onIsPlayingChanged(Z)V
    .locals 0

    invoke-static {p0, p1}, Lcom/google/android/exoplayer2/Player$EventListener$-CC;->$default$onIsPlayingChanged(Lcom/google/android/exoplayer2/Player$EventListener;Z)V

    return-void
.end method

.method public onLoadingChanged(Z)V
    .locals 0

    return-void
.end method

.method public onPause()V
    .locals 1

    .line 106
    invoke-super {p0}, Landroidx/fragment/app/Fragment;->onPause()V

    .line 107
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->player:Lcom/google/android/exoplayer2/SimpleExoPlayer;

    invoke-virtual {v0}, Lcom/google/android/exoplayer2/SimpleExoPlayer;->getPlayWhenReady()Z

    move-result v0

    iput-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->wasPlayingInBackground:Z

    return-void
.end method

.method public onPlaybackParametersChanged(Lcom/google/android/exoplayer2/PlaybackParameters;)V
    .locals 0

    return-void
.end method

.method public synthetic onPlaybackSuppressionReasonChanged(I)V
    .locals 0

    invoke-static {p0, p1}, Lcom/google/android/exoplayer2/Player$EventListener$-CC;->$default$onPlaybackSuppressionReasonChanged(Lcom/google/android/exoplayer2/Player$EventListener;I)V

    return-void
.end method

.method public onPlayerError(Lcom/google/android/exoplayer2/ExoPlaybackException;)V
    .locals 1

    .line 323
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->titleView:Landroid/widget/TextView;

    invoke-virtual {p1}, Lcom/google/android/exoplayer2/ExoPlaybackException;->getLocalizedMessage()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 324
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->albumView:Landroid/widget/TextView;

    const-string v0, "Error"

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public onPlayerStateChanged(ZI)V
    .locals 0

    return-void
.end method

.method public onPositionDiscontinuity(I)V
    .locals 2

    .line 329
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->playerQueue:Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->player:Lcom/google/android/exoplayer2/SimpleExoPlayer;

    invoke-virtual {v0}, Lcom/google/android/exoplayer2/SimpleExoPlayer;->getCurrentWindowIndex()I

    move-result v0

    invoke-virtual {p1, v0}, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->resetPosition(I)V

    .line 330
    new-instance p1, Ljava/io/File;

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->playerQueue:Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->current()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p1, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 331
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->titleView:Landroid/widget/TextView;

    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 332
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->albumView:Landroid/widget/TextView;

    invoke-virtual {p1}, Ljava/io/File;->getParent()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method

.method public onRepeatModeChanged(I)V
    .locals 0

    return-void
.end method

.method public onResume()V
    .locals 2

    .line 112
    invoke-super {p0}, Landroidx/fragment/app/Fragment;->onResume()V

    .line 113
    iget-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->wasPlayingInBackground:Z

    if-eqz v0, :cond_0

    .line 114
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->player:Lcom/google/android/exoplayer2/SimpleExoPlayer;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/google/android/exoplayer2/SimpleExoPlayer;->setPlayWhenReady(Z)V

    :cond_0
    return-void
.end method

.method public onSeekProcessed()V
    .locals 0

    return-void
.end method

.method public onShuffleModeEnabledChanged(Z)V
    .locals 0

    return-void
.end method

.method public synthetic onTimelineChanged(Lcom/google/android/exoplayer2/Timeline;I)V
    .locals 0

    invoke-static {p0, p1, p2}, Lcom/google/android/exoplayer2/Player$EventListener$-CC;->$default$onTimelineChanged(Lcom/google/android/exoplayer2/Player$EventListener;Lcom/google/android/exoplayer2/Timeline;I)V

    return-void
.end method

.method public synthetic onTimelineChanged(Lcom/google/android/exoplayer2/Timeline;Ljava/lang/Object;I)V
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    invoke-static {p0, p1, p2, p3}, Lcom/google/android/exoplayer2/Player$EventListener$-CC;->$default$onTimelineChanged(Lcom/google/android/exoplayer2/Player$EventListener;Lcom/google/android/exoplayer2/Timeline;Ljava/lang/Object;I)V

    return-void
.end method

.method public onTracksChanged(Lcom/google/android/exoplayer2/source/TrackGroupArray;Lcom/google/android/exoplayer2/trackselection/TrackSelectionArray;)V
    .locals 10

    .line 250
    iget-object p2, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->playerQueue:Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->player:Lcom/google/android/exoplayer2/SimpleExoPlayer;

    invoke-virtual {v0}, Lcom/google/android/exoplayer2/SimpleExoPlayer;->getCurrentWindowIndex()I

    move-result v0

    invoke-virtual {p2, v0}, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->resetPosition(I)V

    const/4 p2, 0x0

    const/4 v0, 0x0

    move-object v1, p2

    const/4 v2, 0x0

    .line 253
    :goto_0
    iget v3, p1, Lcom/google/android/exoplayer2/source/TrackGroupArray;->length:I

    if-ge v2, v3, :cond_4

    .line 254
    invoke-virtual {p1, v2}, Lcom/google/android/exoplayer2/source/TrackGroupArray;->get(I)Lcom/google/android/exoplayer2/source/TrackGroup;

    move-result-object v3

    const/4 v4, 0x0

    .line 255
    :goto_1
    iget v5, v3, Lcom/google/android/exoplayer2/source/TrackGroup;->length:I

    if-ge v4, v5, :cond_3

    .line 256
    invoke-virtual {v3, v4}, Lcom/google/android/exoplayer2/source/TrackGroup;->getFormat(I)Lcom/google/android/exoplayer2/Format;

    move-result-object v5

    iget-object v5, v5, Lcom/google/android/exoplayer2/Format;->metadata:Lcom/google/android/exoplayer2/metadata/Metadata;

    if-eqz v5, :cond_2

    const/4 v6, 0x0

    .line 258
    :goto_2
    invoke-virtual {v5}, Lcom/google/android/exoplayer2/metadata/Metadata;->length()I

    move-result v7

    if-ge v6, v7, :cond_2

    .line 259
    invoke-virtual {v5, v6}, Lcom/google/android/exoplayer2/metadata/Metadata;->get(I)Lcom/google/android/exoplayer2/metadata/Metadata$Entry;

    move-result-object v7

    .line 260
    instance-of v8, v7, Lcom/google/android/exoplayer2/metadata/id3/TextInformationFrame;

    if-eqz v8, :cond_1

    .line 261
    check-cast v7, Lcom/google/android/exoplayer2/metadata/id3/TextInformationFrame;

    .line 262
    iget-object v8, v7, Lcom/google/android/exoplayer2/metadata/id3/TextInformationFrame;->id:Ljava/lang/String;

    if-eqz v8, :cond_0

    const-string v9, "TALB"

    .line 263
    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_0

    .line 264
    iget-object v1, v7, Lcom/google/android/exoplayer2/metadata/id3/TextInformationFrame;->value:Ljava/lang/String;

    goto :goto_3

    :cond_0
    if-eqz v8, :cond_1

    const-string v9, "TIT2"

    .line 265
    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_1

    .line 266
    iget-object p2, v7, Lcom/google/android/exoplayer2/metadata/id3/TextInformationFrame;->value:Ljava/lang/String;

    :cond_1
    :goto_3
    add-int/lit8 v6, v6, 0x1

    goto :goto_2

    :cond_2
    add-int/lit8 v4, v4, 0x1

    goto :goto_1

    :cond_3
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_4
    if-nez p2, :cond_6

    if-eqz v1, :cond_5

    goto :goto_4

    .line 283
    :cond_5
    new-instance p1, Ljava/io/File;

    iget-object p2, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->playerQueue:Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;

    invoke-virtual {p2}, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->current()Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 284
    iget-object p2, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->titleView:Landroid/widget/TextView;

    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 285
    iget-object p2, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->albumView:Landroid/widget/TextView;

    invoke-virtual {p1}, Ljava/io/File;->getParent()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_5

    :cond_6
    :goto_4
    if-eqz p2, :cond_7

    .line 276
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->titleView:Landroid/widget/TextView;

    invoke-virtual {p1, p2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_7
    if-eqz v1, :cond_8

    .line 279
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->albumView:Landroid/widget/TextView;

    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_8
    :goto_5
    return-void
.end method

.method public onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V
    .locals 2

    .line 120
    invoke-super {p0, p1, p2}, Landroidx/fragment/app/Fragment;->onViewCreated(Landroid/view/View;Landroid/os/Bundle;)V

    const p2, 0x7f08010a

    .line 122
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/TextView;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->titleView:Landroid/widget/TextView;

    const p2, 0x7f080109

    .line 123
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/TextView;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->albumView:Landroid/widget/TextView;

    const p2, 0x7f08009e

    .line 124
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Lcom/google/android/exoplayer2/ui/SimpleExoPlayerView;

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->playerView:Lcom/google/android/exoplayer2/ui/SimpleExoPlayerView;

    .line 125
    new-instance p2, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$1;

    invoke-direct {p2, p0}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$1;-><init>(Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;)V

    invoke-virtual {p1, p2}, Lcom/google/android/exoplayer2/ui/SimpleExoPlayerView;->setControllerVisibilityListener(Lcom/google/android/exoplayer2/ui/PlayerControlView$VisibilityListener;)V

    .line 133
    new-instance p1, Lcom/google/android/exoplayer2/SimpleExoPlayer$Builder;

    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->getContext()Landroid/content/Context;

    move-result-object p2

    invoke-direct {p1, p2}, Lcom/google/android/exoplayer2/SimpleExoPlayer$Builder;-><init>(Landroid/content/Context;)V

    invoke-virtual {p1}, Lcom/google/android/exoplayer2/SimpleExoPlayer$Builder;->build()Lcom/google/android/exoplayer2/SimpleExoPlayer;

    move-result-object p1

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->player:Lcom/google/android/exoplayer2/SimpleExoPlayer;

    .line 134
    iget-object p2, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->playerView:Lcom/google/android/exoplayer2/ui/SimpleExoPlayerView;

    invoke-virtual {p2, p1}, Lcom/google/android/exoplayer2/ui/SimpleExoPlayerView;->setPlayer(Lcom/google/android/exoplayer2/Player;)V

    .line 135
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->playerView:Lcom/google/android/exoplayer2/ui/SimpleExoPlayerView;

    invoke-virtual {p1}, Lcom/google/android/exoplayer2/ui/SimpleExoPlayerView;->requestFocus()Z

    .line 136
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->player:Lcom/google/android/exoplayer2/SimpleExoPlayer;

    const/4 p2, 0x1

    invoke-virtual {p1, p2}, Lcom/google/android/exoplayer2/SimpleExoPlayer;->setPlayWhenReady(Z)V

    .line 137
    new-instance p1, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->filePath:Ljava/lang/String;

    invoke-direct {p1, v0}, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;-><init>(Ljava/lang/String;)V

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->playerQueue:Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;

    .line 138
    invoke-direct {p0, p1}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->buildMediaSource(Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;)Lcom/google/android/exoplayer2/source/MediaSource;

    move-result-object p1

    .line 139
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->player:Lcom/google/android/exoplayer2/SimpleExoPlayer;

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->playerQueue:Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;

    invoke-virtual {v1}, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->currentIndex()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/google/android/exoplayer2/SimpleExoPlayer;->seekToDefaultPosition(I)V

    .line 140
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->player:Lcom/google/android/exoplayer2/SimpleExoPlayer;

    const/4 v1, 0x0

    invoke-virtual {v0, p1, p2, v1}, Lcom/google/android/exoplayer2/SimpleExoPlayer;->prepare(Lcom/google/android/exoplayer2/source/MediaSource;ZZ)V

    .line 141
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->player:Lcom/google/android/exoplayer2/SimpleExoPlayer;

    invoke-virtual {p1, p0}, Lcom/google/android/exoplayer2/SimpleExoPlayer;->addListener(Lcom/google/android/exoplayer2/Player$EventListener;)V

    .line 142
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->mListener:Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$OnFragmentInteractionListener;

    invoke-interface {p1}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$OnFragmentInteractionListener;->getAspectRatio()Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->setAspectRatio(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;)V

    .line 143
    new-instance p1, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$2;

    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->getContext()Landroid/content/Context;

    move-result-object p2

    invoke-direct {p1, p0, p2}, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$2;-><init>(Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;Landroid/content/Context;)V

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->playerFocusHelper:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerFocusHelper;

    return-void
.end method

.method public setAspectRatio(Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;)V
    .locals 1

    .line 88
    sget-object v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;->CONTAIN:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    if-ne p1, v0, :cond_0

    .line 89
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->playerView:Lcom/google/android/exoplayer2/ui/SimpleExoPlayerView;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Lcom/google/android/exoplayer2/ui/SimpleExoPlayerView;->setResizeMode(I)V

    goto :goto_0

    .line 90
    :cond_0
    sget-object v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;->FILL:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    if-ne p1, v0, :cond_1

    .line 91
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->playerView:Lcom/google/android/exoplayer2/ui/SimpleExoPlayerView;

    const/4 v0, 0x3

    invoke-virtual {p1, v0}, Lcom/google/android/exoplayer2/ui/SimpleExoPlayerView;->setResizeMode(I)V

    goto :goto_0

    .line 92
    :cond_1
    sget-object v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;->COVER:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    if-ne p1, v0, :cond_2

    .line 93
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment;->playerView:Lcom/google/android/exoplayer2/ui/SimpleExoPlayerView;

    const/4 v0, 0x4

    invoke-virtual {p1, v0}, Lcom/google/android/exoplayer2/ui/SimpleExoPlayerView;->setResizeMode(I)V

    :cond_2
    :goto_0
    return-void
.end method
