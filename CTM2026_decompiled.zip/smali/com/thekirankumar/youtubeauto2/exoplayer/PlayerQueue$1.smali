.class Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue$1;
.super Ljava/lang/Object;
.source "PlayerQueue.java"

# interfaces
.implements Ljava/io/FileFilter;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;->buildQueue()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;)V
    .locals 0

    .line 36
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue$1;->this$0:Lcom/thekirankumar/youtubeauto2/exoplayer/PlayerQueue;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public accept(Ljava/io/File;)Z
    .locals 1

    .line 39
    invoke-virtual {p1}, Ljava/io/File;->isDirectory()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object p1

    const-string v0, ".jpg"

    invoke-virtual {p1, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method
