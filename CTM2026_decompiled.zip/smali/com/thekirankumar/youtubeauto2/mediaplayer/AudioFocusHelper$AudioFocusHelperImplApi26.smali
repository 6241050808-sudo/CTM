.class Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplApi26;
.super Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplBase;
.source "AudioFocusHelper.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "AudioFocusHelperImplApi26"
.end annotation


# instance fields
.field private mAudioFocusRequest:Landroid/media/AudioFocusRequest;


# direct methods
.method constructor <init>(Landroid/media/AudioManager;)V
    .locals 0

    .line 175
    invoke-direct {p0, p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplBase;-><init>(Landroid/media/AudioManager;)V

    return-void
.end method


# virtual methods
.method public abandonAudioFocus()V
    .locals 2

    .line 190
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplApi26;->mAudioManager:Landroid/media/AudioManager;

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplApi26;->mAudioFocusRequest:Landroid/media/AudioFocusRequest;

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->abandonAudioFocusRequest(Landroid/media/AudioFocusRequest;)I

    return-void
.end method

.method public requestAudioFocus(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;)Z
    .locals 1

    .line 181
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplApi26;->mAudioFocusRequestCompat:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;

    .line 182
    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->getAudioFocusRequest()Landroid/media/AudioFocusRequest;

    move-result-object p1

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplApi26;->mAudioFocusRequest:Landroid/media/AudioFocusRequest;

    .line 184
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplApi26;->mAudioManager:Landroid/media/AudioManager;

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplApi26;->mAudioFocusRequest:Landroid/media/AudioFocusRequest;

    invoke-virtual {p1, v0}, Landroid/media/AudioManager;->requestAudioFocus(Landroid/media/AudioFocusRequest;)I

    move-result p1

    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method
