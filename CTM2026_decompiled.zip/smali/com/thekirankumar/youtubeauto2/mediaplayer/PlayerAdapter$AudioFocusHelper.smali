.class final Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;
.super Ljava/lang/Object;
.source "PlayerAdapter.java"

# interfaces
.implements Landroid/media/AudioManager$OnAudioFocusChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "AudioFocusHelper"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;


# direct methods
.method private constructor <init>(Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;)V
    .locals 0

    .line 124
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;->this$0:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$1;)V
    .locals 0

    .line 124
    invoke-direct {p0, p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;-><init>(Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;)V

    return-void
.end method

.method private abandonAudioFocus()V
    .locals 1

    .line 135
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;->this$0:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->access$300(Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;)Landroid/media/AudioManager;

    move-result-object v0

    invoke-virtual {v0, p0}, Landroid/media/AudioManager;->abandonAudioFocus(Landroid/media/AudioManager$OnAudioFocusChangeListener;)I

    return-void
.end method

.method static synthetic access$100(Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;)Z
    .locals 0

    .line 124
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;->requestAudioFocus()Z

    move-result p0

    return p0
.end method

.method static synthetic access$200(Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;)V
    .locals 0

    .line 124
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;->abandonAudioFocus()V

    return-void
.end method

.method private requestAudioFocus()Z
    .locals 3

    .line 128
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;->this$0:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->access$300(Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;)Landroid/media/AudioManager;

    move-result-object v0

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0, p0, v2, v1}, Landroid/media/AudioManager;->requestAudioFocus(Landroid/media/AudioManager$OnAudioFocusChangeListener;II)I

    move-result v0

    if-ne v0, v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method


# virtual methods
.method public onAudioFocusChange(I)V
    .locals 3

    const/4 v0, -0x3

    if-eq p1, v0, :cond_5

    const/4 v0, -0x2

    const/4 v1, 0x1

    if-eq p1, v0, :cond_4

    const/4 v0, -0x1

    const/4 v2, 0x0

    if-eq p1, v0, :cond_3

    if-eq p1, v1, :cond_0

    goto :goto_1

    .line 142
    :cond_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;->this$0:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->access$400(Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;)Z

    move-result p1

    if-eqz p1, :cond_1

    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;->this$0:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->isPlaying()Z

    move-result p1

    if-nez p1, :cond_1

    .line 143
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;->this$0:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->play()V

    goto :goto_0

    .line 144
    :cond_1
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;->this$0:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->isPlaying()Z

    move-result p1

    if-eqz p1, :cond_2

    .line 145
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;->this$0:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-virtual {p1, v0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->setVolume(F)V

    .line 147
    :cond_2
    :goto_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;->this$0:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;

    invoke-static {p1, v2}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->access$402(Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;Z)Z

    goto :goto_1

    .line 159
    :cond_3
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;->this$0:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->access$300(Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;)Landroid/media/AudioManager;

    move-result-object p1

    invoke-virtual {p1, p0}, Landroid/media/AudioManager;->abandonAudioFocus(Landroid/media/AudioManager$OnAudioFocusChangeListener;)I

    .line 160
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;->this$0:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;

    invoke-static {p1, v2}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->access$402(Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;Z)Z

    .line 161
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;->this$0:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->stop()V

    goto :goto_1

    .line 153
    :cond_4
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;->this$0:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->isPlaying()Z

    move-result p1

    if-eqz p1, :cond_6

    .line 154
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;->this$0:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;

    invoke-static {p1, v1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->access$402(Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;Z)Z

    .line 155
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;->this$0:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->pause()V

    goto :goto_1

    .line 150
    :cond_5
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;->this$0:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;

    const v0, 0x3e4ccccd    # 0.2f

    invoke-virtual {p1, v0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->setVolume(F)V

    :cond_6
    :goto_1
    return-void
.end method
