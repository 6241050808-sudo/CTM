.class public interface abstract Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;
.super Ljava/lang/Object;
.source "AudioFocusAwarePlayer.java"


# virtual methods
.method public abstract isPlaying()Z
.end method

.method public abstract pause()V
.end method

.method public abstract play()V
.end method

.method public abstract setVolume(F)V
.end method

.method public abstract stop()V
.end method
