.class public Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper;
.super Ljava/lang/Object;
.source "AudioFocusHelper.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;,
        Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplApi26;,
        Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplBase;,
        Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImpl;
    }
.end annotation


# static fields
.field private static final TAG:Ljava/lang/String; = "AudioFocusHelper"


# instance fields
.field private mDefaultChangeListener:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;

.field private final mImpl:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImpl;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    .line 46
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 48
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const-string v0, "audio"

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/media/AudioManager;

    .line 50
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    if-lt v0, v1, :cond_0

    .line 51
    new-instance v0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplApi26;

    invoke-direct {v0, p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplApi26;-><init>(Landroid/media/AudioManager;)V

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper;->mImpl:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImpl;

    goto :goto_0

    .line 53
    :cond_0
    new-instance v0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplBase;

    invoke-direct {v0, p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplBase;-><init>(Landroid/media/AudioManager;)V

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper;->mImpl:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImpl;

    :goto_0
    return-void
.end method


# virtual methods
.method public abandonAudioFocus(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;)V
    .locals 0

    .line 98
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper;->mImpl:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImpl;

    invoke-interface {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImpl;->abandonAudioFocus()V

    return-void
.end method

.method public getListenerForPlayer(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;)Landroid/media/AudioManager$OnAudioFocusChangeListener;
    .locals 3

    .line 75
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper;->mDefaultChangeListener:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;

    if-eqz v0, :cond_0

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;->access$000(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;)Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 76
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper;->mDefaultChangeListener:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;

    return-object p1

    .line 78
    :cond_0
    new-instance v0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper;->mImpl:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImpl;

    const/4 v2, 0x0

    invoke-direct {v0, v1, p1, v2}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;-><init>(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImpl;Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$1;)V

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper;->mDefaultChangeListener:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;

    return-object v0
.end method

.method public requestAudioFocus(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;)Z
    .locals 1

    .line 89
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper;->mImpl:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImpl;

    invoke-interface {v0, p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImpl;->requestAudioFocus(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;)Z

    move-result p1

    return p1
.end method
