.class public Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerFocusHelper;
.super Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;
.source "PlayerFocusHelper.java"


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    .line 12
    invoke-direct {p0, p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;-><init>(Landroid/content/Context;)V

    return-void
.end method


# virtual methods
.method public isPlaying()Z
    .locals 1

    const/4 v0, 0x0

    return v0
.end method

.method protected onPause()V
    .locals 0

    return-void
.end method

.method protected onPlay()V
    .locals 0

    return-void
.end method

.method protected onStop()V
    .locals 0

    return-void
.end method

.method public seekTo(J)V
    .locals 0

    return-void
.end method

.method public setVolume(F)V
    .locals 0

    return-void
.end method
