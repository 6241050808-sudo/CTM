.class Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$1;
.super Landroid/content/BroadcastReceiver;
.source "PlayerAdapter.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;)V
    .locals 0

    .line 40
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$1;->this$0:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 0

    .line 43
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    const-string p2, "android.media.AUDIO_BECOMING_NOISY"

    invoke-virtual {p2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_0

    .line 44
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$1;->this$0:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->isPlaying()Z

    move-result p1

    if-eqz p1, :cond_0

    .line 45
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$1;->this$0:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->pause()V

    :cond_0
    return-void
.end method
