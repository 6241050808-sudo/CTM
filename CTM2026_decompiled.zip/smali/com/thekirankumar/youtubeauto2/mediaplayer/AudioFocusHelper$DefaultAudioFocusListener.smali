.class Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;
.super Ljava/lang/Object;
.source "AudioFocusHelper.java"

# interfaces
.implements Landroid/media/AudioManager$OnAudioFocusChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "DefaultAudioFocusListener"
.end annotation


# static fields
.field private static final MEDIA_VOLUME_DEFAULT:F = 1.0f

.field private static final MEDIA_VOLUME_DUCK:F = 0.2f


# instance fields
.field private final mImpl:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImpl;

.field private final mPlayer:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;

.field private mResumeOnFocusGain:Z


# direct methods
.method private constructor <init>(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImpl;Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;)V
    .locals 1

    .line 208
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 206
    iput-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;->mResumeOnFocusGain:Z

    .line 209
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;->mImpl:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImpl;

    .line 210
    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;->mPlayer:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;

    return-void
.end method

.method synthetic constructor <init>(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImpl;Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$1;)V
    .locals 0

    .line 197
    invoke-direct {p0, p1, p2}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;-><init>(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImpl;Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;)V

    return-void
.end method

.method static synthetic access$000(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;)Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;
    .locals 0

    .line 197
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;->getPlayer()Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;

    move-result-object p0

    return-object p0
.end method

.method private getPlayer()Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;
    .locals 1

    .line 214
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;->mPlayer:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;

    return-object v0
.end method


# virtual methods
.method public onAudioFocusChange(I)V
    .locals 2

    const/4 v0, -0x3

    if-eq p1, v0, :cond_3

    const/4 v0, -0x2

    if-eq p1, v0, :cond_4

    const/4 v0, -0x1

    const/4 v1, 0x0

    if-eq p1, v0, :cond_2

    const/4 v0, 0x1

    if-eq p1, v0, :cond_0

    goto :goto_0

    .line 221
    :cond_0
    iget-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;->mResumeOnFocusGain:Z

    if-eqz p1, :cond_1

    .line 222
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;->mPlayer:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;

    invoke-interface {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;->play()V

    .line 223
    iput-boolean v1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;->mResumeOnFocusGain:Z

    goto :goto_0

    .line 224
    :cond_1
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;->mPlayer:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;

    invoke-interface {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;->isPlaying()Z

    move-result p1

    if-eqz p1, :cond_5

    .line 225
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;->mPlayer:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;

    const/high16 v0, 0x3f800000    # 1.0f

    invoke-interface {p1, v0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;->setVolume(F)V

    goto :goto_0

    .line 241
    :cond_2
    iput-boolean v1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;->mResumeOnFocusGain:Z

    .line 242
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;->mPlayer:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;

    invoke-interface {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;->stop()V

    .line 243
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;->mImpl:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImpl;

    invoke-interface {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImpl;->abandonAudioFocus()V

    goto :goto_0

    .line 229
    :cond_3
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;->mImpl:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImpl;

    invoke-interface {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImpl;->willPauseWhenDucked()Z

    move-result p1

    if-nez p1, :cond_4

    .line 230
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;->mPlayer:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;

    const v0, 0x3e4ccccd    # 0.2f

    invoke-interface {p1, v0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;->setVolume(F)V

    goto :goto_0

    .line 237
    :cond_4
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;->mPlayer:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;

    invoke-interface {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;->isPlaying()Z

    move-result p1

    iput-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;->mResumeOnFocusGain:Z

    .line 238
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$DefaultAudioFocusListener;->mPlayer:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;

    invoke-interface {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusAwarePlayer;->pause()V

    :cond_5
    :goto_0
    return-void
.end method
