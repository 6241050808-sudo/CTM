.class public abstract Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;
.super Ljava/lang/Object;
.source "PlayerAdapter.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;
    }
.end annotation


# static fields
.field private static final AUDIO_NOISY_INTENT_FILTER:Landroid/content/IntentFilter;

.field private static final MEDIA_VOLUME_DEFAULT:F = 1.0f

.field private static final MEDIA_VOLUME_DUCK:F = 0.2f


# instance fields
.field private final mApplicationContext:Landroid/content/Context;

.field private final mAudioFocusHelper:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;

.field private final mAudioManager:Landroid/media/AudioManager;

.field private final mAudioNoisyReceiver:Landroid/content/BroadcastReceiver;

.field private mAudioNoisyReceiverRegistered:Z

.field private mPlayOnAudioFocus:Z


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 35
    new-instance v0, Landroid/content/IntentFilter;

    const-string v1, "android.media.AUDIO_BECOMING_NOISY"

    invoke-direct {v0, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    sput-object v0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->AUDIO_NOISY_INTENT_FILTER:Landroid/content/IntentFilter;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    .line 57
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    .line 38
    iput-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->mAudioNoisyReceiverRegistered:Z

    .line 39
    new-instance v1, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$1;

    invoke-direct {v1, p0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$1;-><init>(Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;)V

    iput-object v1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->mAudioNoisyReceiver:Landroid/content/BroadcastReceiver;

    .line 55
    iput-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->mPlayOnAudioFocus:Z

    .line 58
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->mApplicationContext:Landroid/content/Context;

    const-string v0, "audio"

    .line 59
    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/media/AudioManager;

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->mAudioManager:Landroid/media/AudioManager;

    .line 60
    new-instance p1, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;

    const/4 v0, 0x0

    invoke-direct {p1, p0, v0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;-><init>(Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$1;)V

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->mAudioFocusHelper:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;

    return-void
.end method

.method static synthetic access$300(Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;)Landroid/media/AudioManager;
    .locals 0

    .line 30
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->mAudioManager:Landroid/media/AudioManager;

    return-object p0
.end method

.method static synthetic access$400(Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;)Z
    .locals 0

    .line 30
    iget-boolean p0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->mPlayOnAudioFocus:Z

    return p0
.end method

.method static synthetic access$402(Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;Z)Z
    .locals 0

    .line 30
    iput-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->mPlayOnAudioFocus:Z

    return p1
.end method

.method private registerAudioNoisyReceiver()V
    .locals 3

    .line 108
    iget-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->mAudioNoisyReceiverRegistered:Z

    if-nez v0, :cond_0

    .line 109
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->mApplicationContext:Landroid/content/Context;

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->mAudioNoisyReceiver:Landroid/content/BroadcastReceiver;

    sget-object v2, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->AUDIO_NOISY_INTENT_FILTER:Landroid/content/IntentFilter;

    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/4 v0, 0x1

    .line 110
    iput-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->mAudioNoisyReceiverRegistered:Z

    :cond_0
    return-void
.end method

.method private unregisterAudioNoisyReceiver()V
    .locals 2

    .line 115
    iget-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->mAudioNoisyReceiverRegistered:Z

    if-eqz v0, :cond_0

    .line 116
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->mApplicationContext:Landroid/content/Context;

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->mAudioNoisyReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v0, v1}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    const/4 v0, 0x0

    .line 117
    iput-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->mAudioNoisyReceiverRegistered:Z

    :cond_0
    return-void
.end method


# virtual methods
.method public abstract isPlaying()Z
.end method

.method protected abstract onPause()V
.end method

.method protected abstract onPlay()V
.end method

.method protected abstract onStop()V
.end method

.method public final pause()V
    .locals 1

    .line 78
    iget-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->mPlayOnAudioFocus:Z

    if-nez v0, :cond_0

    .line 79
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->mAudioFocusHelper:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;->access$200(Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;)V

    .line 82
    :cond_0
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->unregisterAudioNoisyReceiver()V

    .line 83
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->onPause()V

    return-void
.end method

.method public final play()V
    .locals 1

    .line 66
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->mAudioFocusHelper:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;->access$100(Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;)Z

    move-result v0

    if-eqz v0, :cond_0

    .line 67
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->registerAudioNoisyReceiver()V

    .line 68
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->onPlay()V

    :cond_0
    return-void
.end method

.method public abstract seekTo(J)V
.end method

.method public abstract setVolume(F)V
.end method

.method public final stop()V
    .locals 1

    .line 92
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->mAudioFocusHelper:Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;->access$200(Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter$AudioFocusHelper;)V

    .line 93
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->unregisterAudioNoisyReceiver()V

    .line 94
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/PlayerAdapter;->onStop()V

    return-void
.end method
