.class public final Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;
.super Ljava/lang/Object;
.source "AudioFocusRequestCompat.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation


# instance fields
.field private mAcceptsDelayedFocusGain:Z

.field private mAudioAttributesCompat:Landroidx/media/AudioAttributesCompat;

.field private mFocusChangeHandler:Landroid/os/Handler;

.field private mFocusGain:I

.field private mOnAudioFocusChangeListener:Landroid/media/AudioManager$OnAudioFocusChangeListener;

.field private mPauseOnDuck:Z


# direct methods
.method public constructor <init>(I)V
    .locals 0

    .line 108
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 109
    iput p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;->mFocusGain:I

    return-void
.end method

.method public constructor <init>(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;)V
    .locals 1

    .line 112
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 113
    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->access$000(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;)I

    move-result v0

    iput v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;->mFocusGain:I

    .line 114
    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->access$100(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;)Landroid/media/AudioManager$OnAudioFocusChangeListener;

    move-result-object v0

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;->mOnAudioFocusChangeListener:Landroid/media/AudioManager$OnAudioFocusChangeListener;

    .line 115
    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->access$200(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;)Landroid/os/Handler;

    move-result-object v0

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;->mFocusChangeHandler:Landroid/os/Handler;

    .line 116
    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->access$300(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;)Landroidx/media/AudioAttributesCompat;

    move-result-object v0

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;->mAudioAttributesCompat:Landroidx/media/AudioAttributesCompat;

    .line 117
    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->access$400(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;)Z

    move-result v0

    iput-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;->mPauseOnDuck:Z

    .line 118
    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->access$500(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;)Z

    move-result p1

    iput-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;->mAcceptsDelayedFocusGain:Z

    return-void
.end method


# virtual methods
.method public build()Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;
    .locals 9

    .line 159
    new-instance v8, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;

    iget v1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;->mFocusGain:I

    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;->mOnAudioFocusChangeListener:Landroid/media/AudioManager$OnAudioFocusChangeListener;

    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;->mFocusChangeHandler:Landroid/os/Handler;

    iget-object v4, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;->mAudioAttributesCompat:Landroidx/media/AudioAttributesCompat;

    iget-boolean v5, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;->mPauseOnDuck:Z

    iget-boolean v6, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;->mAcceptsDelayedFocusGain:Z

    const/4 v7, 0x0

    move-object v0, v8

    invoke-direct/range {v0 .. v7}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;-><init>(ILandroid/media/AudioManager$OnAudioFocusChangeListener;Landroid/os/Handler;Landroidx/media/AudioAttributesCompat;ZZLcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$1;)V

    return-object v8
.end method

.method public setAcceptsDelayedFocusGain(Z)Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;
    .locals 0

    .line 154
    iput-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;->mAcceptsDelayedFocusGain:Z

    return-object p0
.end method

.method public setAudioAttributes(Landroidx/media/AudioAttributesCompat;)Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;
    .locals 0

    .line 142
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;->mAudioAttributesCompat:Landroidx/media/AudioAttributesCompat;

    return-object p0
.end method

.method public setFocusGain(I)Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;
    .locals 0

    .line 123
    iput p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;->mFocusGain:I

    return-object p0
.end method

.method public setOnAudioFocusChangeListener(Landroid/media/AudioManager$OnAudioFocusChangeListener;)Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;
    .locals 2

    .line 129
    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    invoke-virtual {p0, p1, v0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;->setOnAudioFocusChangeListener(Landroid/media/AudioManager$OnAudioFocusChangeListener;Landroid/os/Handler;)Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;

    move-result-object p1

    return-object p1
.end method

.method public setOnAudioFocusChangeListener(Landroid/media/AudioManager$OnAudioFocusChangeListener;Landroid/os/Handler;)Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;
    .locals 0

    .line 135
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;->mOnAudioFocusChangeListener:Landroid/media/AudioManager$OnAudioFocusChangeListener;

    .line 136
    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;->mFocusChangeHandler:Landroid/os/Handler;

    return-object p0
.end method

.method public setWillPauseWhenDucked(Z)Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;
    .locals 0

    .line 148
    iput-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;->mPauseOnDuck:Z

    return-object p0
.end method
