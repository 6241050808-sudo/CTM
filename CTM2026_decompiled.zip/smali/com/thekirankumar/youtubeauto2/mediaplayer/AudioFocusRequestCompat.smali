.class public Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;
.super Ljava/lang/Object;
.source "AudioFocusRequestCompat.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$Builder;,
        Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$FocusGain;
    }
.end annotation


# instance fields
.field private final mAcceptsDelayedFocusGain:Z

.field private final mAudioAttributesCompat:Landroidx/media/AudioAttributesCompat;

.field private final mFocusChangeHandler:Landroid/os/Handler;

.field private final mFocusGain:I

.field private final mOnAudioFocusChangeListener:Landroid/media/AudioManager$OnAudioFocusChangeListener;

.field private final mPauseOnDuck:Z


# direct methods
.method private constructor <init>(ILandroid/media/AudioManager$OnAudioFocusChangeListener;Landroid/os/Handler;Landroidx/media/AudioAttributesCompat;ZZ)V
    .locals 0

    .line 45
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 46
    iput p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mFocusGain:I

    .line 47
    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mOnAudioFocusChangeListener:Landroid/media/AudioManager$OnAudioFocusChangeListener;

    .line 48
    iput-object p3, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mFocusChangeHandler:Landroid/os/Handler;

    .line 49
    iput-object p4, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mAudioAttributesCompat:Landroidx/media/AudioAttributesCompat;

    .line 50
    iput-boolean p5, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mPauseOnDuck:Z

    .line 51
    iput-boolean p6, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mAcceptsDelayedFocusGain:Z

    return-void
.end method

.method synthetic constructor <init>(ILandroid/media/AudioManager$OnAudioFocusChangeListener;Landroid/os/Handler;Landroidx/media/AudioAttributesCompat;ZZLcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat$1;)V
    .locals 0

    .line 22
    invoke-direct/range {p0 .. p6}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;-><init>(ILandroid/media/AudioManager$OnAudioFocusChangeListener;Landroid/os/Handler;Landroidx/media/AudioAttributesCompat;ZZ)V

    return-void
.end method

.method static synthetic access$000(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;)I
    .locals 0

    .line 22
    iget p0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mFocusGain:I

    return p0
.end method

.method static synthetic access$100(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;)Landroid/media/AudioManager$OnAudioFocusChangeListener;
    .locals 0

    .line 22
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mOnAudioFocusChangeListener:Landroid/media/AudioManager$OnAudioFocusChangeListener;

    return-object p0
.end method

.method static synthetic access$200(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;)Landroid/os/Handler;
    .locals 0

    .line 22
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mFocusChangeHandler:Landroid/os/Handler;

    return-object p0
.end method

.method static synthetic access$300(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;)Landroidx/media/AudioAttributesCompat;
    .locals 0

    .line 22
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mAudioAttributesCompat:Landroidx/media/AudioAttributesCompat;

    return-object p0
.end method

.method static synthetic access$400(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;)Z
    .locals 0

    .line 22
    iget-boolean p0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mPauseOnDuck:Z

    return p0
.end method

.method static synthetic access$500(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;)Z
    .locals 0

    .line 22
    iget-boolean p0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mAcceptsDelayedFocusGain:Z

    return p0
.end method


# virtual methods
.method public acceptsDelayedFocusGain()Z
    .locals 1

    .line 67
    iget-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mAcceptsDelayedFocusGain:Z

    return v0
.end method

.method getAudioAttributes()Landroid/media/AudioAttributes;
    .locals 1

    .line 80
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mAudioAttributesCompat:Landroidx/media/AudioAttributesCompat;

    if-eqz v0, :cond_0

    .line 81
    invoke-virtual {v0}, Landroidx/media/AudioAttributesCompat;->unwrap()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/media/AudioAttributes;

    check-cast v0, Landroid/media/AudioAttributes;

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return-object v0
.end method

.method public getAudioAttributesCompat()Landroidx/media/AudioAttributesCompat;
    .locals 1

    .line 59
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mAudioAttributesCompat:Landroidx/media/AudioAttributesCompat;

    return-object v0
.end method

.method getAudioFocusRequest()Landroid/media/AudioFocusRequest;
    .locals 3

    .line 87
    new-instance v0, Landroid/media/AudioFocusRequest$Builder;

    iget v1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mFocusGain:I

    invoke-direct {v0, v1}, Landroid/media/AudioFocusRequest$Builder;-><init>(I)V

    .line 88
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->getAudioAttributes()Landroid/media/AudioAttributes;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/media/AudioFocusRequest$Builder;->setAudioAttributes(Landroid/media/AudioAttributes;)Landroid/media/AudioFocusRequest$Builder;

    move-result-object v0

    iget-boolean v1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mAcceptsDelayedFocusGain:Z

    .line 89
    invoke-virtual {v0, v1}, Landroid/media/AudioFocusRequest$Builder;->setAcceptsDelayedFocusGain(Z)Landroid/media/AudioFocusRequest$Builder;

    move-result-object v0

    iget-boolean v1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mPauseOnDuck:Z

    .line 90
    invoke-virtual {v0, v1}, Landroid/media/AudioFocusRequest$Builder;->setWillPauseWhenDucked(Z)Landroid/media/AudioFocusRequest$Builder;

    move-result-object v0

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mOnAudioFocusChangeListener:Landroid/media/AudioManager$OnAudioFocusChangeListener;

    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mFocusChangeHandler:Landroid/os/Handler;

    .line 91
    invoke-virtual {v0, v1, v2}, Landroid/media/AudioFocusRequest$Builder;->setOnAudioFocusChangeListener(Landroid/media/AudioManager$OnAudioFocusChangeListener;Landroid/os/Handler;)Landroid/media/AudioFocusRequest$Builder;

    move-result-object v0

    .line 92
    invoke-virtual {v0}, Landroid/media/AudioFocusRequest$Builder;->build()Landroid/media/AudioFocusRequest;

    move-result-object v0

    return-object v0
.end method

.method getFocusChangeHandler()Landroid/os/Handler;
    .locals 1

    .line 75
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mFocusChangeHandler:Landroid/os/Handler;

    return-object v0
.end method

.method public getFocusGain()I
    .locals 1

    .line 55
    iget v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mFocusGain:I

    return v0
.end method

.method getOnAudioFocusChangeListener()Landroid/media/AudioManager$OnAudioFocusChangeListener;
    .locals 1

    .line 71
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mOnAudioFocusChangeListener:Landroid/media/AudioManager$OnAudioFocusChangeListener;

    return-object v0
.end method

.method public willPauseWhenDucked()Z
    .locals 1

    .line 63
    iget-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->mPauseOnDuck:Z

    return v0
.end method
