.class Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplBase;
.super Ljava/lang/Object;
.source "AudioFocusHelper.java"

# interfaces
.implements Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImpl;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "AudioFocusHelperImplBase"
.end annotation


# instance fields
.field mAudioFocusRequestCompat:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;

.field final mAudioManager:Landroid/media/AudioManager;


# direct methods
.method constructor <init>(Landroid/media/AudioManager;)V
    .locals 0

    .line 113
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 114
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplBase;->mAudioManager:Landroid/media/AudioManager;

    return-void
.end method


# virtual methods
.method public abandonAudioFocus()V
    .locals 2

    .line 146
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplBase;->mAudioFocusRequestCompat:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;

    if-nez v0, :cond_0

    return-void

    .line 150
    :cond_0
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplBase;->mAudioManager:Landroid/media/AudioManager;

    .line 151
    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->getOnAudioFocusChangeListener()Landroid/media/AudioManager$OnAudioFocusChangeListener;

    move-result-object v0

    .line 150
    invoke-virtual {v1, v0}, Landroid/media/AudioManager;->abandonAudioFocus(Landroid/media/AudioManager$OnAudioFocusChangeListener;)I

    return-void
.end method

.method public requestAudioFocus(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;)Z
    .locals 3

    .line 120
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplBase;->mAudioFocusRequestCompat:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;

    .line 123
    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->acceptsDelayedFocusGain()Z

    move-result p1

    if-eqz p1, :cond_0

    .line 124
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "Cannot request delayed focus on API "

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 129
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 130
    invoke-virtual {v0}, Ljava/lang/UnsupportedOperationException;->fillInStackTrace()Ljava/lang/Throwable;

    move-result-object p1

    const-string v0, "AudioFocusHelper"

    const-string v1, "Cannot request delayed focus"

    .line 131
    invoke-static {v0, v1, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 134
    :cond_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplBase;->mAudioFocusRequestCompat:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;

    .line 135
    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->getOnAudioFocusChangeListener()Landroid/media/AudioManager$OnAudioFocusChangeListener;

    move-result-object p1

    .line 136
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplBase;->mAudioFocusRequestCompat:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;

    .line 137
    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->getAudioAttributesCompat()Landroidx/media/AudioAttributesCompat;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/media/AudioAttributesCompat;->getLegacyStreamType()I

    move-result v0

    .line 138
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplBase;->mAudioFocusRequestCompat:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;

    invoke-virtual {v1}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->getFocusGain()I

    move-result v1

    .line 140
    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplBase;->mAudioManager:Landroid/media/AudioManager;

    invoke-virtual {v2, p1, v0, v1}, Landroid/media/AudioManager;->requestAudioFocus(Landroid/media/AudioManager$OnAudioFocusChangeListener;II)I

    move-result p1

    const/4 v0, 0x1

    if-ne p1, v0, :cond_1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public willPauseWhenDucked()Z
    .locals 4

    .line 156
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplBase;->mAudioFocusRequestCompat:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    .line 161
    :cond_0
    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->getAudioAttributesCompat()Landroidx/media/AudioAttributesCompat;

    move-result-object v0

    .line 163
    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImplBase;->mAudioFocusRequestCompat:Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;

    invoke-virtual {v2}, Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;->willPauseWhenDucked()Z

    move-result v2

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    .line 165
    invoke-virtual {v0}, Landroidx/media/AudioAttributesCompat;->getContentType()I

    move-result v0

    if-ne v0, v3, :cond_1

    const/4 v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    if-nez v2, :cond_2

    if-eqz v0, :cond_3

    :cond_2
    const/4 v1, 0x1

    :cond_3
    return v1
.end method
