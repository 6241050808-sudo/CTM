.class interface abstract Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper$AudioFocusHelperImpl;
.super Ljava/lang/Object;
.source "AudioFocusHelper.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusHelper;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "AudioFocusHelperImpl"
.end annotation


# virtual methods
.method public abstract abandonAudioFocus()V
.end method

.method public abstract requestAudioFocus(Lcom/thekirankumar/youtubeauto2/mediaplayer/AudioFocusRequestCompat;)Z
.end method

.method public abstract willPauseWhenDucked()Z
.end method
