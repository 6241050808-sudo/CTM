.class public final enum Lcom/thekirankumar/youtubeauto2/utils/SearchMode;
.super Ljava/lang/Enum;
.source "SearchMode.java"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/thekirankumar/youtubeauto2/utils/SearchMode;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

.field public static final enum GOOGLE:Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

.field public static final enum YOUTUBE:Lcom/thekirankumar/youtubeauto2/utils/SearchMode;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    .line 8
    new-instance v0, Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    const/4 v1, 0x0

    const-string v2, "YOUTUBE"

    invoke-direct {v0, v2, v1}, Lcom/thekirankumar/youtubeauto2/utils/SearchMode;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/thekirankumar/youtubeauto2/utils/SearchMode;->YOUTUBE:Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    new-instance v0, Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    const/4 v2, 0x1

    const-string v3, "GOOGLE"

    invoke-direct {v0, v3, v2}, Lcom/thekirankumar/youtubeauto2/utils/SearchMode;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/thekirankumar/youtubeauto2/utils/SearchMode;->GOOGLE:Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    const/4 v3, 0x2

    new-array v3, v3, [Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    .line 7
    sget-object v4, Lcom/thekirankumar/youtubeauto2/utils/SearchMode;->YOUTUBE:Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    aput-object v4, v3, v1

    aput-object v0, v3, v2

    sput-object v3, Lcom/thekirankumar/youtubeauto2/utils/SearchMode;->$VALUES:[Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 7
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/thekirankumar/youtubeauto2/utils/SearchMode;
    .locals 1

    .line 7
    const-class v0, Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    return-object p0
.end method

.method public static values()[Lcom/thekirankumar/youtubeauto2/utils/SearchMode;
    .locals 1

    .line 7
    sget-object v0, Lcom/thekirankumar/youtubeauto2/utils/SearchMode;->$VALUES:[Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    invoke-virtual {v0}, [Lcom/thekirankumar/youtubeauto2/utils/SearchMode;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/thekirankumar/youtubeauto2/utils/SearchMode;

    return-object v0
.end method
