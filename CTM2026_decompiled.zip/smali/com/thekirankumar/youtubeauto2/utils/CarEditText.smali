.class public Lcom/thekirankumar/youtubeauto2/utils/CarEditText;
.super Landroid/support/car/input/CarRestrictedEditText;
.source "CarEditText.java"

# interfaces
.implements Lcom/google/android/gms/car/input/CarEditable;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 0

    .line 16
    invoke-direct {p0, p1, p2}, Landroid/support/car/input/CarRestrictedEditText;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method


# virtual methods
.method public setCarEditableListener(Lcom/google/android/gms/car/input/CarEditableListener;)V
    .locals 1

    .line 21
    new-instance v0, Lcom/thekirankumar/youtubeauto2/utils/CarEditText$1;

    invoke-direct {v0, p0, p1}, Lcom/thekirankumar/youtubeauto2/utils/CarEditText$1;-><init>(Lcom/thekirankumar/youtubeauto2/utils/CarEditText;Lcom/google/android/gms/car/input/CarEditableListener;)V

    invoke-super {p0, v0}, Landroid/support/car/input/CarRestrictedEditText;->setCarEditableListener(Landroid/support/car/input/CarEditableListener;)V

    return-void
.end method
