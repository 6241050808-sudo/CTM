.class public Lcom/thekirankumar/youtubeauto2/utils/BroadcastFromPlayer;
.super Ljava/lang/Object;
.source "BroadcastFromPlayer.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static broadcastNextClicked(Landroid/content/Context;)V
    .locals 4

    .line 25
    new-instance v0, Landroid/content/Intent;

    const-string v1, "com.thekirankumar.youtubeauto2.player.event"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "action_type"

    const-wide/16 v2, 0x20

    .line 26
    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    .line 27
    invoke-virtual {p0, v0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    return-void
.end method

.method public static broadcastPauseClicked(Landroid/content/Context;)V
    .locals 4

    .line 20
    new-instance v0, Landroid/content/Intent;

    const-string v1, "com.thekirankumar.youtubeauto2.player.event"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "action_type"

    const-wide/16 v2, 0x2

    .line 21
    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    .line 22
    invoke-virtual {p0, v0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    return-void
.end method

.method public static broadcastPlayClicked(Landroid/content/Context;)V
    .locals 4

    .line 15
    new-instance v0, Landroid/content/Intent;

    const-string v1, "com.thekirankumar.youtubeauto2.player.event"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "action_type"

    const-wide/16 v2, 0x4

    .line 16
    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    .line 17
    invoke-virtual {p0, v0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    return-void
.end method

.method public static broadcastPreviousClicked(Landroid/content/Context;)V
    .locals 4

    .line 30
    new-instance v0, Landroid/content/Intent;

    const-string v1, "com.thekirankumar.youtubeauto2.player.event"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "action_type"

    const-wide/16 v2, 0x10

    .line 31
    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    .line 32
    invoke-virtual {p0, v0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    return-void
.end method

.method public static broadcastVoiceSearch(Landroid/content/Context;Ljava/lang/String;)V
    .locals 4

    .line 36
    new-instance v0, Landroid/content/Intent;

    const-string v1, "com.thekirankumar.youtubeauto2.player.event"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "action_type"

    const-wide/16 v2, 0x800

    .line 37
    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-string v1, "query"

    .line 38
    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 39
    invoke-virtual {p0, v0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    return-void
.end method
