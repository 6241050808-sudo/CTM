.class public Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener;
.super Ljava/lang/Object;
.source "MyRecognitionListener.java"

# interfaces
.implements Landroid/speech/RecognitionListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener$OnCompleteListener;
    }
.end annotation


# static fields
.field private static final TAG:Ljava/lang/String;


# instance fields
.field private listener:Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener$OnCompleteListener;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 14
    const-class v0, Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener;

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener;->TAG:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener$OnCompleteListener;)V
    .locals 0

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 18
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener;->listener:Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener$OnCompleteListener;

    return-void
.end method


# virtual methods
.method public onBeginningOfSpeech()V
    .locals 0

    return-void
.end method

.method public onBufferReceived([B)V
    .locals 0

    return-void
.end method

.method public onEndOfSpeech()V
    .locals 1

    .line 50
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener;->listener:Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener$OnCompleteListener;

    if-eqz v0, :cond_0

    .line 51
    invoke-interface {v0}, Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener$OnCompleteListener;->onEnd()V

    :cond_0
    return-void
.end method

.method public onError(I)V
    .locals 1

    .line 57
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener;->listener:Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener$OnCompleteListener;

    if-eqz v0, :cond_0

    .line 58
    invoke-interface {v0, p1}, Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener$OnCompleteListener;->onError(I)V

    :cond_0
    return-void
.end method

.method public onEvent(ILandroid/os/Bundle;)V
    .locals 0

    return-void
.end method

.method public onPartialResults(Landroid/os/Bundle;)V
    .locals 0

    return-void
.end method

.method public onReadyForSpeech(Landroid/os/Bundle;)V
    .locals 0

    return-void
.end method

.method public onResults(Landroid/os/Bundle;)V
    .locals 2

    const-string v0, "results_recognition"

    .line 64
    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object p1

    .line 65
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    if-lez v0, :cond_0

    .line 66
    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    .line 67
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener;->listener:Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener$OnCompleteListener;

    if-eqz v0, :cond_1

    .line 68
    invoke-interface {v0, p1}, Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener$OnCompleteListener;->onVoiceRecognitionComplete(Ljava/lang/String;)V

    goto :goto_0

    .line 71
    :cond_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener;->listener:Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener$OnCompleteListener;

    if-eqz p1, :cond_1

    .line 72
    invoke-interface {p1, v1}, Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener$OnCompleteListener;->onError(I)V

    :cond_1
    :goto_0
    return-void
.end method

.method public onRmsChanged(F)V
    .locals 0

    return-void
.end method

.method public setListener(Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener$OnCompleteListener;)V
    .locals 0

    .line 25
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener;->listener:Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener$OnCompleteListener;

    return-void
.end method
