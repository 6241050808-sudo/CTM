.class public final Lcom/thekirankumar/youtubeauto2/utils/AspectRatioFrameLayout;
.super Landroid/widget/FrameLayout;
.source "AspectRatioFrameLayout.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thekirankumar/youtubeauto2/utils/AspectRatioFrameLayout$ResizeMode;
    }
.end annotation


# static fields
.field private static final MAX_ASPECT_RATIO_DEFORMATION_FRACTION:F = 0.01f

.field public static final RESIZE_MODE_FILL:I = 0x3

.field public static final RESIZE_MODE_FIT:I = 0x0

.field public static final RESIZE_MODE_FIXED_HEIGHT:I = 0x2

.field public static final RESIZE_MODE_FIXED_WIDTH:I = 0x1

.field public static final RESIZE_MODE_ZOOM:I = 0x4


# instance fields
.field private resizeMode:I

.field private videoAspectRatio:F


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    const/4 v0, 0x0

    .line 74
    invoke-direct {p0, p1, v0}, Lcom/thekirankumar/youtubeauto2/utils/AspectRatioFrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 0

    .line 78
    invoke-direct {p0, p1, p2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method


# virtual methods
.method public getResizeMode()I
    .locals 1

    .line 97
    iget v0, p0, Lcom/thekirankumar/youtubeauto2/utils/AspectRatioFrameLayout;->resizeMode:I

    return v0
.end method

.method protected onMeasure(II)V
    .locals 6

    .line 114
    invoke-super {p0, p1, p2}, Landroid/widget/FrameLayout;->onMeasure(II)V

    .line 115
    iget p1, p0, Lcom/thekirankumar/youtubeauto2/utils/AspectRatioFrameLayout;->resizeMode:I

    const/4 p2, 0x3

    if-eq p1, p2, :cond_7

    iget p1, p0, Lcom/thekirankumar/youtubeauto2/utils/AspectRatioFrameLayout;->videoAspectRatio:F

    const/4 p2, 0x0

    cmpg-float p1, p1, p2

    if-gtz p1, :cond_0

    goto :goto_3

    .line 120
    :cond_0
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/utils/AspectRatioFrameLayout;->getMeasuredWidth()I

    move-result p1

    .line 121
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/utils/AspectRatioFrameLayout;->getMeasuredHeight()I

    move-result v0

    int-to-float v1, p1

    int-to-float v2, v0

    div-float v3, v1, v2

    .line 123
    iget v4, p0, Lcom/thekirankumar/youtubeauto2/utils/AspectRatioFrameLayout;->videoAspectRatio:F

    div-float/2addr v4, v3

    const/high16 v3, 0x3f800000    # 1.0f

    sub-float/2addr v4, v3

    .line 124
    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    move-result v3

    const v5, 0x3c23d70a    # 0.01f

    cmpg-float v3, v3, v5

    if-gtz v3, :cond_1

    return-void

    .line 129
    :cond_1
    iget v3, p0, Lcom/thekirankumar/youtubeauto2/utils/AspectRatioFrameLayout;->resizeMode:I

    const/4 v5, 0x1

    if-eq v3, v5, :cond_6

    const/4 v5, 0x2

    if-eq v3, v5, :cond_5

    const/4 v5, 0x4

    if-eq v3, v5, :cond_3

    cmpl-float p2, v4, p2

    if-lez p2, :cond_2

    .line 145
    iget p2, p0, Lcom/thekirankumar/youtubeauto2/utils/AspectRatioFrameLayout;->videoAspectRatio:F

    goto :goto_1

    .line 147
    :cond_2
    iget p1, p0, Lcom/thekirankumar/youtubeauto2/utils/AspectRatioFrameLayout;->videoAspectRatio:F

    goto :goto_0

    :cond_3
    cmpl-float p2, v4, p2

    if-lez p2, :cond_4

    .line 138
    iget p1, p0, Lcom/thekirankumar/youtubeauto2/utils/AspectRatioFrameLayout;->videoAspectRatio:F

    goto :goto_0

    .line 140
    :cond_4
    iget p2, p0, Lcom/thekirankumar/youtubeauto2/utils/AspectRatioFrameLayout;->videoAspectRatio:F

    goto :goto_1

    .line 134
    :cond_5
    iget p1, p0, Lcom/thekirankumar/youtubeauto2/utils/AspectRatioFrameLayout;->videoAspectRatio:F

    :goto_0
    mul-float v2, v2, p1

    float-to-int p1, v2

    goto :goto_2

    .line 131
    :cond_6
    iget p2, p0, Lcom/thekirankumar/youtubeauto2/utils/AspectRatioFrameLayout;->videoAspectRatio:F

    :goto_1
    div-float/2addr v1, p2

    float-to-int v0, v1

    :goto_2
    const/high16 p2, 0x40000000    # 2.0f

    .line 151
    invoke-static {p1, p2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p1

    .line 152
    invoke-static {v0, p2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p2

    .line 151
    invoke-super {p0, p1, p2}, Landroid/widget/FrameLayout;->onMeasure(II)V

    :cond_7
    :goto_3
    return-void
.end method

.method public setAspectRatio(F)V
    .locals 1

    .line 87
    iget v0, p0, Lcom/thekirankumar/youtubeauto2/utils/AspectRatioFrameLayout;->videoAspectRatio:F

    cmpl-float v0, v0, p1

    if-eqz v0, :cond_0

    .line 88
    iput p1, p0, Lcom/thekirankumar/youtubeauto2/utils/AspectRatioFrameLayout;->videoAspectRatio:F

    .line 89
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/utils/AspectRatioFrameLayout;->requestLayout()V

    :cond_0
    return-void
.end method

.method public setResizeMode(I)V
    .locals 1

    .line 106
    iget v0, p0, Lcom/thekirankumar/youtubeauto2/utils/AspectRatioFrameLayout;->resizeMode:I

    if-eq v0, p1, :cond_0

    .line 107
    iput p1, p0, Lcom/thekirankumar/youtubeauto2/utils/AspectRatioFrameLayout;->resizeMode:I

    .line 108
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/utils/AspectRatioFrameLayout;->requestLayout()V

    :cond_0
    return-void
.end method
