.class public Lcom/thekirankumar/youtubeauto2/utils/MyExceptionHandler;
.super Ljava/lang/Object;
.source "MyExceptionHandler.java"

# interfaces
.implements Ljava/lang/Thread$UncaughtExceptionHandler;


# instance fields
.field private activity:Lcom/google/android/apps/auto/sdk/CarActivity;


# direct methods
.method public constructor <init>(Lcom/google/android/apps/auto/sdk/CarActivity;)V
    .locals 0

    .line 14
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 15
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/utils/MyExceptionHandler;->activity:Lcom/google/android/apps/auto/sdk/CarActivity;

    return-void
.end method


# virtual methods
.method public uncaughtException(Ljava/lang/Thread;Ljava/lang/Throwable;)V
    .locals 5

    .line 20
    new-instance p1, Landroid/content/Intent;

    iget-object p2, p0, Lcom/thekirankumar/youtubeauto2/utils/MyExceptionHandler;->activity:Lcom/google/android/apps/auto/sdk/CarActivity;

    const-class v0, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;

    invoke-direct {p1, p2, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 p2, 0x1

    const-string v0, "crash"

    .line 21
    invoke-virtual {p1, v0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const v0, 0x14008000

    .line 22
    invoke-virtual {p1, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 25
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MyExceptionHandler;->activity:Lcom/google/android/apps/auto/sdk/CarActivity;

    const/4 v1, 0x0

    const/high16 v2, 0x40000000    # 2.0f

    invoke-static {v0, v1, p1, v2}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object p1

    .line 26
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MyExceptionHandler;->activity:Lcom/google/android/apps/auto/sdk/CarActivity;

    const-string v1, "alarm"

    invoke-virtual {v0, v1}, Lcom/google/android/apps/auto/sdk/CarActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/AlarmManager;

    .line 27
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const-wide/16 v3, 0x3e8

    add-long/2addr v1, v3

    invoke-virtual {v0, p2, v1, v2, p1}, Landroid/app/AlarmManager;->set(IJLandroid/app/PendingIntent;)V

    return-void
.end method
