.class public Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;
.super Landroid/content/BroadcastReceiver;
.source "MediaNotificationManager.java"


# static fields
.field public static final ACTION_NEXT:Ljava/lang/String; = "com.thekirankumar.youtubeauto2.next"

.field public static final ACTION_PAUSE:Ljava/lang/String; = "com.thekirankumar.youtubeauto2.pauseVideo"

.field public static final ACTION_PLAY:Ljava/lang/String; = "com.thekirankumar.youtubeauto2.playVideo"

.field public static final ACTION_PREV:Ljava/lang/String; = "com.thekirankumar.youtubeauto2.prev"

.field public static final ACTION_STOP:Ljava/lang/String; = "com.thekirankumar.youtubeauto2.stop"

.field public static final ACTION_STOP_CASTING:Ljava/lang/String; = "com.thekirankumar.youtubeauto2.stop_cast"

.field private static final CHANNEL_ID:Ljava/lang/String; = "com.thekirankumar.youtubeauto2.MUSIC_CHANNEL_ID"

.field private static final NOTIFICATION_ID:I = 0x19c

.field private static final REQUEST_CODE:I = 0x64

.field private static final TAG:Ljava/lang/String;


# instance fields
.field private final mCb:Landroid/support/v4/media/session/MediaControllerCompat$Callback;

.field private final mContext:Landroid/content/Context;

.field private mController:Landroid/support/v4/media/session/MediaControllerCompat;

.field private mMetadata:Landroid/support/v4/media/MediaMetadataCompat;

.field private final mNextIntent:Landroid/app/PendingIntent;

.field private final mNotificationManager:Landroidx/core/app/NotificationManagerCompat;

.field private final mPauseIntent:Landroid/app/PendingIntent;

.field private final mPlayIntent:Landroid/app/PendingIntent;

.field private mPlaybackState:Landroid/support/v4/media/session/PlaybackStateCompat;

.field private final mPreviousIntent:Landroid/app/PendingIntent;

.field private mSessionToken:Landroid/support/v4/media/session/MediaSessionCompat$Token;

.field private mStarted:Z

.field private final mStopCastIntent:Landroid/app/PendingIntent;

.field private final mStopIntent:Landroid/app/PendingIntent;

.field private mTransportControls:Landroid/support/v4/media/session/MediaControllerCompat$TransportControls;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 65
    const-class v0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->TAG:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/support/v4/media/session/MediaSessionCompat$Token;)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 118
    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    const/4 v0, 0x0

    .line 79
    iput-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mStarted:Z

    .line 80
    new-instance v0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager$1;

    invoke-direct {v0, p0}, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager$1;-><init>(Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;)V

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mCb:Landroid/support/v4/media/session/MediaControllerCompat$Callback;

    .line 119
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mContext:Landroid/content/Context;

    .line 120
    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mSessionToken:Landroid/support/v4/media/session/MediaSessionCompat$Token;

    .line 121
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->updateSessionToken()V

    .line 123
    invoke-static {p1}, Landroidx/core/app/NotificationManagerCompat;->from(Landroid/content/Context;)Landroidx/core/app/NotificationManagerCompat;

    move-result-object p2

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mNotificationManager:Landroidx/core/app/NotificationManagerCompat;

    .line 125
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p2

    .line 126
    new-instance v0, Landroid/content/Intent;

    const-string v1, "com.thekirankumar.youtubeauto2.pauseVideo"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 127
    invoke-virtual {v0, p2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/high16 v1, 0x10000000

    const/16 v2, 0x64

    .line 126
    invoke-static {p1, v2, v0, v1}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v0

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mPauseIntent:Landroid/app/PendingIntent;

    .line 128
    new-instance v0, Landroid/content/Intent;

    const-string v3, "com.thekirankumar.youtubeauto2.playVideo"

    invoke-direct {v0, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 129
    invoke-virtual {v0, p2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    .line 128
    invoke-static {p1, v2, v0, v1}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v0

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mPlayIntent:Landroid/app/PendingIntent;

    .line 130
    new-instance v0, Landroid/content/Intent;

    const-string v3, "com.thekirankumar.youtubeauto2.prev"

    invoke-direct {v0, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 131
    invoke-virtual {v0, p2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    .line 130
    invoke-static {p1, v2, v0, v1}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v0

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mPreviousIntent:Landroid/app/PendingIntent;

    .line 132
    new-instance v0, Landroid/content/Intent;

    const-string v3, "com.thekirankumar.youtubeauto2.next"

    invoke-direct {v0, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 133
    invoke-virtual {v0, p2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    .line 132
    invoke-static {p1, v2, v0, v1}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v0

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mNextIntent:Landroid/app/PendingIntent;

    .line 134
    new-instance v0, Landroid/content/Intent;

    const-string v3, "com.thekirankumar.youtubeauto2.stop"

    invoke-direct {v0, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 135
    invoke-virtual {v0, p2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    .line 134
    invoke-static {p1, v2, v0, v1}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v0

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mStopIntent:Landroid/app/PendingIntent;

    .line 136
    new-instance v0, Landroid/content/Intent;

    const-string v3, "com.thekirankumar.youtubeauto2.stop_cast"

    invoke-direct {v0, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 137
    invoke-virtual {v0, p2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p2

    .line 136
    invoke-static {p1, v2, p2, v1}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object p1

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mStopCastIntent:Landroid/app/PendingIntent;

    .line 142
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mNotificationManager:Landroidx/core/app/NotificationManagerCompat;

    invoke-virtual {p1}, Landroidx/core/app/NotificationManagerCompat;->cancelAll()V

    return-void
.end method

.method static synthetic access$002(Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;Landroid/support/v4/media/session/PlaybackStateCompat;)Landroid/support/v4/media/session/PlaybackStateCompat;
    .locals 0

    .line 54
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mPlaybackState:Landroid/support/v4/media/session/PlaybackStateCompat;

    return-object p1
.end method

.method static synthetic access$100()Ljava/lang/String;
    .locals 1

    .line 54
    sget-object v0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->TAG:Ljava/lang/String;

    return-object v0
.end method

.method static synthetic access$200(Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;)Landroid/app/Notification;
    .locals 0

    .line 54
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->createNotification()Landroid/app/Notification;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$300(Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;)Landroidx/core/app/NotificationManagerCompat;
    .locals 0

    .line 54
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mNotificationManager:Landroidx/core/app/NotificationManagerCompat;

    return-object p0
.end method

.method static synthetic access$402(Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;Landroid/support/v4/media/MediaMetadataCompat;)Landroid/support/v4/media/MediaMetadataCompat;
    .locals 0

    .line 54
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mMetadata:Landroid/support/v4/media/MediaMetadataCompat;

    return-object p1
.end method

.method static synthetic access$500(Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;)V
    .locals 0
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 54
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->updateSessionToken()V

    return-void
.end method

.method private addActions(Landroidx/core/app/NotificationCompat$Builder;)I
    .locals 8

    .line 294
    sget-object v0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->TAG:Ljava/lang/String;

    const-string v1, "updatePlayPauseAction"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 298
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mPlaybackState:Landroid/support/v4/media/session/PlaybackStateCompat;

    invoke-virtual {v0}, Landroid/support/v4/media/session/PlaybackStateCompat;->getActions()J

    move-result-wide v0

    const-wide/16 v2, 0x10

    and-long/2addr v0, v2

    const-wide/16 v2, 0x0

    cmp-long v4, v0, v2

    if-eqz v4, :cond_0

    const v0, 0x7f0700d0

    .line 299
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mPreviousIntent:Landroid/app/PendingIntent;

    const-string v4, "Previous"

    invoke-virtual {p1, v0, v4, v1}, Landroidx/core/app/NotificationCompat$Builder;->addAction(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)Landroidx/core/app/NotificationCompat$Builder;

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    .line 313
    :goto_0
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mPlaybackState:Landroid/support/v4/media/session/PlaybackStateCompat;

    invoke-virtual {v1}, Landroid/support/v4/media/session/PlaybackStateCompat;->getState()I

    move-result v1

    const/4 v4, 0x3

    if-ne v1, v4, :cond_1

    const v1, 0x7f0700ce

    .line 316
    iget-object v4, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mPauseIntent:Landroid/app/PendingIntent;

    const-string v5, "Pause"

    goto :goto_1

    :cond_1
    const v1, 0x7f0700cf

    .line 320
    iget-object v4, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mPlayIntent:Landroid/app/PendingIntent;

    const-string v5, "Play"

    .line 322
    :goto_1
    new-instance v6, Landroidx/core/app/NotificationCompat$Action;

    invoke-direct {v6, v1, v5, v4}, Landroidx/core/app/NotificationCompat$Action;-><init>(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)V

    invoke-virtual {p1, v6}, Landroidx/core/app/NotificationCompat$Builder;->addAction(Landroidx/core/app/NotificationCompat$Action;)Landroidx/core/app/NotificationCompat$Builder;

    .line 325
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mPlaybackState:Landroid/support/v4/media/session/PlaybackStateCompat;

    invoke-virtual {v1}, Landroid/support/v4/media/session/PlaybackStateCompat;->getActions()J

    move-result-wide v4

    const-wide/16 v6, 0x20

    and-long/2addr v4, v6

    cmp-long v1, v4, v2

    if-eqz v1, :cond_2

    const v1, 0x7f0700cd

    .line 326
    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mNextIntent:Landroid/app/PendingIntent;

    const-string v3, "Next"

    invoke-virtual {p1, v1, v3, v2}, Landroidx/core/app/NotificationCompat$Builder;->addAction(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)Landroidx/core/app/NotificationCompat$Builder;

    :cond_2
    return v0
.end method

.method private createContentIntent(Landroid/support/v4/media/MediaDescriptionCompat;)Landroid/app/PendingIntent;
    .locals 3

    .line 235
    new-instance p1, Landroid/content/Intent;

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mContext:Landroid/content/Context;

    const-class v1, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;

    invoke-direct {p1, v0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v0, 0x20000000

    .line 236
    invoke-virtual {p1, v0}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    .line 237
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mContext:Landroid/content/Context;

    const/16 v1, 0x64

    const/high16 v2, 0x10000000

    invoke-static {v0, v1, p1, v2}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object p1

    return-object p1
.end method

.method private createNotification()Landroid/app/Notification;
    .locals 8

    .line 242
    sget-object v0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "updateNotificationMetadata. mMetadata="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mMetadata:Landroid/support/v4/media/MediaMetadataCompat;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 243
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mMetadata:Landroid/support/v4/media/MediaMetadataCompat;

    const/4 v1, 0x0

    if-eqz v0, :cond_4

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mPlaybackState:Landroid/support/v4/media/session/PlaybackStateCompat;

    if-nez v0, :cond_0

    goto/16 :goto_0

    .line 247
    :cond_0
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mContext:Landroid/content/Context;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/utils/SettingsUtils;->isDisabledNotifications(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_1

    return-object v1

    .line 251
    :cond_1
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mMetadata:Landroid/support/v4/media/MediaMetadataCompat;

    invoke-virtual {v0}, Landroid/support/v4/media/MediaMetadataCompat;->getDescription()Landroid/support/v4/media/MediaDescriptionCompat;

    move-result-object v0

    .line 255
    invoke-virtual {v0}, Landroid/support/v4/media/MediaDescriptionCompat;->getIconUri()Landroid/net/Uri;

    move-result-object v2

    if-eqz v2, :cond_2

    .line 259
    invoke-virtual {v0}, Landroid/support/v4/media/MediaDescriptionCompat;->getIconUri()Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v2}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 264
    :cond_2
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0x1a

    if-lt v2, v3, :cond_3

    .line 265
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->createNotificationChannel()V

    .line 268
    :cond_3
    new-instance v2, Landroidx/core/app/NotificationCompat$Builder;

    iget-object v3, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mContext:Landroid/content/Context;

    const-string v4, "com.thekirankumar.youtubeauto2.MUSIC_CHANNEL_ID"

    invoke-direct {v2, v3, v4}, Landroidx/core/app/NotificationCompat$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 271
    invoke-direct {p0, v2}, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->addActions(Landroidx/core/app/NotificationCompat$Builder;)I

    move-result v3

    .line 272
    new-instance v4, Landroidx/media/app/NotificationCompat$MediaStyle;

    invoke-direct {v4}, Landroidx/media/app/NotificationCompat$MediaStyle;-><init>()V

    const/4 v5, 0x1

    new-array v6, v5, [I

    const/4 v7, 0x0

    aput v3, v6, v7

    .line 275
    invoke-virtual {v4, v6}, Landroidx/media/app/NotificationCompat$MediaStyle;->setShowActionsInCompactView([I)Landroidx/media/app/NotificationCompat$MediaStyle;

    move-result-object v3

    .line 276
    invoke-virtual {v3, v5}, Landroidx/media/app/NotificationCompat$MediaStyle;->setShowCancelButton(Z)Landroidx/media/app/NotificationCompat$MediaStyle;

    move-result-object v3

    iget-object v4, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mStopIntent:Landroid/app/PendingIntent;

    .line 277
    invoke-virtual {v3, v4}, Landroidx/media/app/NotificationCompat$MediaStyle;->setCancelButtonIntent(Landroid/app/PendingIntent;)Landroidx/media/app/NotificationCompat$MediaStyle;

    move-result-object v3

    iget-object v4, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mSessionToken:Landroid/support/v4/media/session/MediaSessionCompat$Token;

    .line 278
    invoke-virtual {v3, v4}, Landroidx/media/app/NotificationCompat$MediaStyle;->setMediaSession(Landroid/support/v4/media/session/MediaSessionCompat$Token;)Landroidx/media/app/NotificationCompat$MediaStyle;

    move-result-object v3

    .line 273
    invoke-virtual {v2, v3}, Landroidx/core/app/NotificationCompat$Builder;->setStyle(Landroidx/core/app/NotificationCompat$Style;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v3

    iget-object v4, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mStopIntent:Landroid/app/PendingIntent;

    .line 279
    invoke-virtual {v3, v4}, Landroidx/core/app/NotificationCompat$Builder;->setDeleteIntent(Landroid/app/PendingIntent;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v3

    const/high16 v4, 0x7f0d0000

    .line 280
    invoke-virtual {v3, v4}, Landroidx/core/app/NotificationCompat$Builder;->setSmallIcon(I)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v3

    .line 281
    invoke-virtual {v3, v5}, Landroidx/core/app/NotificationCompat$Builder;->setVisibility(I)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v3

    .line 282
    invoke-virtual {v3, v5}, Landroidx/core/app/NotificationCompat$Builder;->setOnlyAlertOnce(Z)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v3

    .line 283
    invoke-direct {p0, v0}, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->createContentIntent(Landroid/support/v4/media/MediaDescriptionCompat;)Landroid/app/PendingIntent;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroidx/core/app/NotificationCompat$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v3

    .line 284
    invoke-virtual {v0}, Landroid/support/v4/media/MediaDescriptionCompat;->getTitle()Ljava/lang/CharSequence;

    move-result-object v4

    invoke-virtual {v3, v4}, Landroidx/core/app/NotificationCompat$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v3

    .line 285
    invoke-virtual {v0}, Landroid/support/v4/media/MediaDescriptionCompat;->getSubtitle()Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v3, v0}, Landroidx/core/app/NotificationCompat$Builder;->setContentText(Ljava/lang/CharSequence;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v0

    .line 286
    invoke-virtual {v0, v1}, Landroidx/core/app/NotificationCompat$Builder;->setLargeIcon(Landroid/graphics/Bitmap;)Landroidx/core/app/NotificationCompat$Builder;

    .line 288
    invoke-direct {p0, v2}, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->setNotificationPlaybackState(Landroidx/core/app/NotificationCompat$Builder;)V

    .line 289
    new-instance v0, Lcom/google/android/apps/auto/sdk/notification/CarNotificationExtender;

    invoke-virtual {v2}, Landroidx/core/app/NotificationCompat$Builder;->build()Landroid/app/Notification;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/google/android/apps/auto/sdk/notification/CarNotificationExtender;-><init>(Landroid/app/Notification;)V

    invoke-virtual {v0, v2}, Lcom/google/android/apps/auto/sdk/notification/CarNotificationExtender;->extend(Landroidx/core/app/NotificationCompat$Builder;)Landroidx/core/app/NotificationCompat$Builder;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/core/app/NotificationCompat$Builder;->build()Landroid/app/Notification;

    move-result-object v0

    return-object v0

    :cond_4
    :goto_0
    return-object v1
.end method

.method private createNotificationChannel()V
    .locals 4

    .line 351
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    if-lt v0, v1, :cond_0

    .line 352
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mContext:Landroid/content/Context;

    const v1, 0x7f100026

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x4

    .line 355
    new-instance v2, Landroid/app/NotificationChannel;

    const-string v3, "com.thekirankumar.youtubeauto2.MUSIC_CHANNEL_ID"

    invoke-direct {v2, v3, v0, v1}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    const-string v0, "Plays youtube audio"

    .line 356
    invoke-virtual {v2, v0}, Landroid/app/NotificationChannel;->setDescription(Ljava/lang/String;)V

    const/4 v0, 0x1

    .line 357
    invoke-virtual {v2, v0}, Landroid/app/NotificationChannel;->enableLights(Z)V

    const-string v1, "#5B3C88"

    .line 358
    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    invoke-virtual {v2, v1}, Landroid/app/NotificationChannel;->setLightColor(I)V

    .line 359
    invoke-virtual {v2, v0}, Landroid/app/NotificationChannel;->enableVibration(Z)V

    .line 360
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mContext:Landroid/content/Context;

    const-string v1, "notification"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    .line 361
    invoke-virtual {v0, v2}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    :cond_0
    return-void
.end method

.method private setNotificationPlaybackState(Landroidx/core/app/NotificationCompat$Builder;)V
    .locals 3

    .line 334
    sget-object v0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->TAG:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "updateNotificationPlaybackState. mPlaybackState="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mPlaybackState:Landroid/support/v4/media/session/PlaybackStateCompat;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 335
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mPlaybackState:Landroid/support/v4/media/session/PlaybackStateCompat;

    if-eqz v0, :cond_2

    iget-boolean v1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mStarted:Z

    if-nez v1, :cond_0

    goto :goto_1

    .line 342
    :cond_0
    invoke-virtual {v0}, Landroid/support/v4/media/session/PlaybackStateCompat;->getState()I

    move-result v0

    const/4 v1, 0x3

    if-ne v0, v1, :cond_1

    const/4 v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p1, v0}, Landroidx/core/app/NotificationCompat$Builder;->setOngoing(Z)Landroidx/core/app/NotificationCompat$Builder;

    return-void

    .line 336
    :cond_2
    :goto_1
    sget-object p1, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->TAG:Ljava/lang/String;

    const-string v0, "updateNotificationPlaybackState. cancelling notification!"

    invoke-static {p1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 337
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mNotificationManager:Landroidx/core/app/NotificationManagerCompat;

    invoke-virtual {p1}, Landroidx/core/app/NotificationManagerCompat;->cancelAll()V

    return-void
.end method

.method private updateSessionToken()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    .line 218
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mSessionToken:Landroid/support/v4/media/session/MediaSessionCompat$Token;

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mSessionToken:Landroid/support/v4/media/session/MediaSessionCompat$Token;

    if-eqz v0, :cond_1

    const/4 v1, 0x0

    .line 219
    invoke-virtual {v0, v1}, Landroid/support/v4/media/session/MediaSessionCompat$Token;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    .line 220
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mController:Landroid/support/v4/media/session/MediaControllerCompat;

    if-eqz v0, :cond_0

    .line 221
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mCb:Landroid/support/v4/media/session/MediaControllerCompat$Callback;

    invoke-virtual {v0, v1}, Landroid/support/v4/media/session/MediaControllerCompat;->unregisterCallback(Landroid/support/v4/media/session/MediaControllerCompat$Callback;)V

    .line 224
    :cond_0
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mSessionToken:Landroid/support/v4/media/session/MediaSessionCompat$Token;

    if-eqz v0, :cond_1

    .line 225
    new-instance v1, Landroid/support/v4/media/session/MediaControllerCompat;

    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mContext:Landroid/content/Context;

    invoke-direct {v1, v2, v0}, Landroid/support/v4/media/session/MediaControllerCompat;-><init>(Landroid/content/Context;Landroid/support/v4/media/session/MediaSessionCompat$Token;)V

    iput-object v1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mController:Landroid/support/v4/media/session/MediaControllerCompat;

    .line 226
    invoke-virtual {v1}, Landroid/support/v4/media/session/MediaControllerCompat;->getTransportControls()Landroid/support/v4/media/session/MediaControllerCompat$TransportControls;

    move-result-object v0

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mTransportControls:Landroid/support/v4/media/session/MediaControllerCompat$TransportControls;

    .line 227
    iget-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mStarted:Z

    if-eqz v0, :cond_1

    .line 228
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mController:Landroid/support/v4/media/session/MediaControllerCompat;

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mCb:Landroid/support/v4/media/session/MediaControllerCompat$Callback;

    invoke-virtual {v0, v1}, Landroid/support/v4/media/session/MediaControllerCompat;->registerCallback(Landroid/support/v4/media/session/MediaControllerCompat$Callback;)V

    :cond_1
    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 3

    .line 192
    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    .line 193
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result p2

    const/4 v0, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    sparse-switch p2, :sswitch_data_0

    goto :goto_0

    :sswitch_0
    const-string p2, "com.thekirankumar.youtubeauto2.playVideo"

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_0

    const/4 p2, 0x1

    goto :goto_1

    :sswitch_1
    const-string p2, "com.thekirankumar.youtubeauto2.pauseVideo"

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_0

    const/4 p2, 0x0

    goto :goto_1

    :sswitch_2
    const-string p2, "com.thekirankumar.youtubeauto2.prev"

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_0

    const/4 p2, 0x3

    goto :goto_1

    :sswitch_3
    const-string p2, "com.thekirankumar.youtubeauto2.next"

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_0

    const/4 p2, 0x2

    goto :goto_1

    :cond_0
    :goto_0
    const/4 p2, -0x1

    :goto_1
    if-eqz p2, :cond_4

    if-eq p2, v2, :cond_3

    if-eq p2, v1, :cond_2

    if-eq p2, v0, :cond_1

    .line 207
    sget-object p2, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->TAG:Ljava/lang/String;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "Unknown intent ignored. Action="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p2, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_2

    .line 204
    :cond_1
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mTransportControls:Landroid/support/v4/media/session/MediaControllerCompat$TransportControls;

    invoke-virtual {p1}, Landroid/support/v4/media/session/MediaControllerCompat$TransportControls;->skipToPrevious()V

    goto :goto_2

    .line 201
    :cond_2
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mTransportControls:Landroid/support/v4/media/session/MediaControllerCompat$TransportControls;

    invoke-virtual {p1}, Landroid/support/v4/media/session/MediaControllerCompat$TransportControls;->skipToNext()V

    goto :goto_2

    .line 198
    :cond_3
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mTransportControls:Landroid/support/v4/media/session/MediaControllerCompat$TransportControls;

    invoke-virtual {p1}, Landroid/support/v4/media/session/MediaControllerCompat$TransportControls;->play()V

    goto :goto_2

    .line 195
    :cond_4
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mTransportControls:Landroid/support/v4/media/session/MediaControllerCompat$TransportControls;

    invoke-virtual {p1}, Landroid/support/v4/media/session/MediaControllerCompat$TransportControls;->pause()V

    :goto_2
    return-void

    nop

    :sswitch_data_0
    .sparse-switch
        -0x5895156 -> :sswitch_3
        -0x5883a16 -> :sswitch_2
        0x435d869c -> :sswitch_1
        0x79151050 -> :sswitch_0
    .end sparse-switch
.end method

.method public startNotification(Landroid/app/Service;)V
    .locals 3

    .line 151
    iget-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mStarted:Z

    if-nez v0, :cond_0

    .line 152
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mController:Landroid/support/v4/media/session/MediaControllerCompat;

    invoke-virtual {v0}, Landroid/support/v4/media/session/MediaControllerCompat;->getMetadata()Landroid/support/v4/media/MediaMetadataCompat;

    move-result-object v0

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mMetadata:Landroid/support/v4/media/MediaMetadataCompat;

    .line 153
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mController:Landroid/support/v4/media/session/MediaControllerCompat;

    invoke-virtual {v0}, Landroid/support/v4/media/session/MediaControllerCompat;->getPlaybackState()Landroid/support/v4/media/session/PlaybackStateCompat;

    move-result-object v0

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mPlaybackState:Landroid/support/v4/media/session/PlaybackStateCompat;

    .line 156
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->createNotification()Landroid/app/Notification;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 158
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mController:Landroid/support/v4/media/session/MediaControllerCompat;

    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mCb:Landroid/support/v4/media/session/MediaControllerCompat$Callback;

    invoke-virtual {v1, v2}, Landroid/support/v4/media/session/MediaControllerCompat;->registerCallback(Landroid/support/v4/media/session/MediaControllerCompat$Callback;)V

    .line 159
    new-instance v1, Landroid/content/IntentFilter;

    invoke-direct {v1}, Landroid/content/IntentFilter;-><init>()V

    const-string v2, "com.thekirankumar.youtubeauto2.next"

    .line 160
    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v2, "com.thekirankumar.youtubeauto2.pauseVideo"

    .line 161
    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v2, "com.thekirankumar.youtubeauto2.playVideo"

    .line 162
    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v2, "com.thekirankumar.youtubeauto2.prev"

    .line 163
    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v2, "com.thekirankumar.youtubeauto2.stop_cast"

    .line 164
    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 165
    iget-object v2, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mContext:Landroid/content/Context;

    invoke-virtual {v2, p0, v1}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v1, 0x19c

    .line 166
    invoke-virtual {p1, v1, v0}, Landroid/app/Service;->startForeground(ILandroid/app/Notification;)V

    const/4 p1, 0x1

    .line 167
    iput-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mStarted:Z

    :cond_0
    return-void
.end method

.method public stopNotification()V
    .locals 2

    .line 177
    iget-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mStarted:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    .line 178
    iput-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mStarted:Z

    .line 179
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mController:Landroid/support/v4/media/session/MediaControllerCompat;

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mCb:Landroid/support/v4/media/session/MediaControllerCompat$Callback;

    invoke-virtual {v0, v1}, Landroid/support/v4/media/session/MediaControllerCompat;->unregisterCallback(Landroid/support/v4/media/session/MediaControllerCompat$Callback;)V

    .line 181
    :try_start_0
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mNotificationManager:Landroidx/core/app/NotificationManagerCompat;

    const/16 v1, 0x19c

    invoke-virtual {v0, v1}, Landroidx/core/app/NotificationManagerCompat;->cancel(I)V

    .line 182
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mContext:Landroid/content/Context;

    invoke-virtual {v0, p0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 186
    :catch_0
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->mNotificationManager:Landroidx/core/app/NotificationManagerCompat;

    invoke-virtual {v0}, Landroidx/core/app/NotificationManagerCompat;->cancelAll()V

    :cond_0
    return-void
.end method
