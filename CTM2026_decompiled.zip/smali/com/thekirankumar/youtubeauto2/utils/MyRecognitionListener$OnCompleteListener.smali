.class public interface abstract Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener$OnCompleteListener;
.super Ljava/lang/Object;
.source "MyRecognitionListener.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thekirankumar/youtubeauto2/utils/MyRecognitionListener;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "OnCompleteListener"
.end annotation


# virtual methods
.method public abstract onEnd()V
.end method

.method public abstract onError(I)V
.end method

.method public abstract onVoiceRecognitionComplete(Ljava/lang/String;)V
.end method
