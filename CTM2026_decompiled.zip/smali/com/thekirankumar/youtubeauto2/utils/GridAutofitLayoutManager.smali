.class public Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;
.super Landroidx/recyclerview/widget/GridLayoutManager;
.source "GridAutofitLayoutManager.java"


# instance fields
.field private mColumnWidth:I

.field private mColumnWidthChanged:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;I)V
    .locals 1

    const/4 v0, 0x1

    .line 16
    invoke-direct {p0, p1, v0}, Landroidx/recyclerview/widget/GridLayoutManager;-><init>(Landroid/content/Context;I)V

    .line 11
    iput-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;->mColumnWidthChanged:Z

    .line 17
    invoke-direct {p0, p1, p2}, Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;->checkedColumnWidth(Landroid/content/Context;I)I

    move-result p1

    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;->setColumnWidth(I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;IIZ)V
    .locals 1

    const/4 v0, 0x1

    .line 23
    invoke-direct {p0, p1, v0, p3, p4}, Landroidx/recyclerview/widget/GridLayoutManager;-><init>(Landroid/content/Context;IIZ)V

    .line 11
    iput-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;->mColumnWidthChanged:Z

    .line 24
    invoke-direct {p0, p1, p2}, Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;->checkedColumnWidth(Landroid/content/Context;I)I

    move-result p1

    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;->setColumnWidth(I)V

    return-void
.end method

.method private checkedColumnWidth(Landroid/content/Context;I)I
    .locals 1

    if-gtz p2, :cond_0

    const/4 p2, 0x1

    const/high16 v0, 0x42400000    # 48.0f

    .line 35
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p1

    .line 34
    invoke-static {p2, v0, p1}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result p1

    float-to-int p2, p1

    :cond_0
    return p2
.end method


# virtual methods
.method public onLayoutChildren(Landroidx/recyclerview/widget/RecyclerView$Recycler;Landroidx/recyclerview/widget/RecyclerView$State;)V
    .locals 4

    .line 52
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;->getWidth()I

    move-result v0

    .line 53
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;->getHeight()I

    move-result v1

    .line 54
    iget-boolean v2, p0, Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;->mColumnWidthChanged:Z

    if-eqz v2, :cond_1

    iget v2, p0, Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;->mColumnWidth:I

    if-lez v2, :cond_1

    if-lez v0, :cond_1

    if-lez v1, :cond_1

    .line 57
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;->getOrientation()I

    move-result v2

    const/4 v3, 0x1

    if-ne v2, v3, :cond_0

    .line 59
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;->getPaddingRight()I

    move-result v1

    sub-int/2addr v0, v1

    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;->getPaddingLeft()I

    move-result v1

    sub-int/2addr v0, v1

    goto :goto_0

    .line 63
    :cond_0
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;->getPaddingTop()I

    move-result v0

    sub-int/2addr v1, v0

    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;->getPaddingBottom()I

    move-result v0

    sub-int v0, v1, v0

    .line 65
    :goto_0
    iget v1, p0, Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;->mColumnWidth:I

    div-int/2addr v0, v1

    invoke-static {v3, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 66
    invoke-virtual {p0, v0}, Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;->setSpanCount(I)V

    const/4 v0, 0x0

    .line 67
    iput-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;->mColumnWidthChanged:Z

    .line 69
    :cond_1
    invoke-super {p0, p1, p2}, Landroidx/recyclerview/widget/GridLayoutManager;->onLayoutChildren(Landroidx/recyclerview/widget/RecyclerView$Recycler;Landroidx/recyclerview/widget/RecyclerView$State;)V

    return-void
.end method

.method public setColumnWidth(I)V
    .locals 1

    if-lez p1, :cond_0

    .line 42
    iget v0, p0, Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;->mColumnWidth:I

    if-eq p1, v0, :cond_0

    .line 44
    iput p1, p0, Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;->mColumnWidth:I

    const/4 p1, 0x1

    .line 45
    iput-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/utils/GridAutofitLayoutManager;->mColumnWidthChanged:Z

    :cond_0
    return-void
.end method
