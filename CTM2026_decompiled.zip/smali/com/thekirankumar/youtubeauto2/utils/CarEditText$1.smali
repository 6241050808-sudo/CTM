.class Lcom/thekirankumar/youtubeauto2/utils/CarEditText$1;
.super Ljava/lang/Object;
.source "CarEditText.java"

# interfaces
.implements Landroid/support/car/input/CarEditableListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/utils/CarEditText;->setCarEditableListener(Lcom/google/android/gms/car/input/CarEditableListener;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/utils/CarEditText;

.field final synthetic val$carEditableListener:Lcom/google/android/gms/car/input/CarEditableListener;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/utils/CarEditText;Lcom/google/android/gms/car/input/CarEditableListener;)V
    .locals 0

    .line 21
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/utils/CarEditText$1;->this$0:Lcom/thekirankumar/youtubeauto2/utils/CarEditText;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/utils/CarEditText$1;->val$carEditableListener:Lcom/google/android/gms/car/input/CarEditableListener;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onUpdateSelection(IIII)V
    .locals 1

    .line 24
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/CarEditText$1;->val$carEditableListener:Lcom/google/android/gms/car/input/CarEditableListener;

    invoke-interface {v0, p1, p2, p3, p4}, Lcom/google/android/gms/car/input/CarEditableListener;->onUpdateSelection(IIII)V

    return-void
.end method
