.class public Lcom/thekirankumar/youtubeauto2/utils/AdBlocker;
.super Ljava/lang/Object;
.source "AdBlocker.java"


# static fields
.field private static final AD_HOSTS:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final AD_HOSTS_FILE:Ljava/lang/String; = "hosts.txt"


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 25
    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    sput-object v0, Lcom/thekirankumar/youtubeauto2/utils/AdBlocker;->AD_HOSTS:Ljava/util/Set;

    return-void
.end method

.method public constructor <init>()V
    .locals 0

    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method static synthetic access$000(Landroid/content/Context;)Ljava/lang/Void;
    .locals 0
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 23
    invoke-static {p0}, Lcom/thekirankumar/youtubeauto2/utils/AdBlocker;->loadFromAssets(Landroid/content/Context;)Ljava/lang/Void;

    move-result-object p0

    return-object p0
.end method

.method public static createEmptyResource()Landroid/webkit/WebResourceResponse;
    .locals 4

    .line 53
    new-instance v0, Landroid/webkit/WebResourceResponse;

    new-instance v1, Ljava/io/ByteArrayInputStream;

    const-string v2, ""

    invoke-virtual {v2}, Ljava/lang/String;->getBytes()[B

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    const-string v2, "text/plain"

    const-string v3, "utf-8"

    invoke-direct {v0, v2, v3, v1}, Landroid/webkit/WebResourceResponse;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/io/InputStream;)V

    return-object v0
.end method

.method public static init(Landroid/content/Context;)V
    .locals 1

    .line 27
    new-instance v0, Lcom/thekirankumar/youtubeauto2/utils/AdBlocker$1;

    invoke-direct {v0, p0}, Lcom/thekirankumar/youtubeauto2/utils/AdBlocker$1;-><init>(Landroid/content/Context;)V

    const/4 p0, 0x0

    new-array p0, p0, [Ljava/lang/Void;

    .line 37
    invoke-virtual {v0, p0}, Lcom/thekirankumar/youtubeauto2/utils/AdBlocker$1;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    return-void
.end method

.method public static init(Landroid/content/Context;Lrx/Scheduler;)V
    .locals 1

    .line 40
    new-instance v0, Lcom/thekirankumar/youtubeauto2/utils/-$$Lambda$AdBlocker$wl-UL5W8oiMaKfpxMMGeueUrxRY;

    invoke-direct {v0, p0}, Lcom/thekirankumar/youtubeauto2/utils/-$$Lambda$AdBlocker$wl-UL5W8oiMaKfpxMMGeueUrxRY;-><init>(Landroid/content/Context;)V

    invoke-static {v0}, Lrx/Observable;->fromCallable(Ljava/util/concurrent/Callable;)Lrx/Observable;

    move-result-object p0

    sget-object v0, Lcom/thekirankumar/youtubeauto2/utils/-$$Lambda$AdBlocker$wZzTs5yBeF2SC9Q0iAyGPQCsl1Q;->INSTANCE:Lcom/thekirankumar/youtubeauto2/utils/-$$Lambda$AdBlocker$wZzTs5yBeF2SC9Q0iAyGPQCsl1Q;

    .line 41
    invoke-virtual {p0, v0}, Lrx/Observable;->onErrorReturn(Lrx/functions/Func1;)Lrx/Observable;

    move-result-object p0

    .line 42
    invoke-virtual {p0, p1}, Lrx/Observable;->subscribeOn(Lrx/Scheduler;)Lrx/Observable;

    move-result-object p0

    .line 43
    invoke-virtual {p0}, Lrx/Observable;->subscribe()Lrx/Subscription;

    return-void
.end method

.method public static isAd(Ljava/lang/String;)Z
    .locals 0

    .line 47
    invoke-static {p0}, Lokhttp3/HttpUrl;->parse(Ljava/lang/String;)Lokhttp3/HttpUrl;

    move-result-object p0

    if-eqz p0, :cond_0

    .line 48
    invoke-virtual {p0}, Lokhttp3/HttpUrl;->host()Ljava/lang/String;

    move-result-object p0

    goto :goto_0

    :cond_0
    const-string p0, ""

    :goto_0
    invoke-static {p0}, Lcom/thekirankumar/youtubeauto2/utils/AdBlocker;->isAdHost(Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method private static isAdHost(Ljava/lang/String;)Z
    .locals 4

    .line 74
    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    return v1

    :cond_0
    const-string v0, "."

    .line 77
    invoke-virtual {p0, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v0

    const/4 v2, 0x1

    if-ltz v0, :cond_2

    .line 78
    sget-object v3, Lcom/thekirankumar/youtubeauto2/utils/AdBlocker;->AD_HOSTS:Ljava/util/Set;

    invoke-interface {v3, p0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_1

    add-int/2addr v0, v2

    .line 79
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v3

    if-ge v0, v3, :cond_2

    invoke-virtual {p0, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lcom/thekirankumar/youtubeauto2/utils/AdBlocker;->isAdHost(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_2

    :cond_1
    const/4 v1, 0x1

    :cond_2
    return v1
.end method

.method static synthetic lambda$init$0(Landroid/content/Context;)Ljava/lang/Void;
    .locals 0
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    .line 40
    invoke-static {p0}, Lcom/thekirankumar/youtubeauto2/utils/AdBlocker;->loadFromAssets(Landroid/content/Context;)Ljava/lang/Void;

    move-result-object p0

    return-object p0
.end method

.method static synthetic lambda$init$1(Ljava/lang/Throwable;)Ljava/lang/Void;
    .locals 0

    const/4 p0, 0x0

    return-object p0
.end method

.method private static loadFromAssets(Landroid/content/Context;)Ljava/lang/Void;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .line 58
    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object p0

    const-string v0, "hosts.txt"

    invoke-virtual {p0, v0}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object p0

    .line 59
    invoke-static {p0}, Lokio/Okio;->source(Ljava/io/InputStream;)Lokio/Source;

    move-result-object v0

    invoke-static {v0}, Lokio/Okio;->buffer(Lokio/Source;)Lokio/BufferedSource;

    move-result-object v0

    .line 61
    :goto_0
    invoke-interface {v0}, Lokio/BufferedSource;->readUtf8Line()Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_0

    .line 62
    sget-object v2, Lcom/thekirankumar/youtubeauto2/utils/AdBlocker;->AD_HOSTS:Ljava/util/Set;

    invoke-interface {v2, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_0

    .line 64
    :cond_0
    invoke-interface {v0}, Lokio/BufferedSource;->close()V

    .line 65
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V

    const/4 p0, 0x0

    return-object p0
.end method
