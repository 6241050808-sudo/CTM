.class Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager$1;
.super Landroid/support/v4/media/session/MediaControllerCompat$Callback;
.source "MediaNotificationManager.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;)V
    .locals 0

    .line 80
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager$1;->this$0:Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;

    invoke-direct {p0}, Landroid/support/v4/media/session/MediaControllerCompat$Callback;-><init>()V

    return-void
.end method


# virtual methods
.method public onMetadataChanged(Landroid/support/v4/media/MediaMetadataCompat;)V
    .locals 3

    .line 98
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager$1;->this$0:Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;

    invoke-static {v0, p1}, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->access$402(Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;Landroid/support/v4/media/MediaMetadataCompat;)Landroid/support/v4/media/MediaMetadataCompat;

    .line 99
    invoke-static {}, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->access$100()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Received new metadata "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 100
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager$1;->this$0:Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->access$200(Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;)Landroid/app/Notification;

    move-result-object p1

    if-eqz p1, :cond_0

    .line 102
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager$1;->this$0:Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->access$300(Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;)Landroidx/core/app/NotificationManagerCompat;

    move-result-object v0

    const/16 v1, 0x19c

    invoke-virtual {v0, v1, p1}, Landroidx/core/app/NotificationManagerCompat;->notify(ILandroid/app/Notification;)V

    :cond_0
    return-void
.end method

.method public onPlaybackStateChanged(Landroid/support/v4/media/session/PlaybackStateCompat;)V
    .locals 3

    .line 83
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager$1;->this$0:Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;

    invoke-static {v0, p1}, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->access$002(Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;Landroid/support/v4/media/session/PlaybackStateCompat;)Landroid/support/v4/media/session/PlaybackStateCompat;

    .line 84
    invoke-static {}, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->access$100()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Received new playback state"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 85
    invoke-virtual {p1}, Landroid/support/v4/media/session/PlaybackStateCompat;->getState()I

    move-result v0

    const/4 v1, 0x1

    if-eq v0, v1, :cond_1

    .line 86
    invoke-virtual {p1}, Landroid/support/v4/media/session/PlaybackStateCompat;->getState()I

    move-result p1

    if-nez p1, :cond_0

    goto :goto_0

    .line 89
    :cond_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager$1;->this$0:Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->access$200(Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;)Landroid/app/Notification;

    move-result-object p1

    if-eqz p1, :cond_2

    .line 91
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager$1;->this$0:Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->access$300(Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;)Landroidx/core/app/NotificationManagerCompat;

    move-result-object v0

    const/16 v1, 0x19c

    invoke-virtual {v0, v1, p1}, Landroidx/core/app/NotificationManagerCompat;->notify(ILandroid/app/Notification;)V

    goto :goto_1

    .line 87
    :cond_1
    :goto_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager$1;->this$0:Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->stopNotification()V

    :cond_2
    :goto_1
    return-void
.end method

.method public onSessionDestroyed()V
    .locals 3

    .line 108
    invoke-super {p0}, Landroid/support/v4/media/session/MediaControllerCompat$Callback;->onSessionDestroyed()V

    .line 109
    invoke-static {}, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->access$100()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Session was destroyed, resetting to the new session token"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 111
    :try_start_0
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager$1;->this$0:Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->access$500(Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    :catch_0
    move-exception v0

    .line 113
    invoke-static {}, Lcom/thekirankumar/youtubeauto2/utils/MediaNotificationManager;->access$100()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, "could not connect media controller"

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :goto_0
    return-void
.end method
