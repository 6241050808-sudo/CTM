.class public Lcom/thekirankumar/youtubeauto2/utils/WebviewUtils;
.super Ljava/lang/Object;
.source "WebviewUtils.java"


# static fields
.field private static final FILE_BROWSER_CSS_PATH:Ljava/lang/String; = "file:///android_asset/filebrowser.css"

.field private static final FILE_BROWSER_SCRIPT_PATH:Ljava/lang/String; = "file:///android_asset/filebrowser.js"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static injectCustomSelectDropDown(Landroid/webkit/WebView;)V
    .locals 2

    const-string v0, "DropDown"

    const-string v1, "Yep"

    .line 36
    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const-string v0, "javascript:for(i=0;i<document.getElementsByTagName(\'select\').length;i++){document.getElementsByTagName(\'select\')[i].onclick=function(){if(this.selectedIndex < this.options.length-1) {this.selectedIndex++} else {this.selectedIndex=0}this.dispatchEvent(new Event(\'change\', { bubbles: true }));};}"

    .line 46
    invoke-virtual {p0, v0}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method

.method public static injectFileListingHack(Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;)V
    .locals 2

    .line 93
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->getUrl()Ljava/lang/String;

    move-result-object v0

    const-string v1, "FileListing"

    .line 94
    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    if-eqz v0, :cond_0

    const-string v1, "file:///"

    .line 95
    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    const-string v1, "/"

    invoke-virtual {v0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_0

    const-string v0, "javascript:var oldHead = document.head.innerHTML;    var head  = document.body;\n    var link  = document.createElement(\'link\');\n    link.rel  = \'stylesheet\';\n    link.type = \'text/css\';\n    link.href = \'file:///android_asset/filebrowser.css\';\n    link.media = \'all\';\n    head.appendChild(link);\nvar script = document.createElement(\'script\');script.src = \'file:///android_asset/filebrowser.js\';head.appendChild(script);document.body.innerHTML+= \'<h3 id=\"header\">LOCATION</h1><div id=\"parentDirLinkBox\" style=\"display:none\"><a id=\"parentDirLink\" class=\"icon up\"><span id=\"parentDirText\">[parent directory]</span></a> </div> <table> <thead> <tr class=\"header\" id=\"theader\"><th onclick=\"javascript:sortTable(0);\">Name</th><th class=\"detailsColumn\" onclick=\"javascript:sortTable(1);\">Size </th> <th class=\"detailsColumn\" onclick=\"javascript:sortTable(2);\">Date Modified </th> </tr> </thead> <tbody id=\"tbody\"> </tbody> </table>\';document.body.innerHTML+= oldHead;"

    .line 110
    invoke-virtual {p0, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->loadUrl(Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method public static injectNightModeCss(Landroid/webkit/WebView;)V
    .locals 2

    .line 70
    invoke-virtual {p0}, Landroid/webkit/WebView;->getUrl()Ljava/lang/String;

    move-result-object v0

    const-string v1, "NightModeInjected"

    .line 71
    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    if-eqz v0, :cond_0

    const-string v0, "javascript:var css = \'html {background-color: #000 !important;}\ndiv.page-container{ color: #fff !important;}\ndiv.mobile-topbar-header-content{ color: hsla(0, 0%, 100%, 0.6) !important;}\nytm-mobile-topbar-renderer.sticky-player {background-color: #000 !important;}\nc3-icon.mobile-topbar-logo{ color: #fff !important;}\nytm-pivot-bar-renderer{ background-color: #000 !important; color: #fff !important;}\ndiv.slim-video-metadata-actions{color:hsla(0, 33.3%, 97.1%, 0.6);}\nytm-app.sticky-player {padding-top: 10px !important;}\n.player-container.sticky-player {top: 0px !important;}\';\nvar head  = document.getElementsByTagName(\'head\')[0];\nvar style  = document.createElement(\'style\');\nstyle.type = \'text/css\';\ndocument.getElementsByTagName(\"ytm-mobile-topbar-renderer\")[0].style.display = \'none\';\nstyle.appendChild(document.createTextNode(css));\nhead.appendChild(style);"

    .line 88
    invoke-virtual {p0, v0}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method public static injectQualityControl(Landroid/webkit/WebView;)V
    .locals 2

    .line 50
    invoke-virtual {p0}, Landroid/webkit/WebView;->getUrl()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_0

    const-string v1, "InjectedQualityControl"

    .line 52
    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 66
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "javascript:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "var bool_url;\nfunction s(){\nlet m = document.getElementsByTagName(\'ytm-menu\')[0];\ndocument.getElementsByClassName(\'slim-video-metadata-actions\')[0].appendChild(m);}\nfunction b(){let url = window.location.href;\nif (url.includes(\'watch\') && !bool_url){ bool_url=1; s(); } else bool_url=0;}\nsetInterval(function(){ b(); }, 500);\n"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method public static setDesktopMode(Landroid/webkit/WebView;Z)V
    .locals 5

    .line 18
    invoke-virtual {p0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object p0

    const-string v0, "Android"

    const-string v1, "diordnA"

    const-string v2, "Mobile"

    const-string v3, "eliboM"

    if-eqz p1, :cond_0

    .line 22
    invoke-virtual {p0}, Landroid/webkit/WebSettings;->getUserAgentString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v2, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    goto :goto_0

    .line 25
    :cond_0
    invoke-virtual {p0}, Landroid/webkit/WebSettings;->getUserAgentString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v3, v2}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2, v1, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    .line 28
    :goto_0
    invoke-virtual {p0, v0}, Landroid/webkit/WebSettings;->setUserAgentString(Ljava/lang/String;)V

    .line 29
    invoke-virtual {p0, p1}, Landroid/webkit/WebSettings;->setUseWideViewPort(Z)V

    .line 30
    invoke-virtual {p0, p1}, Landroid/webkit/WebSettings;->setLoadWithOverviewMode(Z)V

    .line 31
    invoke-virtual {p0, p1}, Landroid/webkit/WebSettings;->setSupportZoom(Z)V

    .line 32
    invoke-virtual {p0, p1}, Landroid/webkit/WebSettings;->setBuiltInZoomControls(Z)V

    return-void
.end method
