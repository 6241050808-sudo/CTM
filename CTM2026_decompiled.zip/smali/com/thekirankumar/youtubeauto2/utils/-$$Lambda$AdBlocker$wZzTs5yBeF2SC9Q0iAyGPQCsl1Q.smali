.class public final synthetic Lcom/thekirankumar/youtubeauto2/utils/-$$Lambda$AdBlocker$wZzTs5yBeF2SC9Q0iAyGPQCsl1Q;
.super Ljava/lang/Object;
.source "lambda"

# interfaces
.implements Lrx/functions/Func1;


# static fields
.field public static final synthetic INSTANCE:Lcom/thekirankumar/youtubeauto2/utils/-$$Lambda$AdBlocker$wZzTs5yBeF2SC9Q0iAyGPQCsl1Q;


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 1

    new-instance v0, Lcom/thekirankumar/youtubeauto2/utils/-$$Lambda$AdBlocker$wZzTs5yBeF2SC9Q0iAyGPQCsl1Q;

    invoke-direct {v0}, Lcom/thekirankumar/youtubeauto2/utils/-$$Lambda$AdBlocker$wZzTs5yBeF2SC9Q0iAyGPQCsl1Q;-><init>()V

    sput-object v0, Lcom/thekirankumar/youtubeauto2/utils/-$$Lambda$AdBlocker$wZzTs5yBeF2SC9Q0iAyGPQCsl1Q;->INSTANCE:Lcom/thekirankumar/youtubeauto2/utils/-$$Lambda$AdBlocker$wZzTs5yBeF2SC9Q0iAyGPQCsl1Q;

    return-void
.end method

.method private synthetic constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final call(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, Ljava/lang/Throwable;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/utils/AdBlocker;->lambda$init$1(Ljava/lang/Throwable;)Ljava/lang/Void;

    move-result-object p1

    return-object p1
.end method
