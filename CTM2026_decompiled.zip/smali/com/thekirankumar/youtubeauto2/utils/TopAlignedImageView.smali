.class public Lcom/thekirankumar/youtubeauto2/utils/TopAlignedImageView;
.super Landroid/widget/ImageView;
.source "TopAlignedImageView.java"


# instance fields
.field private mHasFrame:Z

.field private mMatrix:Landroid/graphics/Matrix;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x0

    .line 16
    invoke-direct {p0, p1, v0, v1}, Lcom/thekirankumar/youtubeauto2/utils/TopAlignedImageView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 1

    const/4 v0, 0x0

    .line 21
    invoke-direct {p0, p1, p2, v0}, Lcom/thekirankumar/youtubeauto2/utils/TopAlignedImageView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 0

    .line 26
    invoke-direct {p0, p1, p2, p3}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 p1, 0x0

    .line 27
    iput-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/utils/TopAlignedImageView;->mHasFrame:Z

    .line 28
    new-instance p1, Landroid/graphics/Matrix;

    invoke-direct {p1}, Landroid/graphics/Matrix;-><init>()V

    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/utils/TopAlignedImageView;->mMatrix:Landroid/graphics/Matrix;

    return-void
.end method

.method private setupScaleMatrix(II)V
    .locals 4

    .line 47
    iget-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/utils/TopAlignedImageView;->mHasFrame:Z

    if-nez v0, :cond_0

    return-void

    .line 52
    :cond_0
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/utils/TopAlignedImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    if-nez v0, :cond_1

    return-void

    .line 59
    :cond_1
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/utils/TopAlignedImageView;->mMatrix:Landroid/graphics/Matrix;

    .line 60
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v2

    .line 61
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v0

    int-to-float p1, p1

    int-to-float v3, v2

    div-float v3, p1, v3

    int-to-float p2, p2

    int-to-float v0, v0

    div-float/2addr p2, v0

    .line 65
    invoke-static {p2, v3}, Ljava/lang/Math;->max(FF)F

    move-result p2

    neg-int v0, v2

    int-to-float v0, v0

    const/high16 v2, 0x40000000    # 2.0f

    div-float/2addr v0, v2

    const/4 v3, 0x0

    .line 69
    invoke-virtual {v1, v0, v3}, Landroid/graphics/Matrix;->setTranslate(FF)V

    .line 70
    invoke-virtual {v1, p2, p2, v3, v3}, Landroid/graphics/Matrix;->postScale(FFFF)Z

    div-float/2addr p1, v2

    .line 71
    invoke-virtual {v1, p1, v3}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    .line 72
    invoke-virtual {p0, v1}, Lcom/thekirankumar/youtubeauto2/utils/TopAlignedImageView;->setImageMatrix(Landroid/graphics/Matrix;)V

    return-void
.end method


# virtual methods
.method protected setFrame(IIII)Z
    .locals 2

    .line 37
    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/ImageView;->setFrame(IIII)Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v1, 0x1

    .line 39
    iput-boolean v1, p0, Lcom/thekirankumar/youtubeauto2/utils/TopAlignedImageView;->mHasFrame:Z

    sub-int/2addr p3, p1

    sub-int/2addr p4, p2

    .line 41
    invoke-direct {p0, p3, p4}, Lcom/thekirankumar/youtubeauto2/utils/TopAlignedImageView;->setupScaleMatrix(II)V

    :cond_0
    return v0
.end method

.method public setImageDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 1

    .line 77
    invoke-super {p0, p1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 79
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/utils/TopAlignedImageView;->getWidth()I

    move-result p1

    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/utils/TopAlignedImageView;->getHeight()I

    move-result v0

    invoke-direct {p0, p1, v0}, Lcom/thekirankumar/youtubeauto2/utils/TopAlignedImageView;->setupScaleMatrix(II)V

    return-void
.end method

.method public setImageResource(I)V
    .locals 1

    .line 84
    invoke-super {p0, p1}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 86
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/utils/TopAlignedImageView;->getWidth()I

    move-result p1

    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/utils/TopAlignedImageView;->getHeight()I

    move-result v0

    invoke-direct {p0, p1, v0}, Lcom/thekirankumar/youtubeauto2/utils/TopAlignedImageView;->setupScaleMatrix(II)V

    return-void
.end method

.method public setImageURI(Landroid/net/Uri;)V
    .locals 1

    .line 91
    invoke-super {p0, p1}, Landroid/widget/ImageView;->setImageURI(Landroid/net/Uri;)V

    .line 93
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/utils/TopAlignedImageView;->getWidth()I

    move-result p1

    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/utils/TopAlignedImageView;->getHeight()I

    move-result v0

    invoke-direct {p0, p1, v0}, Lcom/thekirankumar/youtubeauto2/utils/TopAlignedImageView;->setupScaleMatrix(II)V

    return-void
.end method
