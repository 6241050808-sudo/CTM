.class public final Lcom/thekirankumar/youtubeauto2/R$animator;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thekirankumar/youtubeauto2/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "animator"
.end annotation


# static fields
.field public static final design_appbar_state_list_animator:I = 0x7f020000

.field public static final design_fab_hide_motion_spec:I = 0x7f020001

.field public static final design_fab_show_motion_spec:I = 0x7f020002

.field public static final mtrl_btn_state_list_anim:I = 0x7f020003

.field public static final mtrl_btn_unelevated_state_list_anim:I = 0x7f020004

.field public static final mtrl_card_state_list_anim:I = 0x7f020005

.field public static final mtrl_chip_state_list_anim:I = 0x7f020006

.field public static final mtrl_extended_fab_change_size_motion_spec:I = 0x7f020007

.field public static final mtrl_extended_fab_hide_motion_spec:I = 0x7f020008

.field public static final mtrl_extended_fab_show_motion_spec:I = 0x7f020009

.field public static final mtrl_extended_fab_state_list_animator:I = 0x7f02000a

.field public static final mtrl_fab_hide_motion_spec:I = 0x7f02000b

.field public static final mtrl_fab_show_motion_spec:I = 0x7f02000c

.field public static final mtrl_fab_transformation_sheet_collapse_spec:I = 0x7f02000d

.field public static final mtrl_fab_transformation_sheet_expand_spec:I = 0x7f02000e


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
