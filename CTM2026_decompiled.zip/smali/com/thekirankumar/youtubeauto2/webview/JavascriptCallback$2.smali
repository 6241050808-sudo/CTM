.class Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$2;
.super Ljava/lang/Object;
.source "JavascriptCallback.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;->onVideoCurrentTimeResult(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;

.field final synthetic val$currentTime:I


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;I)V
    .locals 0

    .line 33
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$2;->this$0:Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;

    iput p2, p0, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$2;->val$currentTime:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 36
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$2;->this$0:Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;->access$000(Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;)Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$JSCallbacks;

    move-result-object v0

    iget v1, p0, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$2;->val$currentTime:I

    invoke-interface {v0, v1}, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$JSCallbacks;->onVideoCurrentTimeResult(I)V

    return-void
.end method
