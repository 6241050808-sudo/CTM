.class Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView$JavascriptInterface$1;
.super Ljava/lang/Object;
.source "VideoEnabledWebView.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView$JavascriptInterface;->notifyVideoEnd()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView$JavascriptInterface;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView$JavascriptInterface;)V
    .locals 0

    .line 127
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView$JavascriptInterface$1;->this$1:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView$JavascriptInterface;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .line 130
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView$JavascriptInterface$1;->this$1:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView$JavascriptInterface;

    iget-object v0, v0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView$JavascriptInterface;->this$0:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->access$000(Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;)Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 131
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView$JavascriptInterface$1;->this$1:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView$JavascriptInterface;

    iget-object v0, v0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView$JavascriptInterface;->this$0:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->access$000(Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;)Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;

    move-result-object v0

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->onHideCustomView()V

    :cond_0
    return-void
.end method
