.class Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$4;
.super Ljava/lang/Object;
.source "JavascriptCallback.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;->showKeyboard(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;

.field final synthetic val$oldText:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;Ljava/lang/String;)V
    .locals 0

    .line 53
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$4;->this$0:Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;

    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$4;->val$oldText:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 56
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$4;->this$0:Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;->access$000(Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;)Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$JSCallbacks;

    move-result-object v0

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$4;->val$oldText:Ljava/lang/String;

    invoke-interface {v0, v1}, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$JSCallbacks;->onShowKeyboardFromJS(Ljava/lang/String;)V

    return-void
.end method
