.class public interface abstract Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$JSCallbacks;
.super Ljava/lang/Object;
.source "JavascriptCallback.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "JSCallbacks"
.end annotation


# virtual methods
.method public abstract onHideKeyboardFromJS()V
.end method

.method public abstract onJSVideoEvent(Ljava/lang/String;)V
.end method

.method public abstract onShowKeyboardFromJS(Ljava/lang/String;)V
.end method

.method public abstract onVideoCurrentTimeResult(I)V
.end method

.method public abstract onVideoElementDiscovered()V
.end method
