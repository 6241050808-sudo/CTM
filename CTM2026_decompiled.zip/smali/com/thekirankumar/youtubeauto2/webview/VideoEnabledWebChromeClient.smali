.class public Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;
.super Landroid/webkit/WebChromeClient;
.source "VideoEnabledWebChromeClient.java"

# interfaces
.implements Landroid/media/MediaPlayer$OnPreparedListener;
.implements Landroid/media/MediaPlayer$OnCompletionListener;
.implements Landroid/media/MediaPlayer$OnErrorListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient$ToggledFullscreenCallback;
    }
.end annotation


# instance fields
.field private activityNonVideoView:Landroid/view/View;

.field private activityVideoView:Landroid/view/ViewGroup;

.field private isVideoFullscreen:Z

.field private loadingView:Landroid/view/View;

.field private toggledFullscreenCallback:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient$ToggledFullscreenCallback;

.field private videoStretchingEnabled:Z

.field private videoTouchListener:Landroid/view/View$OnTouchListener;

.field private videoViewCallback:Landroid/webkit/WebChromeClient$CustomViewCallback;

.field private videoViewContainer:Landroid/widget/FrameLayout;

.field private webView:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 49
    invoke-direct {p0}, Landroid/webkit/WebChromeClient;-><init>()V

    return-void
.end method

.method public constructor <init>(Landroid/view/View;Landroid/view/ViewGroup;)V
    .locals 0

    .line 58
    invoke-direct {p0}, Landroid/webkit/WebChromeClient;-><init>()V

    .line 59
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->activityNonVideoView:Landroid/view/View;

    .line 60
    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->activityVideoView:Landroid/view/ViewGroup;

    const/4 p1, 0x0

    .line 61
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->loadingView:Landroid/view/View;

    .line 62
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;

    const/4 p1, 0x0

    .line 63
    iput-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->isVideoFullscreen:Z

    return-void
.end method

.method public constructor <init>(Landroid/view/View;Landroid/view/ViewGroup;Landroid/view/View;)V
    .locals 0

    .line 73
    invoke-direct {p0}, Landroid/webkit/WebChromeClient;-><init>()V

    .line 74
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->activityNonVideoView:Landroid/view/View;

    .line 75
    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->activityVideoView:Landroid/view/ViewGroup;

    .line 76
    iput-object p3, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->loadingView:Landroid/view/View;

    const/4 p1, 0x0

    .line 77
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;

    const/4 p1, 0x0

    .line 78
    iput-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->isVideoFullscreen:Z

    return-void
.end method

.method public constructor <init>(Landroid/view/View;Landroid/view/ViewGroup;Landroid/view/View;Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;)V
    .locals 0

    .line 90
    invoke-direct {p0}, Landroid/webkit/WebChromeClient;-><init>()V

    .line 91
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->activityNonVideoView:Landroid/view/View;

    .line 92
    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->activityVideoView:Landroid/view/ViewGroup;

    .line 93
    iput-object p3, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->loadingView:Landroid/view/View;

    .line 94
    iput-object p4, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;

    const/4 p1, 0x0

    .line 95
    iput-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->isVideoFullscreen:Z

    return-void
.end method

.method static synthetic access$000(Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;)Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;
    .locals 0

    .line 33
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;

    return-object p0
.end method

.method private handleVideoStretching()V
    .locals 2

    .line 198
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "javascript:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "_ytrp_html5_video = document.getElementsByTagName(\'video\')[0];"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 199
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "if (_ytrp_html5_video !== undefined) {var originalWidth = _ytrp_html5_video.style.width; var originalHeight = _ytrp_html5_video.style.height; var originalTop = _ytrp_html5_video.style.top;"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 205
    iget-boolean v1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->videoStretchingEnabled:Z

    if-eqz v1, :cond_0

    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->isVideoFullscreen()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 206
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "_ytrp_html5_video.style.objectFit=\'fill\'; _ytrp_html5_video.style.height=window.innerHeight+\'px\';_ytrp_html5_video.style.width=window.innerWidth+\'px\';_ytrp_html5_video.style.top=0;"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 214
    :cond_0
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "}"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 215
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;

    invoke-virtual {v1, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public getVideoLoadingProgressView()Landroid/view/View;
    .locals 2

    .line 266
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->loadingView:Landroid/view/View;

    if-eqz v0, :cond_0

    const/4 v1, 0x0

    .line 267
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 268
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->loadingView:Landroid/view/View;

    return-object v0

    .line 270
    :cond_0
    invoke-super {p0}, Landroid/webkit/WebChromeClient;->getVideoLoadingProgressView()Landroid/view/View;

    move-result-object v0

    return-object v0
.end method

.method public getVideoTouchListener()Landroid/view/View$OnTouchListener;
    .locals 1

    .line 104
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->videoTouchListener:Landroid/view/View$OnTouchListener;

    return-object v0
.end method

.method public isVideoFullscreen()Z
    .locals 1

    .line 117
    iget-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->isVideoFullscreen:Z

    return v0
.end method

.method public onBackPressed()Z
    .locals 1

    .line 301
    iget-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->isVideoFullscreen:Z

    if-eqz v0, :cond_0

    .line 302
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->onHideCustomView()V

    const/4 v0, 0x1

    return v0

    :cond_0
    const/4 v0, 0x0

    return v0
.end method

.method public onCompletion(Landroid/media/MediaPlayer;)V
    .locals 0

    .line 285
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->onHideCustomView()V

    return-void
.end method

.method public onError(Landroid/media/MediaPlayer;II)Z
    .locals 0

    const/4 p1, 0x0

    return p1
.end method

.method public onGeolocationPermissionsShowPrompt(Ljava/lang/String;Landroid/webkit/GeolocationPermissions$Callback;)V
    .locals 1

    .line 318
    invoke-super {p0, p1, p2}, Landroid/webkit/WebChromeClient;->onGeolocationPermissionsShowPrompt(Ljava/lang/String;Landroid/webkit/GeolocationPermissions$Callback;)V

    const/4 v0, 0x1

    .line 319
    invoke-interface {p2, p1, v0, v0}, Landroid/webkit/GeolocationPermissions$Callback;->invoke(Ljava/lang/String;ZZ)V

    return-void
.end method

.method public onHideCustomView()V
    .locals 2

    .line 230
    iget-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->isVideoFullscreen:Z

    if-eqz v0, :cond_2

    .line 231
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    invoke-virtual {v0}, Landroid/webkit/WebSettings;->getJavaScriptEnabled()Z

    move-result v0

    if-eqz v0, :cond_0

    .line 234
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "javascript:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "_ytrp_html5_video = document.getElementsByTagName(\'video\')[0];"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .line 241
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;

    invoke-virtual {v1, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->loadUrl(Ljava/lang/String;)V

    .line 244
    :cond_0
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->activityVideoView:Landroid/view/ViewGroup;

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->setVisibility(I)V

    .line 245
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->activityVideoView:Landroid/view/ViewGroup;

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->videoViewContainer:Landroid/widget/FrameLayout;

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 246
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->activityNonVideoView:Landroid/view/View;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 249
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->videoViewCallback:Landroid/webkit/WebChromeClient$CustomViewCallback;

    if-eqz v0, :cond_1

    invoke-interface {v0}, Landroid/webkit/WebChromeClient$CustomViewCallback;->onCustomViewHidden()V

    .line 252
    :cond_1
    iput-boolean v1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->isVideoFullscreen:Z

    const/4 v0, 0x0

    .line 253
    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->videoViewContainer:Landroid/widget/FrameLayout;

    .line 254
    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->videoViewCallback:Landroid/webkit/WebChromeClient$CustomViewCallback;

    .line 257
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->toggledFullscreenCallback:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient$ToggledFullscreenCallback;

    if-eqz v0, :cond_2

    .line 258
    invoke-interface {v0, v1}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient$ToggledFullscreenCallback;->toggledFullscreen(Z)V

    :cond_2
    return-void
.end method

.method public onPermissionRequest(Landroid/webkit/PermissionRequest;)V
    .locals 2

    .line 311
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x15

    if-lt v0, v1, :cond_0

    .line 312
    invoke-virtual {p1}, Landroid/webkit/PermissionRequest;->getResources()[Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/webkit/PermissionRequest;->grant([Ljava/lang/String;)V

    :cond_0
    return-void
.end method

.method public onPrepared(Landroid/media/MediaPlayer;)V
    .locals 1

    .line 277
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->loadingView:Landroid/view/View;

    if-eqz p1, :cond_0

    const/16 v0, 0x8

    .line 278
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    :cond_0
    return-void
.end method

.method public onShowCustomView(Landroid/view/View;ILandroid/webkit/WebChromeClient$CustomViewCallback;)V
    .locals 0

    .line 221
    invoke-virtual {p0, p1, p3}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->onShowCustomView(Landroid/view/View;Landroid/webkit/WebChromeClient$CustomViewCallback;)V

    return-void
.end method

.method public onShowCustomView(Landroid/view/View;Landroid/webkit/WebChromeClient$CustomViewCallback;)V
    .locals 4

    .line 132
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "onShowCustomView() called with: view = ["

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, "], callback = ["

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, "]"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 133
    instance-of v0, p1, Landroid/widget/FrameLayout;

    if-eqz v0, :cond_4

    .line 136
    check-cast p1, Landroid/widget/FrameLayout;

    .line 137
    invoke-virtual {p1}, Landroid/widget/FrameLayout;->getFocusedChild()Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 139
    invoke-virtual {v0}, Landroid/view/View;->requestFocus()Z

    .line 140
    new-instance v1, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient$1;

    invoke-direct {v1, p0}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient$1;-><init>(Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    :cond_0
    const/4 v1, 0x1

    .line 155
    iput-boolean v1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->isVideoFullscreen:Z

    .line 156
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->videoViewContainer:Landroid/widget/FrameLayout;

    .line 157
    iput-object p2, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->videoViewCallback:Landroid/webkit/WebChromeClient$CustomViewCallback;

    .line 160
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->activityNonVideoView:Landroid/view/View;

    const/4 p2, 0x4

    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    .line 161
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->activityVideoView:Landroid/view/ViewGroup;

    iget-object p2, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->videoViewContainer:Landroid/widget/FrameLayout;

    new-instance v2, Landroid/view/ViewGroup$LayoutParams;

    const/4 v3, -0x1

    invoke-direct {v2, v3, v3}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {p1, p2, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 162
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->activityVideoView:Landroid/view/ViewGroup;

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Landroid/view/ViewGroup;->setVisibility(I)V

    .line 163
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->activityVideoView:Landroid/view/ViewGroup;

    const/high16 p2, -0x1000000

    invoke-virtual {p1, p2}, Landroid/view/ViewGroup;->setBackgroundColor(I)V

    if-eqz v0, :cond_1

    .line 165
    invoke-virtual {v0, p2}, Landroid/view/View;->setBackgroundColor(I)V

    .line 166
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->videoTouchListener:Landroid/view/View$OnTouchListener;

    if-eqz p1, :cond_1

    .line 167
    invoke-virtual {v0, p1}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 172
    :cond_1
    instance-of p1, v0, Landroid/widget/VideoView;

    if-eqz p1, :cond_2

    .line 174
    check-cast v0, Landroid/widget/VideoView;

    .line 176
    invoke-virtual {v0, p0}, Landroid/widget/VideoView;->setOnPreparedListener(Landroid/media/MediaPlayer$OnPreparedListener;)V

    .line 177
    invoke-virtual {v0, p0}, Landroid/widget/VideoView;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    .line 178
    invoke-virtual {v0, p0}, Landroid/widget/VideoView;->setOnErrorListener(Landroid/media/MediaPlayer$OnErrorListener;)V

    goto :goto_0

    .line 183
    :cond_2
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->webView:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;

    if-eqz p1, :cond_3

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object p1

    invoke-virtual {p1}, Landroid/webkit/WebSettings;->getJavaScriptEnabled()Z

    move-result p1

    if-eqz p1, :cond_3

    .line 185
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->handleVideoStretching()V

    .line 190
    :cond_3
    :goto_0
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->toggledFullscreenCallback:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient$ToggledFullscreenCallback;

    if-eqz p1, :cond_4

    .line 191
    invoke-interface {p1, v1}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient$ToggledFullscreenCallback;->toggledFullscreen(Z)V

    :cond_4
    return-void
.end method

.method public setOnToggledFullscreen(Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient$ToggledFullscreenCallback;)V
    .locals 0

    .line 126
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->toggledFullscreenCallback:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient$ToggledFullscreenCallback;

    return-void
.end method

.method public setVideoStretchingEnabled(Z)V
    .locals 0

    .line 99
    iput-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->videoStretchingEnabled:Z

    .line 100
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->handleVideoStretching()V

    return-void
.end method

.method public setVideoTouchListener(Landroid/view/View$OnTouchListener;)V
    .locals 0

    .line 108
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->videoTouchListener:Landroid/view/View$OnTouchListener;

    return-void
.end method
