.class public Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;
.super Ljava/lang/Object;
.source "JavascriptCallback.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$JSCallbacks;
    }
.end annotation


# instance fields
.field private callbacks:Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$JSCallbacks;

.field private final handler:Landroid/os/Handler;


# direct methods
.method public constructor <init>(Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$JSCallbacks;)V
    .locals 1

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 17
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;->handler:Landroid/os/Handler;

    .line 18
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;->callbacks:Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$JSCallbacks;

    return-void
.end method

.method static synthetic access$000(Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;)Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$JSCallbacks;
    .locals 0

    .line 11
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;->callbacks:Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$JSCallbacks;

    return-object p0
.end method


# virtual methods
.method public hideKeyboard()V
    .locals 2
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 63
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;->handler:Landroid/os/Handler;

    new-instance v1, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$5;

    invoke-direct {v1, p0}, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$5;-><init>(Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public onVideoCurrentTimeResult(I)V
    .locals 2
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 33
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;->handler:Landroid/os/Handler;

    new-instance v1, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$2;

    invoke-direct {v1, p0, p1}, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$2;-><init>(Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;I)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public onVideoDiscovered()V
    .locals 2
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 43
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;->handler:Landroid/os/Handler;

    new-instance v1, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$3;

    invoke-direct {v1, p0}, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$3;-><init>(Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public onVideoEvent(Ljava/lang/String;)V
    .locals 2
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 23
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;->handler:Landroid/os/Handler;

    new-instance v1, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$1;

    invoke-direct {v1, p0, p1}, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$1;-><init>(Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public showKeyboard(Ljava/lang/String;)V
    .locals 2
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 53
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;->handler:Landroid/os/Handler;

    new-instance v1, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$4;

    invoke-direct {v1, p0, p1}, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$4;-><init>(Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method
