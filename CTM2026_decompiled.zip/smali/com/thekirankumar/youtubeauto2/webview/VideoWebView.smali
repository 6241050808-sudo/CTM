.class public Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;
.super Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;
.source "VideoWebView.java"


# instance fields
.field private TOUCH_TOLERANCE:F

.field private lastDownX:F

.field private lastDownY:F


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    .line 18
    invoke-direct {p0, p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;-><init>(Landroid/content/Context;)V

    const/high16 p1, 0x41a00000    # 20.0f

    .line 15
    iput p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->TOUCH_TOLERANCE:F

    .line 19
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->init()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 0

    .line 23
    invoke-direct {p0, p1, p2}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/high16 p1, 0x41a00000    # 20.0f

    .line 15
    iput p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->TOUCH_TOLERANCE:F

    .line 24
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->init()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 0

    .line 28
    invoke-direct {p0, p1, p2, p3}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/high16 p1, 0x41a00000    # 20.0f

    .line 15
    iput p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->TOUCH_TOLERANCE:F

    .line 29
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->init()V

    return-void
.end method

.method private init()V
    .locals 0

    return-void
.end method


# virtual methods
.method public attachVideoListeners()V
    .locals 1

    const-string v0, "javascript: var el = document.querySelector(\'video\'); el.addEventListener(\'playing\', function(e){window.nativecallbacks.onVideoEvent(\'playing\');});el.addEventListener(\'pause\', function(e){window.nativecallbacks.onVideoEvent(\'pause\');});el.addEventListener(\'progress\', function(e){window.nativecallbacks.onVideoEvent(\'progress\');});el.addEventListener(\'waiting\', function(e){window.nativecallbacks.onVideoEvent(\'waiting\');});"

    .line 132
    invoke-virtual {p0, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method

.method public discoverVideoElements()V
    .locals 1

    const-string v0, "javascript: function waitForElementToDisplay(selector, time, fn) {\nvar el = document.querySelector(selector);if(el!=null) {            fn(el);            return;        }        else {            setTimeout(function() {                waitForElementToDisplay(selector, time, fn);            }, time);\n        }    }waitForElementToDisplay(\'video\', 1000, function(el) {window.nativecallbacks.onVideoDiscovered();})"

    .line 89
    invoke-virtual {p0, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method

.method public dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 2

    .line 37
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    move-result v0

    const/16 v1, 0x17

    if-ne v0, v1, :cond_0

    .line 38
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->showKeyboardIfInput()V

    .line 40
    :cond_0
    invoke-super {p0, p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    move-result p1

    return p1
.end method

.method public enterEditText(Ljava/lang/String;)V
    .locals 2

    .line 188
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "var changeEvent = new Event(\'change\'); if(document.activeElement.isContentEditable){document.activeElement.innerText = \""

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "\";}else {document.activeElement.value = \""

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "\";} document.activeElement.dispatchEvent(changeEvent);"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 199
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "javascript:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method

.method public findAndClickFirstVideo()V
    .locals 1

    const-string v0, "javascript: var el = document.querySelector(\"a[href^=\'/watch\'\"); el.click();"

    .line 139
    invoke-virtual {p0, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method

.method public getCurrentVideoTimeResult()V
    .locals 1

    const-string v0, "javascript:var v = document.querySelector(\"video\"); window.nativecallbacks.onVideoCurrentTimeResult(v.currentTime);"

    .line 184
    invoke-virtual {p0, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 2

    .line 45
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    if-nez v0, :cond_0

    .line 46
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    iput v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->lastDownX:F

    .line 47
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v0

    iput v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->lastDownY:F

    .line 49
    :cond_0
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_1

    .line 50
    iget v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->lastDownX:F

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    sub-float/2addr v0, v1

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    iget v1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->TOUCH_TOLERANCE:F

    cmpg-float v0, v0, v1

    if-gez v0, :cond_1

    iget v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->lastDownY:F

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    sub-float/2addr v0, v1

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    iget v1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->TOUCH_TOLERANCE:F

    cmpg-float v0, v0, v1

    if-gez v0, :cond_1

    .line 51
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->showKeyboardIfInput()V

    .line 53
    :cond_1
    invoke-super {p0, p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    return p1
.end method

.method public pauseVideo()V
    .locals 1

    const-string v0, "javascript:var v = document.querySelector(\"video\"); v.pause();"

    .line 62
    invoke-virtual {p0, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method

.method public pauseVideoAndSetFlag()V
    .locals 1

    const-string v0, "javascript: var el = document.getElementsByTagName(\'video\')[0];\nif(!el.paused) {el.pause();window.pausedDueToMinimize = true;}"

    .line 117
    invoke-virtual {p0, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method

.method public playNextTrack()V
    .locals 1

    const-string v0, "javascript:var v = document.querySelector(\"video\"); v.currentTime = v.getDuration();\nvar next = document.querySelectorAll(\'a[aria-label=\"Play next video\"]\'); next[0].click();\n"

    .line 57
    invoke-virtual {p0, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method

.method public playVideo()V
    .locals 1

    const-string v0, "javascript:var v = document.querySelector(\"video\"); v.play();"

    .line 66
    invoke-virtual {p0, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method

.method public playVideoIfPausedFlag()V
    .locals 1

    const-string v0, "javascript: if(window.pausedDueToMinimize) {var el = document.getElementsByTagName(\'video\')[0];    el.play();window.pausedDueToMinimize = false;}"

    .line 108
    invoke-virtual {p0, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method

.method public requestFullScreen()V
    .locals 1

    const-string v0, "javascript: var vid = document.querySelector(\'video\');  if (vid.requestFullscreen) {\n      vid.requestFullscreen();\n    } else if (vid.mozRequestFullScreen) {\n      vid.mozRequestFullScreen();\n    } else if (vid.webkitRequestFullscreen) {\n      vid.webkitRequestFullscreen();\n    }"

    .line 78
    invoke-virtual {p0, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method

.method public scrollActiveElementIntoView(Z)V
    .locals 0

    const-string p1, "javascript:setTimeout(function() { const element = document.activeElement;\nconst elementRect = element.getBoundingClientRect();\nconst absoluteElementTop = elementRect.top + window.pageYOffset;\nconst middle = absoluteElementTop - (window.innerHeight / 2);\nwindow.scrollTo(0, middle);},500);"

    .line 70
    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method

.method public seekBySeconds(I)V
    .locals 2

    .line 180
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "javascript:var v = document.querySelector(\"video\"); v.currentTime = v.currentTime + "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, ";"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method

.method public sendKeyboardEnterEvent()V
    .locals 1

    const-string v0, "javascript: var keyboardEvent = document.createEvent(\"KeyboardEvent\");\nvar initMethod = typeof keyboardEvent.initKeyboardEvent !== \'undefined\' ? \"initKeyboardEvent\" : \"initKeyEvent\";\nkeyboardEvent[initMethod](\n                   \"keyup\",                    true,                     true,                     window,                     false,                     false,                     false,                     false,                     13,                     0);\ndocument.activeElement.dispatchEvent(keyboardEvent);"

    .line 161
    invoke-virtual {p0, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method

.method public setAspectRatio(Ljava/lang/String;)V
    .locals 2

    .line 143
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "javascript:document.querySelector(\'video\').setAttribute(\'style\',\'object-fit:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "\');"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    .line 144
    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method

.method public showKeyboardIfInput()V
    .locals 1

    const-string v0, "javascript:setTimeout(function() {if(document.activeElement instanceof HTMLInputElement) {window.nativecallbacks.showKeyboard(document.activeElement.value);} else if(document.activeElement.getAttribute(\"contenteditable\") == \"true\") {window.nativecallbacks.showKeyboard(document.activeElement.innerText);} else {}}, 500);"

    .line 157
    invoke-virtual {p0, v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoWebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method
