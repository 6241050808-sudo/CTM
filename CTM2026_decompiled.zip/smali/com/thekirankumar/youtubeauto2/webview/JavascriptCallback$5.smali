.class Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$5;
.super Ljava/lang/Object;
.source "JavascriptCallback.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;->hideKeyboard()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;)V
    .locals 0

    .line 63
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$5;->this$0:Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .line 66
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$5;->this$0:Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;

    invoke-static {v0}, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;->access$000(Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback;)Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$JSCallbacks;

    move-result-object v0

    invoke-interface {v0}, Lcom/thekirankumar/youtubeauto2/webview/JavascriptCallback$JSCallbacks;->onHideKeyboardFromJS()V

    return-void
.end method
