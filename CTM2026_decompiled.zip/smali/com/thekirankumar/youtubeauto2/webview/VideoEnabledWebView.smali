.class public Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;
.super Landroid/webkit/WebView;
.source "VideoEnabledWebView.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView$JavascriptInterface;
    }
.end annotation


# instance fields
.field private addedJavascriptInterface:Z

.field private videoEnabledWebChromeClient:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 0

    .line 31
    invoke-direct {p0, p1}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V

    const/4 p1, 0x0

    .line 32
    iput-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->addedJavascriptInterface:Z

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 0

    .line 37
    invoke-direct {p0, p1, p2}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 p1, 0x0

    .line 38
    iput-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->addedJavascriptInterface:Z

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 0

    .line 43
    invoke-direct {p0, p1, p2, p3}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 p1, 0x0

    .line 44
    iput-boolean p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->addedJavascriptInterface:Z

    return-void
.end method

.method static synthetic access$000(Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;)Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;
    .locals 0

    .line 25
    iget-object p0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->videoEnabledWebChromeClient:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;

    return-object p0
.end method

.method private addJavascriptInterface()V
    .locals 2

    .line 111
    iget-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->addedJavascriptInterface:Z

    if-nez v0, :cond_0

    .line 114
    new-instance v0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView$JavascriptInterface;

    invoke-direct {v0, p0}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView$JavascriptInterface;-><init>(Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;)V

    const-string v1, "_VideoEnabledWebView"

    invoke-virtual {p0, v0, v1}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x1

    .line 116
    iput-boolean v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->addedJavascriptInterface:Z

    :cond_0
    return-void
.end method


# virtual methods
.method public exitFullScreen()V
    .locals 1

    .line 68
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->videoEnabledWebChromeClient:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->onHideCustomView()V

    return-void
.end method

.method public isVideoFullscreen()Z
    .locals 1

    .line 64
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->videoEnabledWebChromeClient:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->isVideoFullscreen()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public loadData(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 88
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->addJavascriptInterface()V

    .line 89
    invoke-super {p0, p1, p2, p3}, Landroid/webkit/WebView;->loadData(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public loadDataWithBaseURL(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 94
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->addJavascriptInterface()V

    .line 95
    invoke-super/range {p0 .. p5}, Landroid/webkit/WebView;->loadDataWithBaseURL(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public loadUrl(Ljava/lang/String;)V
    .locals 0

    .line 100
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->addJavascriptInterface()V

    .line 101
    invoke-super {p0, p1}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method

.method public loadUrl(Ljava/lang/String;Ljava/util/Map;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .line 106
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->addJavascriptInterface()V

    .line 107
    invoke-super {p0, p1, p2}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;Ljava/util/Map;)V

    return-void
.end method

.method protected onDetachedFromWindow()V
    .locals 0

    .line 54
    invoke-super {p0}, Landroid/webkit/WebView;->onDetachedFromWindow()V

    return-void
.end method

.method public onPause()V
    .locals 0

    return-void
.end method

.method public setWebChromeClient(Landroid/webkit/WebChromeClient;)V
    .locals 2

    .line 77
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    .line 79
    instance-of v0, p1, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;

    if-eqz v0, :cond_0

    .line 80
    move-object v0, p1

    check-cast v0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->videoEnabledWebChromeClient:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;

    .line 83
    :cond_0
    invoke-super {p0, p1}, Landroid/webkit/WebView;->setWebChromeClient(Landroid/webkit/WebChromeClient;)V

    return-void
.end method
