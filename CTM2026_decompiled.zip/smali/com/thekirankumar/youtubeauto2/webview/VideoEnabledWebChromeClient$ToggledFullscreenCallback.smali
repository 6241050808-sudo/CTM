.class public interface abstract Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient$ToggledFullscreenCallback;
.super Ljava/lang/Object;
.source "VideoEnabledWebChromeClient.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "ToggledFullscreenCallback"
.end annotation


# virtual methods
.method public abstract toggledFullscreen(Z)V
.end method
