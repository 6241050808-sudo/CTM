.class Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient$1;
.super Ljava/lang/Object;
.source "VideoEnabledWebChromeClient.java"

# interfaces
.implements Landroid/view/View$OnKeyListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->onShowCustomView(Landroid/view/View;Landroid/webkit/WebChromeClient$CustomViewCallback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;)V
    .locals 0

    .line 140
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient$1;->this$0:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .locals 0

    .line 143
    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result p1

    if-nez p1, :cond_0

    const/16 p1, 0x13

    if-ne p2, p1, :cond_0

    .line 145
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient$1;->this$0:Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;->access$000(Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebChromeClient;)Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;

    move-result-object p1

    invoke-virtual {p1}, Lcom/thekirankumar/youtubeauto2/webview/VideoEnabledWebView;->goBack()V

    const/4 p1, 0x1

    return p1

    :cond_0
    const/4 p1, 0x0

    return p1
.end method
