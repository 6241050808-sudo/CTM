.class public final Lcom/thekirankumar/youtubeauto2/R$string;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thekirankumar/youtubeauto2/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "string"
.end annotation


# static fields
.field public static final abc_action_bar_home_description:I = 0x7f100000

.field public static final abc_action_bar_up_description:I = 0x7f100001

.field public static final abc_action_menu_overflow_description:I = 0x7f100002

.field public static final abc_action_mode_done:I = 0x7f100003

.field public static final abc_activity_chooser_view_see_all:I = 0x7f100004

.field public static final abc_activitychooserview_choose_application:I = 0x7f100005

.field public static final abc_capital_off:I = 0x7f100006

.field public static final abc_capital_on:I = 0x7f100007

.field public static final abc_menu_alt_shortcut_label:I = 0x7f100008

.field public static final abc_menu_ctrl_shortcut_label:I = 0x7f100009

.field public static final abc_menu_delete_shortcut_label:I = 0x7f10000a

.field public static final abc_menu_enter_shortcut_label:I = 0x7f10000b

.field public static final abc_menu_function_shortcut_label:I = 0x7f10000c

.field public static final abc_menu_meta_shortcut_label:I = 0x7f10000d

.field public static final abc_menu_shift_shortcut_label:I = 0x7f10000e

.field public static final abc_menu_space_shortcut_label:I = 0x7f10000f

.field public static final abc_menu_sym_shortcut_label:I = 0x7f100010

.field public static final abc_prepend_shortcut_label:I = 0x7f100011

.field public static final abc_search_hint:I = 0x7f100012

.field public static final abc_searchview_description_clear:I = 0x7f100013

.field public static final abc_searchview_description_query:I = 0x7f100014

.field public static final abc_searchview_description_search:I = 0x7f100015

.field public static final abc_searchview_description_submit:I = 0x7f100016

.field public static final abc_searchview_description_voice:I = 0x7f100017

.field public static final abc_shareactionprovider_share_with:I = 0x7f100018

.field public static final abc_shareactionprovider_share_with_application:I = 0x7f100019

.field public static final abc_toolbar_collapse_description:I = 0x7f10001a

.field public static final about_page:I = 0x7f10001b

.field public static final add_bookmark:I = 0x7f10001c

.field public static final app_name:I = 0x7f10001d

.field public static final app_name_player:I = 0x7f10001e

.field public static final appbar_scrolling_view_behavior:I = 0x7f10001f

.field public static final aspect_ratio_contain:I = 0x7f100020

.field public static final aspect_ratio_cover:I = 0x7f100021

.field public static final aspect_ratio_fill:I = 0x7f100022

.field public static final bookmarks:I = 0x7f100023

.field public static final bottom_sheet_behavior:I = 0x7f100024

.field public static final car_service_name:I = 0x7f100025

.field public static final channel_name:I = 0x7f100026

.field public static final character_counter_content_description:I = 0x7f100027

.field public static final character_counter_overflowed_content_description:I = 0x7f100028

.field public static final character_counter_pattern:I = 0x7f100029

.field public static final chip_text:I = 0x7f10002a

.field public static final clear_text_end_icon_content_description:I = 0x7f10002b

.field public static final common_google_play_services_enable_button:I = 0x7f10002c

.field public static final common_google_play_services_enable_text:I = 0x7f10002d

.field public static final common_google_play_services_enable_title:I = 0x7f10002e

.field public static final common_google_play_services_install_button:I = 0x7f10002f

.field public static final common_google_play_services_install_text:I = 0x7f100030

.field public static final common_google_play_services_install_title:I = 0x7f100031

.field public static final common_google_play_services_notification_channel_name:I = 0x7f100032

.field public static final common_google_play_services_notification_ticker:I = 0x7f100033

.field public static final common_google_play_services_unknown_issue:I = 0x7f100034

.field public static final common_google_play_services_unsupported_text:I = 0x7f100035

.field public static final common_google_play_services_update_button:I = 0x7f100036

.field public static final common_google_play_services_update_text:I = 0x7f100037

.field public static final common_google_play_services_update_title:I = 0x7f100038

.field public static final common_google_play_services_updating_text:I = 0x7f100039

.field public static final common_google_play_services_wear_update_text:I = 0x7f10003a

.field public static final common_open_on_phone:I = 0x7f10003b

.field public static final common_signin_button_text:I = 0x7f10003c

.field public static final common_signin_button_text_long:I = 0x7f10003d

.field public static final default_web_client_id:I = 0x7f10003e

.field public static final error_icon_content_description:I = 0x7f10003f

.field public static final exo_controls_fastforward_description:I = 0x7f100040

.field public static final exo_controls_fullscreen_description:I = 0x7f100041

.field public static final exo_controls_hide:I = 0x7f100042

.field public static final exo_controls_next_description:I = 0x7f100043

.field public static final exo_controls_pause_description:I = 0x7f100044

.field public static final exo_controls_play_description:I = 0x7f100045

.field public static final exo_controls_previous_description:I = 0x7f100046

.field public static final exo_controls_repeat_all_description:I = 0x7f100047

.field public static final exo_controls_repeat_off_description:I = 0x7f100048

.field public static final exo_controls_repeat_one_description:I = 0x7f100049

.field public static final exo_controls_rewind_description:I = 0x7f10004a

.field public static final exo_controls_show:I = 0x7f10004b

.field public static final exo_controls_shuffle_off_description:I = 0x7f10004c

.field public static final exo_controls_shuffle_on_description:I = 0x7f10004d

.field public static final exo_controls_stop_description:I = 0x7f10004e

.field public static final exo_controls_vr_description:I = 0x7f10004f

.field public static final exo_download_completed:I = 0x7f100050

.field public static final exo_download_description:I = 0x7f100051

.field public static final exo_download_downloading:I = 0x7f100052

.field public static final exo_download_failed:I = 0x7f100053

.field public static final exo_download_notification_channel_name:I = 0x7f100054

.field public static final exo_download_removing:I = 0x7f100055

.field public static final exo_item_list:I = 0x7f100056

.field public static final exo_track_bitrate:I = 0x7f100057

.field public static final exo_track_mono:I = 0x7f100058

.field public static final exo_track_resolution:I = 0x7f100059

.field public static final exo_track_role_alternate:I = 0x7f10005a

.field public static final exo_track_role_closed_captions:I = 0x7f10005b

.field public static final exo_track_role_commentary:I = 0x7f10005c

.field public static final exo_track_role_supplementary:I = 0x7f10005d

.field public static final exo_track_selection_auto:I = 0x7f10005e

.field public static final exo_track_selection_none:I = 0x7f10005f

.field public static final exo_track_selection_title_audio:I = 0x7f100060

.field public static final exo_track_selection_title_text:I = 0x7f100061

.field public static final exo_track_selection_title_video:I = 0x7f100062

.field public static final exo_track_stereo:I = 0x7f100063

.field public static final exo_track_surround:I = 0x7f100064

.field public static final exo_track_surround_5_point_1:I = 0x7f100065

.field public static final exo_track_surround_7_point_1:I = 0x7f100066

.field public static final exo_track_unknown:I = 0x7f100067

.field public static final exposed_dropdown_menu_content_description:I = 0x7f100068

.field public static final external_storage:I = 0x7f100069

.field public static final fab_transformation_scrim_behavior:I = 0x7f10006a

.field public static final fab_transformation_sheet_behavior:I = 0x7f10006b

.field public static final fcm_fallback_notification_channel_label:I = 0x7f10006c

.field public static final firebase_database_url:I = 0x7f10006d

.field public static final fullscreen:I = 0x7f10006e

.field public static final gcm_defaultSenderId:I = 0x7f10006f

.field public static final google_api_key:I = 0x7f100070

.field public static final google_app_id:I = 0x7f100071

.field public static final google_crash_reporting_api_key:I = 0x7f100072

.field public static final google_storage_bucket:I = 0x7f100073

.field public static final hide_bottom_view_on_scroll_behavior:I = 0x7f100074

.field public static final home:I = 0x7f100075

.field public static final icon_content_description:I = 0x7f100076

.field public static final internal_storage:I = 0x7f100077

.field public static final mtrl_badge_numberless_content_description:I = 0x7f100078

.field public static final mtrl_chip_close_icon_content_description:I = 0x7f100079

.field public static final mtrl_exceed_max_badge_number_suffix:I = 0x7f10007a

.field public static final mtrl_picker_a11y_next_month:I = 0x7f10007b

.field public static final mtrl_picker_a11y_prev_month:I = 0x7f10007c

.field public static final mtrl_picker_announce_current_selection:I = 0x7f10007d

.field public static final mtrl_picker_cancel:I = 0x7f10007e

.field public static final mtrl_picker_confirm:I = 0x7f10007f

.field public static final mtrl_picker_date_header_selected:I = 0x7f100080

.field public static final mtrl_picker_date_header_title:I = 0x7f100081

.field public static final mtrl_picker_date_header_unselected:I = 0x7f100082

.field public static final mtrl_picker_day_of_week_column_header:I = 0x7f100083

.field public static final mtrl_picker_invalid_format:I = 0x7f100084

.field public static final mtrl_picker_invalid_format_example:I = 0x7f100085

.field public static final mtrl_picker_invalid_format_use:I = 0x7f100086

.field public static final mtrl_picker_invalid_range:I = 0x7f100087

.field public static final mtrl_picker_navigate_to_year_description:I = 0x7f100088

.field public static final mtrl_picker_out_of_range:I = 0x7f100089

.field public static final mtrl_picker_range_header_only_end_selected:I = 0x7f10008a

.field public static final mtrl_picker_range_header_only_start_selected:I = 0x7f10008b

.field public static final mtrl_picker_range_header_selected:I = 0x7f10008c

.field public static final mtrl_picker_range_header_title:I = 0x7f10008d

.field public static final mtrl_picker_range_header_unselected:I = 0x7f10008e

.field public static final mtrl_picker_save:I = 0x7f10008f

.field public static final mtrl_picker_text_input_date_hint:I = 0x7f100090

.field public static final mtrl_picker_text_input_date_range_end_hint:I = 0x7f100091

.field public static final mtrl_picker_text_input_date_range_start_hint:I = 0x7f100092

.field public static final mtrl_picker_text_input_day_abbr:I = 0x7f100093

.field public static final mtrl_picker_text_input_month_abbr:I = 0x7f100094

.field public static final mtrl_picker_text_input_year_abbr:I = 0x7f100095

.field public static final mtrl_picker_toggle_to_calendar_input_mode:I = 0x7f100096

.field public static final mtrl_picker_toggle_to_day_selection:I = 0x7f100097

.field public static final mtrl_picker_toggle_to_text_input_mode:I = 0x7f100098

.field public static final mtrl_picker_toggle_to_year_selection:I = 0x7f100099

.field public static final night_mode:I = 0x7f10009a

.field public static final password_toggle_content_description:I = 0x7f10009b

.field public static final path_password_eye:I = 0x7f10009c

.field public static final path_password_eye_mask_strike_through:I = 0x7f10009d

.field public static final path_password_eye_mask_visible:I = 0x7f10009e

.field public static final path_password_strike_through:I = 0x7f10009f

.field public static final project_id:I = 0x7f1000a0

.field public static final receive_from_phone:I = 0x7f1000a1

.field public static final refresh_page:I = 0x7f1000a2

.field public static final search:I = 0x7f1000a3

.field public static final search_menu_title:I = 0x7f1000a4

.field public static final send_to_car:I = 0x7f1000a5

.field public static final settings:I = 0x7f1000a6

.field public static final settings_car_category:I = 0x7f1000a7

.field public static final settings_car_disable_notifications_summary:I = 0x7f1000a8

.field public static final settings_car_disable_notifications_title:I = 0x7f1000a9

.field public static final settings_car_enable_desktop_mode_summary:I = 0x7f1000aa

.field public static final settings_car_enable_desktop_mode_title:I = 0x7f1000ab

.field public static final status_bar_notification_info_overflow:I = 0x7f1000ac

.field public static final unlock:I = 0x7f1000ad

.field public static final url_edittext_phone_app:I = 0x7f1000ae

.field public static final version:I = 0x7f1000af

.field public static final voice_search:I = 0x7f1000b0

.field public static final warning_accept_button:I = 0x7f1000b1

.field public static final warning_body:I = 0x7f1000b2

.field public static final warning_title:I = 0x7f1000b3

.field public static final webview_back:I = 0x7f1000b4


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
