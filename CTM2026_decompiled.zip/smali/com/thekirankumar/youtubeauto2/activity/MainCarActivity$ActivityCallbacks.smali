.class public interface abstract Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity$ActivityCallbacks;
.super Ljava/lang/Object;
.source "MainCarActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "ActivityCallbacks"
.end annotation


# virtual methods
.method public abstract onWindowFocusChanged(Z)V
.end method
