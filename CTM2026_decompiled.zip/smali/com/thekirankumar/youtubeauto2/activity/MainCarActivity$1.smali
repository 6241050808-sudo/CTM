.class Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity$1;
.super Landroidx/fragment/app/FragmentManager$FragmentLifecycleCallbacks;
.source "MainCarActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;


# direct methods
.method constructor <init>(Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;)V
    .locals 0

    .line 27
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity$1;->this$0:Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;

    invoke-direct {p0}, Landroidx/fragment/app/FragmentManager$FragmentLifecycleCallbacks;-><init>()V

    return-void
.end method


# virtual methods
.method public onFragmentStarted(Landroidx/fragment/app/FragmentManager;Landroidx/fragment/app/Fragment;)V
    .locals 0

    .line 30
    iget-object p1, p0, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity$1;->this$0:Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;

    invoke-static {p1}, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->access$000(Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;)V

    return-void
.end method
