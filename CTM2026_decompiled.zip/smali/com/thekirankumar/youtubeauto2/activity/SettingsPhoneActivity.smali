.class public Lcom/thekirankumar/youtubeauto2/activity/SettingsPhoneActivity;
.super Landroidx/appcompat/app/AppCompatActivity;
.source "SettingsPhoneActivity.java"


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 9
    invoke-direct {p0}, Landroidx/appcompat/app/AppCompatActivity;-><init>()V

    return-void
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 0

    .line 13
    invoke-super {p0, p1}, Landroidx/appcompat/app/AppCompatActivity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f0b001e

    .line 14
    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/activity/SettingsPhoneActivity;->setContentView(I)V

    return-void
.end method
