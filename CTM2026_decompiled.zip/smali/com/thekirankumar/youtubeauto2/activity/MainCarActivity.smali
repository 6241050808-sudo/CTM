.class public Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;
.super Lcom/google/android/apps/auto/sdk/CarActivity;
.source "MainCarActivity.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity$ActivityCallbacks;
    }
.end annotation


# static fields
.field private static final CURRENT_FRAGMENT_KEY:Ljava/lang/String; = "app_current_fragment"

.field private static final FRAGMENT_MAIN:Ljava/lang/String; = "main"


# instance fields
.field private activityCallbacks:Ljava/util/HashSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashSet<",
            "Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity$ActivityCallbacks;",
            ">;"
        }
    .end annotation
.end field

.field private mCurrentFragmentTag:Ljava/lang/String;

.field private final mFragmentLifecycleCallbacks:Landroidx/fragment/app/FragmentManager$FragmentLifecycleCallbacks;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 22
    invoke-direct {p0}, Lcom/google/android/apps/auto/sdk/CarActivity;-><init>()V

    .line 26
    new-instance v0, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity$1;

    invoke-direct {v0, p0}, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity$1;-><init>(Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;)V

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->mFragmentLifecycleCallbacks:Landroidx/fragment/app/FragmentManager$FragmentLifecycleCallbacks;

    .line 33
    new-instance v0, Ljava/util/HashSet;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/HashSet;-><init>(I)V

    iput-object v0, p0, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->activityCallbacks:Ljava/util/HashSet;

    return-void
.end method

.method static synthetic access$000(Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;)V
    .locals 0

    .line 22
    invoke-direct {p0}, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->updateStatusBarTitle()V

    return-void
.end method

.method private switchToFragment(Ljava/lang/String;)V
    .locals 3

    .line 92
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->mCurrentFragmentTag:Ljava/lang/String;

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_0

    return-void

    .line 95
    :cond_0
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    .line 96
    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->mCurrentFragmentTag:Ljava/lang/String;

    if-nez v1, :cond_1

    const/4 v1, 0x0

    goto :goto_0

    :cond_1
    invoke-virtual {v0, v1}, Landroidx/fragment/app/FragmentManager;->findFragmentByTag(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v1

    .line 97
    :goto_0
    invoke-virtual {v0, p1}, Landroidx/fragment/app/FragmentManager;->findFragmentByTag(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v0

    .line 98
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/fragment/app/FragmentManager;->beginTransaction()Landroidx/fragment/app/FragmentTransaction;

    move-result-object v2

    if-eqz v1, :cond_2

    .line 100
    invoke-virtual {v2, v1}, Landroidx/fragment/app/FragmentTransaction;->detach(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/FragmentTransaction;

    .line 102
    :cond_2
    invoke-virtual {v2, v0}, Landroidx/fragment/app/FragmentTransaction;->attach(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/FragmentTransaction;

    .line 103
    invoke-virtual {v2}, Landroidx/fragment/app/FragmentTransaction;->commit()I

    .line 104
    iput-object p1, p0, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->mCurrentFragmentTag:Ljava/lang/String;

    return-void
.end method

.method private updateStatusBarTitle()V
    .locals 2

    .line 108
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    iget-object v1, p0, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->mCurrentFragmentTag:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroidx/fragment/app/FragmentManager;->findFragmentByTag(Ljava/lang/String;)Landroidx/fragment/app/Fragment;

    move-result-object v0

    check-cast v0, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;

    .line 109
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->getCarUiController()Lcom/google/android/apps/auto/sdk/CarUiController;

    move-result-object v1

    invoke-virtual {v1}, Lcom/google/android/apps/auto/sdk/CarUiController;->getStatusBarController()Lcom/google/android/apps/auto/sdk/StatusBarController;

    move-result-object v1

    invoke-virtual {v0}, Lcom/thekirankumar/youtubeauto2/fragments/CarFragment;->getTitle()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Lcom/google/android/apps/auto/sdk/StatusBarController;->setTitle(Ljava/lang/CharSequence;)V

    return-void
.end method


# virtual methods
.method public addActivityCallback(Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity$ActivityCallbacks;)V
    .locals 1

    .line 117
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->activityCallbacks:Ljava/util/HashSet;

    invoke-virtual {v0, p1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method public getWindow()Landroid/view/Window;
    .locals 1

    .line 113
    invoke-super {p0}, Lcom/google/android/apps/auto/sdk/CarActivity;->c()Landroid/view/Window;

    move-result-object v0

    return-object v0
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .locals 4

    .line 47
    invoke-super {p0, p1}, Lcom/google/android/apps/auto/sdk/CarActivity;->onCreate(Landroid/os/Bundle;)V

    const v0, 0x7f0b001c

    .line 48
    invoke-virtual {p0, v0}, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->setContentView(I)V

    .line 50
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->getCarUiController()Lcom/google/android/apps/auto/sdk/CarUiController;

    move-result-object v0

    .line 51
    invoke-virtual {v0}, Lcom/google/android/apps/auto/sdk/CarUiController;->getStatusBarController()Lcom/google/android/apps/auto/sdk/StatusBarController;

    move-result-object v1

    invoke-virtual {v1}, Lcom/google/android/apps/auto/sdk/StatusBarController;->hideAppHeader()V

    .line 52
    invoke-virtual {v0}, Lcom/google/android/apps/auto/sdk/CarUiController;->getStatusBarController()Lcom/google/android/apps/auto/sdk/StatusBarController;

    move-result-object v0

    invoke-virtual {v0}, Lcom/google/android/apps/auto/sdk/StatusBarController;->hideConnectivityLevel()V

    .line 53
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->c()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const/16 v1, 0x1806

    invoke-virtual {v0, v1}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 57
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object v0

    .line 58
    new-instance v1, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;

    invoke-direct {v1}, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment;-><init>()V

    .line 60
    invoke-virtual {v0}, Landroidx/fragment/app/FragmentManager;->beginTransaction()Landroidx/fragment/app/FragmentTransaction;

    move-result-object v0

    const-string v2, "main"

    const v3, 0x7f0800af

    .line 61
    invoke-virtual {v0, v3, v1, v2}, Landroidx/fragment/app/FragmentTransaction;->add(ILandroidx/fragment/app/Fragment;Ljava/lang/String;)Landroidx/fragment/app/FragmentTransaction;

    move-result-object v0

    .line 62
    invoke-virtual {v0, v1}, Landroidx/fragment/app/FragmentTransaction;->detach(Landroidx/fragment/app/Fragment;)Landroidx/fragment/app/FragmentTransaction;

    move-result-object v0

    .line 63
    invoke-virtual {v0}, Landroidx/fragment/app/FragmentTransaction;->commitNow()V

    if-eqz p1, :cond_0

    const-string v0, "app_current_fragment"

    .line 66
    invoke-virtual {p1, v0}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 67
    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    .line 69
    :cond_0
    invoke-direct {p0, v2}, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->switchToFragment(Ljava/lang/String;)V

    .line 70
    invoke-virtual {p0}, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->getSupportFragmentManager()Landroidx/fragment/app/FragmentManager;

    move-result-object p1

    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->mFragmentLifecycleCallbacks:Landroidx/fragment/app/FragmentManager$FragmentLifecycleCallbacks;

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Landroidx/fragment/app/FragmentManager;->registerFragmentLifecycleCallbacks(Landroidx/fragment/app/FragmentManager$FragmentLifecycleCallbacks;Z)V

    return-void
.end method

.method public onNewIntent(Landroid/content/Intent;)V
    .locals 0

    .line 76
    invoke-super {p0, p1}, Lcom/google/android/apps/auto/sdk/CarActivity;->onNewIntent(Landroid/content/Intent;)V

    return-void
.end method

.method public onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 2

    .line 81
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->mCurrentFragmentTag:Ljava/lang/String;

    const-string v1, "app_current_fragment"

    invoke-virtual {p1, v1, v0}, Landroid/os/Bundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 82
    invoke-super {p0, p1}, Lcom/google/android/apps/auto/sdk/CarActivity;->onSaveInstanceState(Landroid/os/Bundle;)V

    return-void
.end method

.method public onStart()V
    .locals 1

    .line 87
    invoke-super {p0}, Lcom/google/android/apps/auto/sdk/CarActivity;->onStart()V

    .line 88
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->mCurrentFragmentTag:Ljava/lang/String;

    invoke-direct {p0, v0}, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->switchToFragment(Ljava/lang/String;)V

    return-void
.end method

.method public onWindowFocusChanged(ZZ)V
    .locals 1

    .line 37
    invoke-super {p0, p1, p2}, Lcom/google/android/apps/auto/sdk/CarActivity;->onWindowFocusChanged(ZZ)V

    .line 38
    iget-object p2, p0, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->activityCallbacks:Ljava/util/HashSet;

    invoke-virtual {p2}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_0
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity$ActivityCallbacks;

    .line 39
    invoke-interface {v0, p1}, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity$ActivityCallbacks;->onWindowFocusChanged(Z)V

    goto :goto_0

    :cond_0
    return-void
.end method

.method public removeActivityCallback(Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity$ActivityCallbacks;)V
    .locals 1

    .line 121
    iget-object v0, p0, Lcom/thekirankumar/youtubeauto2/activity/MainCarActivity;->activityCallbacks:Ljava/util/HashSet;

    invoke-virtual {v0, p1}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    return-void
.end method
