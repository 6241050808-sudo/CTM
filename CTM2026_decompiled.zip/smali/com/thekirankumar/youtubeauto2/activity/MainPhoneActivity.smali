.class public Lcom/thekirankumar/youtubeauto2/activity/MainPhoneActivity;
.super Landroidx/appcompat/app/AppCompatActivity;
.source "MainPhoneActivity.java"

# interfaces
.implements Lcom/thekirankumar/youtubeauto2/exoplayer/ExoPlayerFragment$OnFragmentInteractionListener;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 12
    invoke-direct {p0}, Landroidx/appcompat/app/AppCompatActivity;-><init>()V

    return-void
.end method


# virtual methods
.method public getAspectRatio()Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;
    .locals 1

    .line 43
    sget-object v0, Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;->CONTAIN:Lcom/thekirankumar/youtubeauto2/fragments/WebViewCarFragment$AspectRatio;

    return-object v0
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 0

    .line 16
    invoke-super {p0, p1}, Landroidx/appcompat/app/AppCompatActivity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f0b001d

    .line 17
    invoke-virtual {p0, p1}, Lcom/thekirankumar/youtubeauto2/activity/MainPhoneActivity;->setContentView(I)V

    return-void
.end method

.method public onKeyDown(ILandroid/view/KeyEvent;)Z
    .locals 0

    .line 33
    invoke-super {p0, p1, p2}, Landroidx/appcompat/app/AppCompatActivity;->onKeyDown(ILandroid/view/KeyEvent;)Z

    move-result p1

    return p1
.end method

.method public onKeyUp(ILandroid/view/KeyEvent;)Z
    .locals 0

    .line 28
    invoke-super {p0, p1, p2}, Landroidx/appcompat/app/AppCompatActivity;->onKeyUp(ILandroid/view/KeyEvent;)Z

    move-result p1

    return p1
.end method

.method public onNativePlayerControlsVisibilityChange(I)V
    .locals 0

    return-void
.end method

.method protected onResume()V
    .locals 0

    .line 23
    invoke-super {p0}, Landroidx/appcompat/app/AppCompatActivity;->onResume()V

    return-void
.end method
