.class public final Lcom/thekirankumar/youtubeauto2/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/thekirankumar/youtubeauto2/R$anim;,
        Lcom/thekirankumar/youtubeauto2/R$animator;,
        Lcom/thekirankumar/youtubeauto2/R$attr;,
        Lcom/thekirankumar/youtubeauto2/R$bool;,
        Lcom/thekirankumar/youtubeauto2/R$color;,
        Lcom/thekirankumar/youtubeauto2/R$dimen;,
        Lcom/thekirankumar/youtubeauto2/R$drawable;,
        Lcom/thekirankumar/youtubeauto2/R$id;,
        Lcom/thekirankumar/youtubeauto2/R$integer;,
        Lcom/thekirankumar/youtubeauto2/R$interpolator;,
        Lcom/thekirankumar/youtubeauto2/R$layout;,
        Lcom/thekirankumar/youtubeauto2/R$menu;,
        Lcom/thekirankumar/youtubeauto2/R$mipmap;,
        Lcom/thekirankumar/youtubeauto2/R$plurals;,
        Lcom/thekirankumar/youtubeauto2/R$raw;,
        Lcom/thekirankumar/youtubeauto2/R$string;,
        Lcom/thekirankumar/youtubeauto2/R$style;,
        Lcom/thekirankumar/youtubeauto2/R$styleable;,
        Lcom/thekirankumar/youtubeauto2/R$xml;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
