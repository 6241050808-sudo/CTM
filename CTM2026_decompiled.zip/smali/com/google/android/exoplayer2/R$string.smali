.class public final Lcom/google/android/exoplayer2/R$string;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/exoplayer2/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "string"
.end annotation


# static fields
.field public static final exo_controls_fastforward_description:I = 0x7f100040

.field public static final exo_controls_fullscreen_description:I = 0x7f100041

.field public static final exo_controls_hide:I = 0x7f100042

.field public static final exo_controls_next_description:I = 0x7f100043

.field public static final exo_controls_pause_description:I = 0x7f100044

.field public static final exo_controls_play_description:I = 0x7f100045

.field public static final exo_controls_previous_description:I = 0x7f100046

.field public static final exo_controls_repeat_all_description:I = 0x7f100047

.field public static final exo_controls_repeat_off_description:I = 0x7f100048

.field public static final exo_controls_repeat_one_description:I = 0x7f100049

.field public static final exo_controls_rewind_description:I = 0x7f10004a

.field public static final exo_controls_show:I = 0x7f10004b

.field public static final exo_controls_shuffle_off_description:I = 0x7f10004c

.field public static final exo_controls_shuffle_on_description:I = 0x7f10004d

.field public static final exo_controls_stop_description:I = 0x7f10004e

.field public static final exo_controls_vr_description:I = 0x7f10004f

.field public static final exo_download_completed:I = 0x7f100050

.field public static final exo_download_description:I = 0x7f100051

.field public static final exo_download_downloading:I = 0x7f100052

.field public static final exo_download_failed:I = 0x7f100053

.field public static final exo_download_notification_channel_name:I = 0x7f100054

.field public static final exo_download_removing:I = 0x7f100055

.field public static final exo_item_list:I = 0x7f100056

.field public static final exo_track_bitrate:I = 0x7f100057

.field public static final exo_track_mono:I = 0x7f100058

.field public static final exo_track_resolution:I = 0x7f100059

.field public static final exo_track_role_alternate:I = 0x7f10005a

.field public static final exo_track_role_closed_captions:I = 0x7f10005b

.field public static final exo_track_role_commentary:I = 0x7f10005c

.field public static final exo_track_role_supplementary:I = 0x7f10005d

.field public static final exo_track_selection_auto:I = 0x7f10005e

.field public static final exo_track_selection_none:I = 0x7f10005f

.field public static final exo_track_selection_title_audio:I = 0x7f100060

.field public static final exo_track_selection_title_text:I = 0x7f100061

.field public static final exo_track_selection_title_video:I = 0x7f100062

.field public static final exo_track_stereo:I = 0x7f100063

.field public static final exo_track_surround:I = 0x7f100064

.field public static final exo_track_surround_5_point_1:I = 0x7f100065

.field public static final exo_track_surround_7_point_1:I = 0x7f100066

.field public static final exo_track_unknown:I = 0x7f100067

.field public static final status_bar_notification_info_overflow:I = 0x7f1000ac


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
