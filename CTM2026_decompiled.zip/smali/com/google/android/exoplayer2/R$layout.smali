.class public final Lcom/google/android/exoplayer2/R$layout;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/exoplayer2/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "layout"
.end annotation


# static fields
.field public static final exo_list_divider:I = 0x7f0b003a

.field public static final exo_playback_control_view:I = 0x7f0b003b

.field public static final exo_player_control_view:I = 0x7f0b003c

.field public static final exo_player_view:I = 0x7f0b003d

.field public static final exo_simple_player_view:I = 0x7f0b003e

.field public static final exo_track_selection_dialog:I = 0x7f0b003f

.field public static final notification_action:I = 0x7f0b005f

.field public static final notification_action_tombstone:I = 0x7f0b0060

.field public static final notification_media_action:I = 0x7f0b0061

.field public static final notification_media_cancel_action:I = 0x7f0b0062

.field public static final notification_template_big_media:I = 0x7f0b0063

.field public static final notification_template_big_media_custom:I = 0x7f0b0064

.field public static final notification_template_big_media_narrow:I = 0x7f0b0065

.field public static final notification_template_big_media_narrow_custom:I = 0x7f0b0066

.field public static final notification_template_custom_big:I = 0x7f0b0067

.field public static final notification_template_icon_group:I = 0x7f0b0068

.field public static final notification_template_lines_media:I = 0x7f0b0069

.field public static final notification_template_media:I = 0x7f0b006a

.field public static final notification_template_media_custom:I = 0x7f0b006b

.field public static final notification_template_part_chronometer:I = 0x7f0b006c

.field public static final notification_template_part_time:I = 0x7f0b006d


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
