.class public final Lcom/google/android/exoplayer2/R$integer;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/exoplayer2/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "integer"
.end annotation


# static fields
.field public static final cancel_button_image_alpha:I = 0x7f090004

.field public static final exo_media_button_opacity_percentage_disabled:I = 0x7f090009

.field public static final exo_media_button_opacity_percentage_enabled:I = 0x7f09000a

.field public static final status_bar_notification_info_maxnum:I = 0x7f090018


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
